# Guia Completo de Deploy do Projeto MercadoPlast no Google Cloud Platform

Este documento detalha os passos necessários para realizar o deploy completo do projeto MercadoPlast (backend e frontend) no Google Cloud Platform (GCP).

## 1. Visão Geral da Arquitetura

O projeto MercadoPlast é composto por:

*   **Backend**: Uma API Node.js (TypeScript) que interage com um banco de dados PostgreSQL (Cloud SQL) e utiliza o Google Cloud Storage para uploads.
*   **Frontend (App Principal)**: Uma aplicação React para usuários finais.
*   **Frontend (Admin)**: Uma aplicação React separada para administração.

Ambos os frontends e o backend são projetados para serem deployados como serviços separados no Google Cloud Run, utilizando imagens Docker e o Cloud Build para automação do CI/CD.

## 2. Pré-requisitos

Certifique-se de ter os seguintes recursos e ferramentas configurados:

*   **Projeto Google Cloud**: Um projeto ativo no GCP com faturamento habilitado.
*   **Google Cloud SDK (gcloud)**: Instalado e autenticado localmente.
*   **Docker**: Instalado localmente para construir e testar imagens Docker.
*   **Cloud SQL (PostgreSQL)**: Uma instância de PostgreSQL configurada. Anote o IP de conexão, usuário, senha e nome do banco de dados.
*   **Cloud Storage Bucket**: Um bucket criado para armazenar arquivos (ex: documentos KYC, imagens).
*   **Google Secret Manager**: Para armazenar com segurança variáveis de ambiente sensíveis.
*   **APIs Habilitadas no GCP**: Cloud Run API, Cloud Build API, Cloud SQL Admin API, Secret Manager API, Cloud Storage API.

## 3. Configuração de Variáveis de Ambiente e Secrets

Todas as variáveis de ambiente sensíveis devem ser armazenadas no Google Secret Manager e injetadas nos serviços do Cloud Run no momento do deploy.

### 3.1. Backend (`.env.example`)

O arquivo `backend/.env.example` lista todas as variáveis necessárias para o backend. Você deve criar secrets correspondentes no Secret Manager.

**Variáveis Críticas para o Backend:**

*   `DATABASE_URL`: String de conexão completa para o Cloud SQL (ex: `postgres://<DB_USER>:<DB_PASSWORD>@<DB_HOST>:5432/<DB_NAME>`).
*   `JWT_SECRET`: Chave secreta forte para JSON Web Tokens.
*   `REFRESH_TOKEN_SECRET`: Chave secreta forte para Refresh Tokens.
*   `MP_ACCESS_TOKEN`: Token de acesso do Mercado Pago.
*   `GCP_PROJECT_ID`: ID do seu projeto GCP.
*   `GCS_BUCKET`: Nome do bucket do Cloud Storage para uploads.
*   `GCP_CREDENTIALS_BASE64`: Credenciais da conta de serviço em Base64. (Exemplo: `cat /path/to/your/service-account-key.json | base64`)
*   `CORS_ORIGIN`: URLs permitidas para CORS (ex: `https://app.seusite.com,https://admin.seusite.com`).

**Exemplo de criação de secrets (substitua os valores):**

```bash
gcloud secrets create DATABASE_URL --data-file=<(echo 'postgres://user:pass@host:5432/db_name')
gcloud secrets create JWT_SECRET --data-file=<(echo 'sua_chave_jwt_secreta_aqui')
gcloud secrets create REFRESH_TOKEN_SECRET --data-file=<(echo 'sua_chave_refresh_token_secreta_aqui')
gcloud secrets create MP_ACCESS_TOKEN --data-file=<(echo 'seu_token_mercado_pago')
gcloud secrets create GCP_CREDENTIALS_BASE64 --data-file=<(cat /path/to/your/service-account-key.json | base64)
```

### 3.2. Frontend (App Principal e Admin)

Os frontends geralmente consomem variáveis de ambiente no tempo de build. As variáveis configuradas no `.env.example` do backend que são relevantes para o frontend (como `CORS_ORIGIN` ou URLs de API) devem ser configuradas no ambiente de build do frontend.

**Variáveis Críticas para o Frontend:**

*   `VITE_API_BASE_URL`: URL base da API do backend (ex: `https://api.seusite.com`).

Estas variáveis devem ser passadas para o Cloud Build durante o processo de build do frontend, ou configuradas diretamente nos arquivos `.env` de cada frontend (para desenvolvimento local).

## 4. Deploy do Backend

O backend possui um `Dockerfile` e um `cloudbuild.yaml` para automação do deploy.

### 4.1. `Dockerfile` do Backend

Localizado em `backend/Dockerfile`. Este Dockerfile constrói a imagem da aplicação Node.js.

### 4.2. `cloudbuild.yaml` do Backend

Localizado em `backend/cloudbuild.yaml`. Este arquivo define os passos para:

1.  Construir a imagem Docker do backend.
2.  Fazer push da imagem para o Google Container Registry (GCR).
3.  Deployar o serviço no Google Cloud Run, injetando os secrets do Secret Manager.

**Para testar o `cloudbuild.yaml` e o `Dockerfile` do backend:**

Navegue até o diretório `backend` e execute:

```bash
gcloud builds submit --config cloudbuild.yaml --substitutions _REGION=us-central1
```

Substitua `us-central1` pela região desejada.

### 4.3. Script de Configuração Inicial (`scripts/setup.sh`)

Localizado em `backend/scripts/setup.sh`. Este script é responsável por:

*   Verificar variáveis de ambiente essenciais.
*   Executar migrações do banco de dados (`npx knex migrate:latest`).

Este script deve ser executado como parte do processo de build da imagem Docker ou como um passo inicial no Cloud Run, antes da aplicação iniciar. O `Dockerfile` do backend já está configurado para executar as migrações.

## 5. Deploy do Frontend (App Principal e Admin)

Ambos os frontends (App Principal e Admin) seguem um processo de deploy similar, cada um com seu próprio `Dockerfile` e `cloudbuild.yaml`.

### 5.1. `Dockerfile` do Frontend

*   **App Principal**: `frontend/app/Dockerfile`
*   **Admin**: `frontend/admin/Dockerfile`

Estes Dockerfiles constroem a aplicação React e a servem usando Nginx.

### 5.2. `nginx.conf` do Frontend

Localizado em `frontend/nginx.conf`. Este arquivo de configuração do Nginx é compartilhado por ambos os frontends e serve para:

*   Servir arquivos estáticos.
*   Configurar roteamento para Single Page Applications (SPAs).
*   Adicionar headers de segurança e cache.
*   Configurar `health checks` para o Cloud Run.

### 5.3. `cloudbuild.yaml` do Frontend

*   **App Principal**: `frontend/app/cloudbuild.yaml`
*   **Admin**: `frontend/admin/cloudbuild.yaml`

Estes arquivos definem os passos para:

1.  Construir a imagem Docker do frontend.
2.  Fazer push da imagem para o Google Container Registry (GCR).
3.  Deployar o serviço no Google Cloud Run.

**Para testar o `cloudbuild.yaml` e o `Dockerfile` do frontend (exemplo para o App Principal):**

Navegue até o diretório `frontend/app` e execute:

```bash
gcloud builds submit --config cloudbuild.yaml --substitutions _REGION=us-central1
```

Repita o processo para o diretório `frontend/admin` para o frontend Admin.

## 6. Configurações Específicas do Cloud

### 6.1. Cloud SQL Connection

O `DATABASE_URL` deve ser configurado para permitir que o Cloud Run se conecte ao Cloud SQL. Para uma conexão segura e privada, é recomendado usar o Cloud SQL Proxy ou VPC Serverless Access.

### 6.2. Cloud Storage Bucket para Uploads

Certifique-se de que a conta de serviço utilizada pelo Cloud Run (ou Cloud Build, se o upload ocorrer durante o build) tenha as permissões necessárias para ler e escrever no bucket do Cloud Storage (`roles/storage.objectAdmin`).

### 6.3. Load Balancer (Opcional)

Se você planeja ter domínios personalizados e balanceamento de carga entre múltiplos serviços ou regiões, um Load Balancer (HTTP(S) Load Balancing) pode ser configurado na frente dos serviços do Cloud Run.

## 7. Fluxo de Doação Manual e Interação Humana (Característica Intencional)

Conforme sua visão para o MercadoPlast, o processo de doação é intencionalmente manual para fomentar a interação humana e a conexão com os apoiadores. Este fluxo é totalmente suportado pela arquitetura atual e é considerado uma **característica fundamental** do projeto, não uma limitação.

**Fluxo Detalhado:**

1.  **Geração do Link de Doação**: Você ou sua equipe gera um link de pagamento/doação através da plataforma do Mercado Pago.
2.  **Compartilhamento com o Doador**: O link é compartilhado com o interessado em doar, via e-mail, chat ou outro canal de comunicação direto.
3.  **Realização da Doação**: O doador utiliza o link para efetuar a doação via Mercado Pago.
4.  **Envio do Comprovante**: O doador envia o comprovante da transação para você, por exemplo, via e-mail ou um formulário específico no site.
5.  **Verificação e Interação Manual**: Você acessa sua conta do Mercado Pago para confirmar a doação e, crucialmente, **interage diretamente com o doador**. Este é o momento para agradecer, entender suas motivações e fortalecer o relacionamento.
6.  **Registro no Painel Administrativo**: No painel de administração do MercadoPlast (`frontend/admin`), você pode registrar a doação, atualizar o status, e gerenciar qualquer benefício ou reconhecimento associado. As páginas como `PaymentsPage` e `KYCReviewPage` (se aplicável para doadores) podem ser adaptadas para este gerenciamento.

Este fluxo garante que cada doação seja uma oportunidade para construir uma comunidade e manter o propósito humanitário do MercadoPlast no centro das operações.

## 8. Próximos Passos e Prioridades

### CRÍTICO:

*   **Preencher `.env.example`**: Atualizar o `backend/.env.example` com todas as variáveis de ambiente necessárias e seus placeholders, garantindo que todas as chaves secretas sejam geradas e armazenadas no Secret Manager.
*   **Configurar Cloud SQL**: Criar e configurar a instância do Cloud SQL (PostgreSQL) e garantir que o `DATABASE_URL` esteja correto.
*   **Testar `cloudbuild.yaml` e `Dockerfile`**: Executar os builds de teste para backend e ambos os frontends para garantir que as imagens sejam construídas e enviadas corretamente.

### IMPORTANTE:

*   **Frontend App Principal**: Confirmar que a aplicação `frontend/app` está completa e funcional.
*   **Documentação de Deploy**: Manter este `README_DEPLOY.md` atualizado com quaisquer mudanças ou informações adicionais.

Com estes arquivos e configurações, o projeto MercadoPlast estará pronto para um deploy robusto e escalável no Google Cloud Platform, com um fluxo de doação que prioriza a interação humana.
