/**
 * Jest tests for the payment flow. These tests ensure that the payment
 * endpoints enforce donation tiers, validate hashes, and apply rate
 * limiting. They should be run with a test database and appropriate
 * environment variables set. Use jest and supertest to perform HTTP
 * requests against the Express app.
 */
import request from 'supertest';
import app from '../src/index';

describe('Payment flow', () => {
  it('should reject payments with invalid tier', async () => {
    const agent = request(app);
    // Assuming we have a way to authenticate and obtain a JWT
    const jwt = 'test.jwt.token';
    const res = await agent
      .post('/api/payments/create-link')
      .set('Authorization', `Bearer ${jwt}`)
      .send({ tier: 'invalid' });
    expect(res.status).toBe(400);
  });
  // Additional tests would cover successful link creation, confirmation,
  // rate limiting, and security checks.
});