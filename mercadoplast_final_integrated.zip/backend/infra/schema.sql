-- habilitar uuid
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Tipos ENUM para papéis de usuário
CREATE TYPE user_role AS ENUM (
  'user',
  'admin',
  'moderator',
  'analyst'
);

-- Tipos ENUM para status de posts
CREATE TYPE post_status AS ENUM (
  'draft',
  'published',
  'archived'
);

-- Tipos ENUM para status de requisições KYC
CREATE TYPE kyc_status AS ENUM (
  'pending',
  'approved',
  'rejected'
);

-- Tipos ENUM para tipos de conta KYC
CREATE TYPE kyc_account_type AS ENUM (
  'pf',
  'pj'
);

-- Tipos ENUM para status de pagamentos
CREATE TYPE payment_status AS ENUM (
  'pending',
  'completed',
  'failed',
  'refunded'
);

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role user_role NOT NULL DEFAULT 'user', -- Usando o tipo ENUM
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE IF NOT EXISTS posts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  status post_status NOT NULL DEFAULT 'published', -- Usando o tipo ENUM
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE IF NOT EXISTS kyc_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  account_type kyc_account_type NOT NULL DEFAULT 'pf', -- Usando o tipo ENUM
  documents JSONB NOT NULL,
  status kyc_status NOT NULL DEFAULT 'pending', -- Usando o tipo ENUM
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE IF NOT EXISTS payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  status payment_status NOT NULL DEFAULT 'pending', -- Usando o tipo ENUM
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);



CREATE TABLE IF NOT EXISTS token_denylist (
  token TEXT PRIMARY KEY,
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL
);



CREATE TABLE IF NOT EXISTS refresh_tokens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  token TEXT NOT NULL UNIQUE,
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);




-- Índices para a tabela users
CREATE INDEX IF NOT EXISTS idx_users_email ON users (email);
CREATE INDEX IF NOT EXISTS idx_users_username ON users (username);

-- Índices para a tabela posts
CREATE INDEX IF NOT EXISTS idx_posts_user_id ON posts (user_id);
CREATE INDEX IF NOT EXISTS idx_posts_status ON posts (status);

-- Índices para a tabela kyc_requests
CREATE INDEX IF NOT EXISTS idx_kyc_requests_user_id ON kyc_requests (user_id);
CREATE INDEX IF NOT EXISTS idx_kyc_requests_status ON kyc_requests (status);

-- Índices para a tabela payments
CREATE INDEX IF NOT EXISTS idx_payments_user_id ON payments (user_id);
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments (status);

-- Índices para a tabela token_denylist
CREATE INDEX IF NOT EXISTS idx_token_denylist_expires_at ON token_denylist (expires_at);

-- Índices para a tabela refresh_tokens
CREATE INDEX IF NOT EXISTS idx_refresh_tokens_user_id ON refresh_tokens (user_id);
CREATE INDEX IF NOT EXISTS idx_refresh_tokens_expires_at ON refresh_tokens (expires_at);





-- Tabela para Polímeros
CREATE TABLE IF NOT EXISTS polymers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  acronym TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL UNIQUE,
  description TEXT
);

-- Índice para a tabela polymers
CREATE INDEX IF NOT EXISTS idx_polymers_acronym ON polymers (acronym);
CREATE INDEX IF NOT EXISTS idx_polymers_name ON polymers (name);




-- Tipos ENUM para tipos de anúncios
CREATE TYPE advertisement_type AS ENUM (
  'product',
  'service',
  'equipment',
  'transport'
);

-- Tabela para Anúncios
CREATE TABLE IF NOT EXISTS advertisements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  image_url TEXT NOT NULL,
  target_url TEXT NOT NULL,
  type advertisement_type NOT NULL,
  category TEXT NOT NULL,
  location TEXT,
  price TEXT,
  target_audience TEXT[] NOT NULL,
  budget NUMERIC(12,2) NOT NULL DEFAULT 0,
  duration INTEGER NOT NULL DEFAULT 30, -- dias
  active BOOLEAN NOT NULL DEFAULT true,
  click_count INTEGER NOT NULL DEFAULT 0,
  impression_count INTEGER NOT NULL DEFAULT 0,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Tabela para Cliques em Anúncios (Analytics)
CREATE TABLE IF NOT EXISTS ad_clicks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ad_id UUID REFERENCES advertisements(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id),
  source TEXT, -- 'sidebar', 'feed', 'post-details'
  clicked_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Tabela para Impressões de Anúncios (Analytics)
CREATE TABLE IF NOT EXISTS ad_impressions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ad_id UUID REFERENCES advertisements(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id),
  source TEXT, -- 'sidebar', 'feed', 'post-details'
  viewed_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Índices para a tabela advertisements
CREATE INDEX IF NOT EXISTS idx_advertisements_type ON advertisements (type);
CREATE INDEX IF NOT EXISTS idx_advertisements_category ON advertisements (category);
CREATE INDEX IF NOT EXISTS idx_advertisements_active ON advertisements (active);
CREATE INDEX IF NOT EXISTS idx_advertisements_created_by ON advertisements (created_by);
CREATE INDEX IF NOT EXISTS idx_advertisements_location ON advertisements (location);

-- Índices para a tabela ad_clicks
CREATE INDEX IF NOT EXISTS idx_ad_clicks_ad_id ON ad_clicks (ad_id);
CREATE INDEX IF NOT EXISTS idx_ad_clicks_user_id ON ad_clicks (user_id);
CREATE INDEX IF NOT EXISTS idx_ad_clicks_clicked_at ON ad_clicks (clicked_at);

-- Índices para a tabela ad_impressions
CREATE INDEX IF NOT EXISTS idx_ad_impressions_ad_id ON ad_impressions (ad_id);
CREATE INDEX IF NOT EXISTS idx_ad_impressions_user_id ON ad_impressions (user_id);
CREATE INDEX IF NOT EXISTS idx_ad_impressions_viewed_at ON ad_impressions (viewed_at);

-- Additional analytics tables for more detailed tracking and auditing
CREATE TABLE IF NOT EXISTS user_analytics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  activity_type TEXT NOT NULL,
  details JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_user_analytics_user_id ON user_analytics(user_id);
CREATE INDEX IF NOT EXISTS idx_user_analytics_created_at ON user_analytics(created_at);

CREATE TABLE IF NOT EXISTS post_analytics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id UUID REFERENCES posts(id) ON DELETE CASCADE,
  event_type TEXT NOT NULL,
  details JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_post_analytics_post_id ON post_analytics(post_id);
CREATE INDEX IF NOT EXISTS idx_post_analytics_created_at ON post_analytics(created_at);

CREATE TABLE IF NOT EXISTS admin_audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id UUID REFERENCES users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  target_type TEXT NOT NULL,
  target_id UUID,
  details JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_admin_audit_log_admin_id ON admin_audit_log(admin_id);
CREATE INDEX IF NOT EXISTS idx_admin_audit_log_created_at ON admin_audit_log(created_at);

