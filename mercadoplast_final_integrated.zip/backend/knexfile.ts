import type { Knex } from 'knex';
import dotenv from 'dotenv';

dotenv.config();

const config: { [key: string]: Knex.Config } = {
  development: {
    client: 'pg',
    connection: process.env.DATABASE_URL,
    // Use a connection pool for improved performance in development
    pool: {
      min: 2,
      max: 20,
      idleTimeoutMillis: 30000,
      createTimeoutMillis: 2000,
      acquireTimeoutMillis: 2000
    },
    migrations: {
      directory: './db/migrations',
      extension: 'ts'
    },
    seeds: {
      directory: './db/seeds',
      extension: 'ts'
    }
  },

  production: {
    client: 'pg',
    connection: process.env.DATABASE_URL,
    // Use a larger pool in production to handle concurrent connections
    pool: {
      min: 2,
      max: 20,
      idleTimeoutMillis: 30000,
      createTimeoutMillis: 2000,
      acquireTimeoutMillis: 2000
    },
    migrations: {
      directory: './db/migrations',
      extension: 'ts'
    },
    seeds: {
      directory: './db/seeds',
      extension: 'ts'
    }
  }
};

module.exports = config;