#!/bin/bash

set -e

echo "Iniciando setup do backend MercadoPlast..."

# Verificar se as variáveis de ambiente essenciais estão definidas
if [ -z "$DATABASE_URL" ]; then
  echo "Erro: DATABASE_URL não definida."
  exit 1
fi

if [ -z "$JWT_SECRET" ]; then
  echo "Erro: JWT_SECRET não definida."
  exit 1
fi

# Instalar dependências (se não for feito no Dockerfile ou para ambiente local)
# npm install

# Executar migrações do banco de dados
echo "Executando migrações do banco de dados..."
npx knex migrate:latest --knexfile knexfile.ts

# Executar seeds (apenas em ambientes de desenvolvimento/teste, ou com cautela em produção)
# if [ "$NODE_ENV" == "development" ]; then
#   echo "Executando seeds do banco de dados..."
#   npx knex seed:run --knexfile knexfile.ts
# fi

echo "Setup do backend MercadoPlast concluído com sucesso."

