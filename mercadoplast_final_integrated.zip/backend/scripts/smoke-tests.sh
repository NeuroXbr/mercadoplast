#!/usr/bin/env bash

# This script performs a series of API calls against a running MercadoPlast
# backend to verify that the core endpoints are functioning correctly. It
# requires jq to parse JSON responses. You can pass a base URL as the first
# argument (default http://localhost:8080/api). An optional JWT can be
# provided as the second argument for authenticated routes.

set -euo pipefail

BASE_URL=${1:-http://localhost:8080/api}
JWT=${2:-}

headerAuth=""
if [[ -n "$JWT" ]]; then
  headerAuth="Authorization: Bearer $JWT"
fi

echo "== Health check =="
curl -s "$BASE_URL/../health" | jq . || true

echo "\n== List first page of payments (admin required) =="
if [[ -n "$JWT" ]]; then
  curl -s -H "$headerAuth" "$BASE_URL/payments?page=1&pageSize=5" | jq . || true
else
  echo "Skipped: JWT not provided"
fi

echo "\n== Payment stats =="
if [[ -n "$JWT" ]]; then
  curl -s -H "$headerAuth" "$BASE_URL/payments/stats" | jq . || true
else
  echo "Skipped: JWT not provided"
fi

echo "\n== Create payment link (basic tier) =="
if [[ -n "$JWT" ]]; then
  resp=$(curl -s -H "$headerAuth" -H "Content-Type: application/json" -d '{"tier":"basic"}' "$BASE_URL/payments/create-link")
  echo "$resp" | jq . || true
else
  echo "Skipped: JWT not provided"
fi

# Additional tests can be added here (e.g. confirm payment)