import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  // Alterar tabela kyc_requests
  await knex.schema.alterTable('kyc_requests', (table) => {
    table.text('review_note').nullable();
    table.uuid('reviewed_by').nullable().references('id').inTable('users').onDelete('SET NULL');
    table.timestamp('reviewed_at').nullable();
    
    // Adicionar índices
    table.index(['status']);
    table.index(['user_id', 'status']);
  });
  
  // Alterar tabela users
  await knex.schema.alterTable('users', (table) => {
    table.string('kyc_status', 20).notNullable().defaultTo('pending');
    table.boolean('premium').notNullable().defaultTo(false);
  });
  
  // Alterar tabela payments
  await knex.schema.alterTable('payments', (table) => {
    table.string('payment_method', 20).defaultTo('pix');
    table.text('proof_url').nullable();
    table.uuid('confirmed_by').nullable().references('id').inTable('users').onDelete('SET NULL');
    table.timestamp('confirmed_at').nullable();
    table.text('failure_reason').nullable();
    table.text('description').nullable();
    
    // Adicionar índices
    table.index(['status']);
    table.index(['user_id', 'status']);
    table.index(['created_at']);
  });
  
  // Alterar tabela advertisements
  await knex.schema.alterTable('advertisements', (table) => {
    table.boolean('active').notNullable().defaultTo(true);
    
    // Adicionar índices
    table.index(['active']);
    table.index(['created_at']);
  });
}

export async function down(knex: Knex): Promise<void> {
  // Reverter alterações em kyc_requests
  await knex.schema.alterTable('kyc_requests', (table) => {
    table.dropColumn('review_note');
    table.dropColumn('reviewed_by');
    table.dropColumn('reviewed_at');
    table.dropIndex(['status']);
    table.dropIndex(['user_id', 'status']);
  });
  
  // Reverter alterações em users
  await knex.schema.alterTable('users', (table) => {
    table.dropColumn('kyc_status');
    table.dropColumn('premium');
  });
  
  // Reverter alterações em payments
  await knex.schema.alterTable('payments', (table) => {
    table.dropColumn('payment_method');
    table.dropColumn('proof_url');
    table.dropColumn('confirmed_by');
    table.dropColumn('confirmed_at');
    table.dropColumn('failure_reason');
    table.dropColumn('description');
    table.dropIndex(['status']);
    table.dropIndex(['user_id', 'status']);
    table.dropIndex(['created_at']);
  });
  
  // Reverter alterações em advertisements
  await knex.schema.alterTable('advertisements', (table) => {
    table.dropColumn('active');
    table.dropIndex(['active']);
    table.dropIndex(['created_at']);
  });
}