import { Knex } from 'knex';

/*
 * Migration to create the payment_audit_log table.
 * This table records all actions performed on payments for full auditability.
 */

export async function up(knex: Knex): Promise<void> {
  return knex.schema.createTable('payment_audit_log', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table
      .uuid('payment_id')
      .notNullable()
      .references('id')
      .inTable('payments')
      .onDelete('CASCADE');
    table.string('action').notNullable();
    table
      .uuid('admin_id')
      .nullable()
      .references('id')
      .inTable('users');
    table.string('ip_address').nullable();
    table.string('user_agent').nullable();
    table.timestamp('timestamp').defaultTo(knex.fn.now());
  });
}

export async function down(knex: Knex): Promise<void> {
  return knex.schema.dropTableIfExists('payment_audit_log');
}