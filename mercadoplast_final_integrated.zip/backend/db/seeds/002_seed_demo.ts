import { Knex } from 'knex';

/*
 * This seed file populates the database with additional demo data.
 * It should be executed after the base seed (001_seed_initial.ts) to
 * provide rich example data for development and demonstrations. It does not
 * remove or overwrite existing data. Feel free to adjust quantities and
 * values as needed.
 */

export async function seed(knex: Knex): Promise<void> {
  // Seed extra advertisements
  const adminUser = await knex('users').where({ email: 'admin@mercadoplast.com' }).first();
  const adminId = adminUser?.id;

  for (let i = 0; i < 10; i++) {
    await knex('advertisements').insert({
      id: knex.raw('gen_random_uuid()'),
      title: `Anúncio Demo ${i + 1}`,
      description: 'Conteúdo demonstrativo para fins de teste e analytics.',
      image_url: 'https://via.placeholder.com/600x300',
      link_url: 'https://example.com/demo',
      type: 'banner',
      category: 'demo',
      budget: 500 + i * 25,
      active: i % 2 === 0,
      clicks: 100 + i * 5,
      impressions: 2000 + i * 100,
      created_by: adminId,
      created_at: knex.fn.now(),
      updated_at: knex.fn.now()
    });
  }

  // Seed extra posts (polymers)
  const normalUser = await knex('users').where({ email: 'user@mercadoplast.com' }).first();
  const userId = normalUser?.id;
  for (let i = 0; i < 20; i++) {
    await knex('posts').insert({
      id: knex.raw('gen_random_uuid()'),
      user_id: userId,
      title: `Lote de polímero #${i + 1}`,
      content: 'Lote de demonstração para gráficos e listagens.',
      type: 'venda',
      price: 1000 + i * 50,
      quantity: 100 + i * 10,
      unit: 'kg',
      location: 'São Paulo - SP',
      status: 'active',
      views: 50 + i * 3,
      created_at: knex.fn.now(),
      updated_at: knex.fn.now()
    });
  }

  // Seed extra payments with various statuses
  const statuses = ['pending', 'completed', 'failed'] as const;
  for (let i = 0; i < 15; i++) {
    const status = statuses[i % statuses.length];
    await knex('payments').insert({
      id: knex.raw('gen_random_uuid()'),
      user_id: userId,
      amount: 20 + i,
      status,
      external_id: `DEMO_${i + 1}`,
      payment_method: i % 2 === 0 ? 'pix' : 'credit_card',
      description: 'Plano Premium - Demo',
      confirmed_at: status === 'completed' ? knex.fn.now() : null,
      confirmed_by: status === 'completed' ? adminId : null,
      created_at: knex.fn.now(),
      updated_at: knex.fn.now()
    });
  }
}