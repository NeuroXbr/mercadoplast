import { Knex } from 'knex';
import bcrypt from 'bcryptjs';

export async function seed(knex: Knex): Promise<void> {
  // Limpar tabelas em ordem correta (respeitando FKs)
  await knex('kyc_requests').del();
  await knex('payments').del();
  await knex('advertisements').del();
  await knex('posts').del();
  await knex('users').del();
  
  // Criar usuários
  const adminPassword = await bcrypt.hash('Admin123!', 10);
  const userPassword = await bcrypt.hash('User123!', 10);
  
  const [adminUser, normalUser] = await knex('users')
    .insert([
      {
        id: knex.raw('gen_random_uuid()'),
        email: 'admin@mercadoplast.com',
        password: adminPassword,
        name: 'Admin MercadoPlast',
        role: 'admin',
        kyc_status: 'approved',
        premium: true,
        created_at: knex.fn.now(),
        updated_at: knex.fn.now()
      },
      {
        id: knex.raw('gen_random_uuid()'),
        email: 'user@mercadoplast.com',
        password: userPassword,
        name: 'User Test',
        role: 'user',
        kyc_status: 'pending',
        premium: false,
        created_at: knex.fn.now(),
        updated_at: knex.fn.now()
      }
    ])
    .returning(['id', 'email']);
  
  // Criar KYC request pendente para o usuário comum
  await knex('kyc_requests').insert({
    id: knex.raw('gen_random_uuid()'),
    user_id: normalUser.id,
    document_type: 'RG',
    document_number: '123456789',
    document_url: 'kyc/user-test/rg-frente.pdf',
    selfie_url: 'kyc/user-test/selfie.jpg',
    status: 'pending',
    created_at: knex.fn.now()
  });
  
  // Criar pagamento pendente
  await knex('payments').insert({
    id: knex.raw('gen_random_uuid()'),
    user_id: normalUser.id,
    amount: 199.90,
    status: 'pending',
    external_id: 'MP-TEST-12345',
    payment_method: 'pix',
    description: 'Premium MercadoPlast',
    created_at: knex.fn.now()
  });
  
  // Criar anúncio ativo
  await knex('advertisements').insert({
    id: knex.raw('gen_random_uuid()'),
    title: 'Plásticos Reciclados Premium',
    description: 'Os melhores plásticos reciclados do mercado',
    image_url: 'https://example.com/plastico-premium.jpg',
    link_url: 'https://mercadoplast.com/premium',
    type: 'banner',
    category: 'reciclagem',
    budget: 1000.00,
    active: true,
    clicks: 0,
    impressions: 0,
    created_by: adminUser.id,
    created_at: knex.fn.now(),
    updated_at: knex.fn.now()
  });
  
  // Criar um post de exemplo
  await knex('posts').insert({
    id: knex.raw('gen_random_uuid()'),
    user_id: normalUser.id,
    title: 'Vendo PET reciclado',
    content: 'Tenho 500kg de PET reciclado disponível para venda imediata.',
    type: 'venda',
    price: 2500.00,
    quantity: 500,
    unit: 'kg',
    location: 'São Paulo - SP',
    status: 'active',
    views: 0,
    created_at: knex.fn.now(),
    updated_at: knex.fn.now()
  });
  
  console.log('Seed inicial executado com sucesso!');
  console.log('Usuários criados:');
  console.log('- admin@mercadoplast.com (senha: Admin123!)');
  console.log('- user@mercadoplast.com (senha: User123!)');
}