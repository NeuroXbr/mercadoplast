import { ZodSchema, ZodError } from 'zod';

/**
 * Validate an object against a Zod schema and return the parsed result. If
 * validation fails, an error is thrown with a standardized message.
 *
 * @param schema Zod schema to parse against
 * @param data Raw data to validate
 * @returns Parsed data typed according to the schema
 */
export function validate<T>(schema: ZodSchema<T>, data: unknown): T {
  try {
    return schema.parse(data);
  } catch (error) {
    if (error instanceof ZodError) {
      // Transform ZodError into a consistent format
      throw new Error(error.errors.map((e) => e.message).join('; '));
    }
    throw error;
  }
}