import { query } from '../database';

export async function addTokenToDenylist(token: string, expiresAt: Date) {
  await query('INSERT INTO token_denylist (token, expires_at) VALUES ($1, $2)', [token, expiresAt]);
}

export async function isTokenInDenylist(token: string): Promise<boolean> {
  const { rows } = await query('SELECT 1 FROM token_denylist WHERE token = $1 AND expires_at > NOW()', [token]);
  return rows.length > 0;
}

