import crypto from 'crypto';

/**
 * Generate a SHA-256 hash for a payment record. This hash can be used to
 * validate that the payment parameters have not been tampered with.
 *
 * @param paymentId ID of the payment in the database
 * @param externalId External reference ID (e.g. Mercado Pago preference ID)
 * @param secret Secret key from PAYMENT_SECRET environment variable
 * @returns A hex-encoded SHA-256 hash
 */
export function generatePaymentHash(paymentId: string, externalId: string, secret: string): string {
  return crypto
    .createHash('sha256')
    .update(`${paymentId}:${externalId}:${secret}`)
    .digest('hex');
}