import { query } from '../database';

export async function createRefreshToken(userId: string, token: string, expiresAt: Date) {
  await query('INSERT INTO refresh_tokens (user_id, token, expires_at) VALUES ($1, $2, $3)', [userId, token, expiresAt]);
}

export async function getRefreshToken(token: string) {
  const { rows } = await query('SELECT * FROM refresh_tokens WHERE token = $1 AND expires_at > NOW()', [token]);
  return rows[0];
}

export async function deleteRefreshToken(token: string) {
  await query('DELETE FROM refresh_tokens WHERE token = $1', [token]);
}


