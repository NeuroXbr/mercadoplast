import { Request, Response, NextFunction } from 'express';

interface LogEntry {
  timestamp: string;
  method: string;
  url: string;
  ip: string;
  userAgent: string;
  userId?: string;
  statusCode?: number;
  responseTime?: number;
  error?: string;
}

class RequestLogger {
  private logs: LogEntry[] = [];
  private maxLogs = 10000; // Manter apenas os últimos 10k logs em memória

  log(entry: LogEntry) {
    this.logs.push(entry);
    
    // Manter apenas os logs mais recentes
    if (this.logs.length > this.maxLogs) {
      this.logs = this.logs.slice(-this.maxLogs);
    }
    
    // Em produção, enviar para serviço de logging (ex: Winston, CloudWatch)
    if (process.env.NODE_ENV === 'production') {
      console.log(JSON.stringify(entry));
    } else {
      console.log(`${entry.timestamp} ${entry.method} ${entry.url} - ${entry.statusCode} - ${entry.responseTime}ms`);
    }
  }

  getRecentLogs(limit = 100): LogEntry[] {
    return this.logs.slice(-limit);
  }

  getErrorLogs(limit = 50): LogEntry[] {
    return this.logs
      .filter(log => log.statusCode && log.statusCode >= 400)
      .slice(-limit);
  }

  getSlowRequests(threshold = 1000, limit = 50): LogEntry[] {
    return this.logs
      .filter(log => log.responseTime && log.responseTime > threshold)
      .slice(-limit);
  }

  getUserActivity(userId: string, limit = 100): LogEntry[] {
    return this.logs
      .filter(log => log.userId === userId)
      .slice(-limit);
  }

  getStats() {
    const now = Date.now();
    const oneHourAgo = now - (60 * 60 * 1000);
    const recentLogs = this.logs.filter(log => 
      new Date(log.timestamp).getTime() > oneHourAgo
    );

    const statusCounts = recentLogs.reduce((acc, log) => {
      if (log.statusCode) {
        const statusGroup = Math.floor(log.statusCode / 100) * 100;
        acc[statusGroup] = (acc[statusGroup] || 0) + 1;
      }
      return acc;
    }, {} as Record<number, number>);

    const avgResponseTime = recentLogs
      .filter(log => log.responseTime)
      .reduce((sum, log) => sum + (log.responseTime || 0), 0) / recentLogs.length;

    return {
      totalRequests: recentLogs.length,
      statusCounts,
      averageResponseTime: Math.round(avgResponseTime || 0),
      errorRate: ((statusCounts[400] || 0) + (statusCounts[500] || 0)) / recentLogs.length * 100
    };
  }
}

const logger = new RequestLogger();

export const requestLogger = (req: Request, res: Response, next: NextFunction) => {
  const startTime = Date.now();
  
  const logEntry: LogEntry = {
    timestamp: new Date().toISOString(),
    method: req.method,
    url: req.originalUrl,
    ip: req.ip || 'unknown',
    userAgent: req.get('User-Agent') || 'unknown',
    userId: req.user?.id
  };

  // Interceptar o final da resposta
  const originalSend = res.send;
  res.send = function(data) {
    logEntry.statusCode = res.statusCode;
    logEntry.responseTime = Date.now() - startTime;
    
    // Capturar erros se houver
    if (res.statusCode >= 400) {
      try {
        const errorData = JSON.parse(data);
        logEntry.error = errorData.error || errorData.message;
      } catch {
        // Ignorar se não conseguir parsear
      }
    }
    
    logger.log(logEntry);
    return originalSend.call(this, data);
  };

  next();
};

// Middleware para expor estatísticas (apenas para admins)
export const getLogStats = (req: Request, res: Response) => {
  try {
    const stats = logger.getStats();
    res.json(stats);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao obter estatísticas' });
  }
};

// Middleware para obter logs recentes (apenas para admins)
export const getRecentLogs = (req: Request, res: Response) => {
  try {
    const { limit = '100', type = 'all' } = req.query;
    const limitNum = parseInt(limit as string);
    
    let logs;
    switch (type) {
      case 'errors':
        logs = logger.getErrorLogs(limitNum);
        break;
      case 'slow':
        logs = logger.getSlowRequests(1000, limitNum);
        break;
      default:
        logs = logger.getRecentLogs(limitNum);
    }
    
    res.json({ logs, total: logs.length });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao obter logs' });
  }
};

export { logger };

