import { Request, Response, NextFunction } from 'express';

export const authorizeRoles = (allowedRoles: string[]) => {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ 
        error: 'Forbidden', 
        message: 'You do not have permission to access this resource' 
      });
    }
    
    next();
  };
};

// Alias úteis
export const requireAdmin = authorizeRoles(['admin']);
export const requireModerator = authorizeRoles(['admin', 'moderator']);
export const requireAnalyst = authorizeRoles(['admin', 'moderator', 'analyst']);