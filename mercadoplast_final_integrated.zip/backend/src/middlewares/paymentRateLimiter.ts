import { Request } from 'express';
import { createRateLimit } from './rateLimiter';

/**
 * Rate limiter specifically for payment-related endpoints. By default it
 * allows MAX_PAYMENT_ATTEMPTS requests per window (15 minutes) per user.
 * Configuration is derived from environment variables:
 * - MAX_PAYMENT_ATTEMPTS: number of allowed attempts (default 3)
 * - PAYMENT_RATE_LIMIT_WINDOW_MS: window duration in ms (default 15 minutes)
 */
const windowMs = Number(process.env.PAYMENT_RATE_LIMIT_WINDOW_MS || 15 * 60 * 1000);
const max = Number(process.env.MAX_PAYMENT_ATTEMPTS || 3);

export const paymentRateLimiter = createRateLimit({
  windowMs,
  maxRequests: max,
  message: 'Muitas tentativas de pagamento. Tente novamente mais tarde.',
  keyGenerator: (req: Request) => {
    // If the user is authenticated, use the user ID as part of the key to avoid rate limiting
    // all users by IP. If not authenticated, fallback to IP.
    return `payment:${req.user?.id || req.ip}`;
  }
});