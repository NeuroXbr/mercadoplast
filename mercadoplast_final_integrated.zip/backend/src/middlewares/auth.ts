import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { UserRole } from '../constants/roles';
import { isTokenInDenylist } from '../utils/tokenDenylist';
import { AppError } from './errorHandler';

export interface AuthenticatedRequest extends Request {
  user?: { id: string; role: UserRole };
}

export async function authenticateJWT(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) return next(new AppError('Missing token', 401));
  const token = header.substring('Bearer '.length);

  if (await isTokenInDenylist(token)) {
    return next(new AppError('Token revoked', 401));
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!);
    req.user = decoded as any;
    next();
  } catch (err) {
    return next(new AppError('Invalid token', 401));
  }
}

export function requireRole(...roles: UserRole[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    if (!req.user || !roles.includes(req.user.role)) return next(new AppError('Forbidden', 403));
    next();
  };
}


