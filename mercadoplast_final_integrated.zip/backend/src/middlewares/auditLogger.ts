import { Request, Response, NextFunction } from 'express';
import knex from '../database';

/**
 * Helper to insert an audit log entry for a payment action. This is not a
 * middleware by itself, but a function that controllers can call after
 * completing an operation. It records who performed the action, on which
 * payment, and captures the client IP and user agent for traceability.
 *
 * @param req Express request (used for ip and user agent)
 * @param paymentId The ID of the payment that was affected
 * @param action A string describing the action (e.g. 'CREATED', 'CONFIRMED', 'FAILED')
 * @param adminId The ID of the admin performing the operation (may be undefined)
 */
export async function auditLog(
  req: Request,
  paymentId: string,
  action: string,
  adminId?: string
): Promise<void> {
  await knex('payment_audit_log').insert({
    payment_id: paymentId,
    action,
    admin_id: adminId,
    ip_address: req.ip,
    user_agent: req.get('User-Agent'),
    timestamp: knex.fn.now()
  });
}