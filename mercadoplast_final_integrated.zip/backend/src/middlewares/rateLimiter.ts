import { Request, Response, NextFunction } from 'express';

interface RateLimitStore {
  [key: string]: {
    count: number;
    resetTime: number;
  };
}

const store: RateLimitStore = {};

// Limpar entradas expiradas a cada 5 minutos
setInterval(() => {
  const now = Date.now();
  Object.keys(store).forEach(key => {
    if (store[key].resetTime < now) {
      delete store[key];
    }
  });
}, 5 * 60 * 1000);

export interface RateLimitOptions {
  windowMs: number; // Janela de tempo em milissegundos
  maxRequests: number; // Máximo de requisições por janela
  message?: string; // Mensagem de erro personalizada
  keyGenerator?: (req: Request) => string; // Função para gerar a chave única
}

export const createRateLimit = (options: RateLimitOptions) => {
  const {
    windowMs,
    maxRequests,
    message = 'Muitas requisições. Tente novamente mais tarde.',
    keyGenerator = (req: Request) => req.ip || 'unknown'
  } = options;

  return (req: Request, res: Response, next: NextFunction) => {
    const key = keyGenerator(req);
    const now = Date.now();
    
    // Inicializar ou resetar contador se a janela expirou
    if (!store[key] || store[key].resetTime < now) {
      store[key] = {
        count: 1,
        resetTime: now + windowMs
      };
      return next();
    }
    
    // Incrementar contador
    store[key].count++;
    
    // Verificar se excedeu o limite
    if (store[key].count > maxRequests) {
      const resetTime = Math.ceil((store[key].resetTime - now) / 1000);
      
      res.set({
        'X-RateLimit-Limit': maxRequests.toString(),
        'X-RateLimit-Remaining': '0',
        'X-RateLimit-Reset': resetTime.toString()
      });
      
      return res.status(429).json({
        error: 'Rate limit exceeded',
        message,
        retryAfter: resetTime
      });
    }
    
    // Adicionar headers informativos
    res.set({
      'X-RateLimit-Limit': maxRequests.toString(),
      'X-RateLimit-Remaining': (maxRequests - store[key].count).toString(),
      'X-RateLimit-Reset': Math.ceil((store[key].resetTime - now) / 1000).toString()
    });
    
    next();
  };
};

// Rate limiters pré-configurados
export const authRateLimit = createRateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  maxRequests: 5, // 5 tentativas de login por IP
  message: 'Muitas tentativas de login. Tente novamente em 15 minutos.',
  keyGenerator: (req: Request) => `auth:${req.ip}`
});

export const apiRateLimit = createRateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  maxRequests: 100, // 100 requisições por IP
  message: 'Limite de requisições excedido. Tente novamente em alguns minutos.'
});

export const uploadRateLimit = createRateLimit({
  windowMs: 60 * 60 * 1000, // 1 hora
  maxRequests: 10, // 10 uploads por hora
  message: 'Limite de uploads excedido. Tente novamente em 1 hora.',
  keyGenerator: (req: Request) => `upload:${req.user?.id || req.ip}`
});

export const searchRateLimit = createRateLimit({
  windowMs: 60 * 1000, // 1 minuto
  maxRequests: 30, // 30 buscas por minuto
  message: 'Muitas buscas realizadas. Aguarde um momento.',
  keyGenerator: (req: Request) => `search:${req.user?.id || req.ip}`
});

