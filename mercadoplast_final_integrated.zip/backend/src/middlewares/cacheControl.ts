import { Request, Response, NextFunction } from 'express';

export const setCache = (duration: number) => (req: Request, res: Response, next: NextFunction) => {
  if (req.method === 'GET') {
    res.set('Cache-Control', `public, max-age=${duration}`);
  } else {
    res.set('Cache-Control', 'no-store');
  }
  next();
};

