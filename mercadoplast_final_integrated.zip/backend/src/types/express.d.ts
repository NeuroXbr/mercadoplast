// Extend the Express Request type with a `user` property.
// This allows middleware and controllers to safely access the authenticated user
// information attached during JWT authentication.

declare module 'express-serve-static-core' {
  interface Request {
    /**
     * Authenticated user attached by the authentication middleware.
     * If present, contains at least an `id` property and may include other
     * user fields depending on the auth implementation.
     */
    user?: {
      id: string;
      email?: string;
      name?: string;
      role?: string;
      [key: string]: unknown;
    };
  }
}