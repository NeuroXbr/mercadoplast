import { Request, Response, NextFunction } from 'express';
import knex from '../database';
import { getCache, setCache, delCache } from '../services/cacheService';

export const listAds = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { active = true, page = 1, pageSize = 20 } = req.query;
    const offset = (Number(page) - 1) * Number(pageSize);
    const activeBool = active === 'true' || active === true;
    const cacheKey = `ads:list:${activeBool}:${page}:${pageSize}`;
    // Attempt to read from cache
    const cached = await getCache<any>(cacheKey);
    if (cached) {
      return res.json(cached);
    }
    const query = knex('advertisements')
      .where('active', activeBool)
      .orderBy('created_at', 'desc')
      .limit(Number(pageSize))
      .offset(offset);
    const [items, totalResult] = await Promise.all([
      query,
      knex('advertisements').where('active', activeBool).count('* as total')
    ]);
    const responseData = {
      items,
      total: Number(totalResult[0].total),
      page: Number(page),
      pageSize: Number(pageSize)
    };
    // Cache the response for 5 minutes if active ads; 1 minute if inactive
    const ttl = activeBool ? 5 * 60 : 60;
    await setCache(cacheKey, responseData, ttl);
    res.json(responseData);
  } catch (error) {
    next(error);
  }
};

export const createAd = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const adData = req.body;
    
    const [ad] = await knex('advertisements')
      .insert({
        ...adData,
        created_by: req.user?.id,
        clicks: 0,
        impressions: 0
      })
      .returning('*');
    
    res.status(201).json(ad);
  } catch (error) {
    next(error);
  }
};

export const updateAd = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;
    const updates = req.body;
    
    const [ad] = await knex('advertisements')
      .where('id', id)
      .update({
        ...updates,
        updated_at: knex.fn.now()
      })
      .returning('*');
    
    if (!ad) {
      return res.status(404).json({ error: 'Advertisement not found' });
    }
    
    res.json(ad);
  } catch (error) {
    next(error);
  }
};

export const deleteAd = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;
    
    const deleted = await knex('advertisements')
      .where('id', id)
      .delete();
    
    if (!deleted) {
      return res.status(404).json({ error: 'Advertisement not found' });
    }
    
    res.status(204).send();
  } catch (error) {
    next(error);
  }
};

export const toggleAd = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;
    
    // Buscar estado atual
    const current = await knex('advertisements')
      .where('id', id)
      .select('active')
      .first();
    
    if (!current) {
      return res.status(404).json({ error: 'Advertisement not found' });
    }
    
    // Toggle
    const [updated] = await knex('advertisements')
      .where('id', id)
      .update({
        active: !current.active,
        updated_at: knex.fn.now()
      })
      .returning('*');
    
    res.json(updated);
  } catch (error) {
    next(error);
  }
};

export const getAdStats = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const [
      totalCount,
      activeCount,
      clicksSum,
      impressionsSum
    ] = await Promise.all([
      knex('advertisements').count('* as total'),
      knex('advertisements').where('active', true).count('* as total'),
      knex('advertisements').sum('clicks as total'),
      knex('advertisements').sum('impressions as total')
    ]);
    
    const clicks = Number(clicksSum[0].total || 0);
    const impressions = Number(impressionsSum[0].total || 0);
    const ctr = impressions > 0 ? clicks / impressions : 0;
    
    res.json({
      total: Number(totalCount[0].total),
      active: Number(activeCount[0].total),
      inactive: Number(totalCount[0].total) - Number(activeCount[0].total),
      clicks,
      impressions,
      ctr
    });
  } catch (error) {
    next(error);
  }
};

export const getAdById = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;
    
    const ad = await knex('advertisements')
      .where('id', id)
      .first();
    
    if (!ad) {
      return res.status(404).json({ error: 'Advertisement not found' });
    }
    
    res.json(ad);
  } catch (error) {
    next(error);
  }
};

export const recordClick = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;
    
    await knex('advertisements')
      .where('id', id)
      .increment('clicks', 1);
    
    res.json({ success: true });
  } catch (error) {
    next(error);
  }
};

export const recordImpression = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;
    
    await knex('advertisements')
      .where('id', id)
      .increment('impressions', 1);
    
    res.json({ success: true });
  } catch (error) {
    next(error);
  }
};

export const intelligentAds = async (req: Request, res: Response, next: NextFunction) => {
  try {
    // Implementação stub para anúncios inteligentes
    const ads = await knex('advertisements')
      .where('active', true)
      .orderBy('clicks', 'desc')
      .limit(5);
    
    res.json({ ads });
  } catch (error) {
    next(error);
  }
};