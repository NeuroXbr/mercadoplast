import { Request, Response, NextFunction } from 'express';
import knex from '../database';

export const getAdvancedAnalytics = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    // Métricas gerais
    const [
      usersTotal,
      revenueTotal,
      postsTotal,
      adsStats
    ] = await Promise.all([
      knex('users').count('* as total'),
      knex('payments')
        .where('status', 'completed')
        .sum('amount as total'),
      knex('posts').count('* as total'),
      knex('advertisements')
        .select(
          knex.raw('SUM(clicks) as clicks'),
          knex.raw('SUM(impressions) as impressions')
        )
        .first()
    ]);
    
    // Crescimento diário dos últimos 30 dias
    const dailyGrowth = await knex('users')
      .select(
        knex.raw('DATE(created_at) as date'),
        knex.raw('COUNT(*) as count')
      )
      .where('created_at', '>=', thirtyDaysAgo)
      .groupByRaw('DATE(created_at)')
      .orderBy('date', 'asc');
    
    const dailyRevenue = await knex('payments')
      .select(
        knex.raw('DATE(confirmed_at) as date'),
        knex.raw('SUM(amount) as revenue')
      )
      .where('status', 'completed')
      .where('confirmed_at', '>=', thirtyDaysAgo)
      .whereNotNull('confirmed_at')
      .groupByRaw('DATE(confirmed_at)')
      .orderBy('date', 'asc');
    
    // Calcular CTR
    const clicks = Number(adsStats.clicks || 0);
    const impressions = Number(adsStats.impressions || 0);
    const ctr = impressions > 0 ? clicks / impressions : 0;
    
    // Formatar séries temporais
    const growth_users_30d = dailyGrowth.map(row => ({
      date: row.date,
      count: Number(row.count)
    }));
    
    const growth_revenue_30d = dailyRevenue.map(row => ({
      date: row.date,
      revenue: Number(row.revenue)
    }));
    
    res.json({
      users_total: Number(usersTotal[0].total),
      revenue_total: Number(revenueTotal[0].total || 0),
      posts_total: Number(postsTotal[0].total),
      ctr,
      growth_users_30d,
      growth_revenue_30d
    });
  } catch (error) {
    next(error);
  }
};

export const getUserSegmentation = async (req: Request, res: Response, next: NextFunction) => {
  try {
    // Segmentação por roles
    const roleSegments = await knex('users')
      .select('role')
      .count('* as count')
      .groupBy('role');
    
    // Segmentação por premium
    const premiumSegments = await knex('users')
      .select('premium')
      .count('* as count')
      .groupBy('premium');
    
    // Formatar resposta
    const roles = {};
    roleSegments.forEach(segment => {
      roles[segment.role] = Number(segment.count);
    });
    
    const premium = {};
    premiumSegments.forEach(segment => {
      premium[segment.premium.toString()] = Number(segment.count);
    });
    
    res.json({ roles, premium });
  } catch (error) {
    next(error);
  }
};

export const getGeographicDistribution = async (req: Request, res: Response, next: NextFunction) => {
  try {
    // Mock de distribuição geográfica (simulando dados sintéticos)
    // Em produção, isso viria de dados reais de geolocalização
    const mockRegions = [
      { region: 'SP', users: 500 },
      { region: 'RJ', users: 200 },
      { region: 'MG', users: 150 },
      { region: 'RS', users: 100 },
      { region: 'PR', users: 80 },
      { region: 'BA', users: 70 },
      { region: 'PE', users: 50 },
      { region: 'SC', users: 45 },
      { region: 'CE', users: 40 },
      { region: 'Others', users: 65 }
    ];
    
    res.json({ regions: mockRegions });
  } catch (error) {
    next(error);
  }
};