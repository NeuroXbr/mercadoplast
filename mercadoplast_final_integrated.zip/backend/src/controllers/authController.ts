import { Request, Response, NextFunction } from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { query } from '../database';
import { AppError } from '../middlewares/errorHandler';
import { createRefreshToken, deleteRefreshToken, getRefreshToken } from '../utils/refreshToken';

const SALT_ROUNDS = 10;

export async function register(req: Request, res: Response, next: NextFunction) {
  const { username, email, password } = req.body || {};
  // Validação agora é feita pelo middleware validate(registerSchema)
  const hashed = await bcrypt.hash(password, SALT_ROUNDS);
  const sql = `INSERT INTO users (username, email, password_hash, role) VALUES ($1,$2,$3,'user') RETURNING id, username, email, role`;
  try {
    const { rows } = await query(sql, [username, email, hashed]);
    return res.status(201).json(rows[0]);
  } catch (error: any) {
    if (error.code === '23505') { // PostgreSQL unique violation error code
      return next(new AppError('Email or username already exists', 409));
    }
    next(error);
  }
}

export async function login(req: Request, res: Response, next: NextFunction) {
  const { email, password } = req.body || {};
  // Validação agora é feita pelo middleware validate(loginSchema)
  const { rows } = await query('SELECT id, email, username, password_hash, role FROM users WHERE email=$1', [email]);
  const user = rows[0];
  if (!user) return next(new AppError('Invalid credentials', 401));
  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return next(new AppError('Invalid credentials', 401));

  const accessToken = jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET!, { expiresIn: '15m' }); // Access token de curta duração
  const refreshToken = jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET!, { expiresIn: '7d' }); // Refresh token de longa duração

  const refreshTokenExpiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 dias
  await createRefreshToken(user.id, refreshToken, refreshTokenExpiresAt);

  res.cookie('refreshToken', refreshToken, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict',
    expires: refreshTokenExpiresAt,
  });

  return res.json({ accessToken, user: { id: user.id, email: user.email, username: user.username, role: user.role } });
}

export async function refreshAccessToken(req: Request, res: Response, next: NextFunction) {
  const refreshToken = req.cookies.refreshToken;
  if (!refreshToken) {
    return next(new AppError('Refresh token not found', 401));
  }

  try {
    const storedToken = await getRefreshToken(refreshToken);
    if (!storedToken) {
      return next(new AppError('Refresh token invalid or expired', 401));
    }

    const decoded: any = jwt.verify(refreshToken, process.env.JWT_SECRET!); // Verifica o refresh token
    const newAccessToken = jwt.sign({ id: decoded.id, role: decoded.role }, process.env.JWT_SECRET!, { expiresIn: '15m' });

    return res.json({ accessToken: newAccessToken });
  } catch (err) {
    return next(new AppError('Invalid refresh token', 401));
  }
}

export async function logout(req: Request, res: Response, next: NextFunction) {
  const refreshToken = req.cookies.refreshToken;
  if (refreshToken) {
    await deleteRefreshToken(refreshToken);
  }
  res.clearCookie('refreshToken');
  res.status(200).json({ message: 'Logged out successfully' });
}


