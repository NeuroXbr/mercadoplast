import { Request, Response, NextFunction } from 'express';
import knex from '../database';
import { DONATION_AMOUNTS, DonationTier } from '../constants/donations';
import { createPayment as createPaymentService, confirmPayment as confirmPaymentService } from '../services/paymentService';
import { auditLog } from '../middlewares/auditLogger';

export const createPaymentLink = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { tier, description } = req.body;
    const userId = req.user?.id;
    if (!userId) {
      return res.status(401).json({ error: 'Usuário não autenticado' });
    }
    // Validate tier and ensure it's one of the predefined donation levels
    if (!tier || !(tier in DONATION_AMOUNTS)) {
      return res.status(400).json({ error: 'Tipo de doação inválido' });
    }
    const donationTier = tier as DonationTier;
    const result = await createPaymentService(userId, donationTier, description);
    // Log creation of payment (no admin ID since this is initiated by the user)
    await auditLog(req, result.paymentId, 'CREATED', undefined);
    res.json({
      payment_url: result.paymentUrl,
      external_id: result.externalId,
      payment_id: result.paymentId,
      hash: result.hash
    });
  } catch (error) {
    next(error);
  }
};

export const confirmPayment = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { payment_id, external_id, hash } = req.body;
    const adminId = req.user?.id;
    if (!adminId) {
      return res.status(401).json({ error: 'Usuário não autenticado' });
    }
    await confirmPaymentService(payment_id, external_id, hash, adminId);
    // Log confirmation action
    await auditLog(req, payment_id, 'CONFIRMED', adminId);
    res.json({ success: true });
  } catch (error) {
    next(error);
  }
};

export const listPayments = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { status, method, userEmail, page = 1, pageSize = 20, from, to } = req.query;
    const offset = (Number(page) - 1) * Number(pageSize);
    
    let query = knex('payments as p')
      .join('users as u', 'p.user_id', 'u.id')
      .select(
        'p.*',
        'u.email as user_email',
        'u.name as user_name',
        'u.id as user_id_full'
      );
    
    if (status) {
      query = query.where('p.status', status);
    }
    
    if (method) {
      query = query.where('p.payment_method', method);
    }
    
    if (userEmail) {
      query = query.whereILike('u.email', `%${userEmail}%`);
    }
    
    if (from) {
      query = query.where('p.created_at', '>=', from);
    }
    
    if (to) {
      query = query.where('p.created_at', '<=', to);
    }
    
    const [items, totalResult] = await Promise.all([
      query
        .orderBy('p.created_at', 'desc')
        .limit(Number(pageSize))
        .offset(offset),
      query.clone().count('* as total')
    ]);
    
    const total = Number(totalResult[0].total);
    
    // Formatar resposta
    const formattedItems = items.map(item => ({
      id: item.id,
      user_id: item.user_id,
      amount: item.amount,
      status: item.status,
      external_id: item.external_id,
      payment_method: item.payment_method,
      proof_url: item.proof_url,
      confirmed_by: item.confirmed_by,
      confirmed_at: item.confirmed_at,
      created_at: item.created_at,
      user: {
        id: item.user_id_full,
        email: item.user_email,
        name: item.user_name
      }
    }));
    
    res.json({
      items: formattedItems,
      page: Number(page),
      pageSize: Number(pageSize),
      total
    });
  } catch (error) {
    next(error);
  }
};

export const getPaymentById = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;
    
    const payment = await knex('payments as p')
      .join('users as u', 'p.user_id', 'u.id')
      .select(
        'p.*',
        'u.email as user_email',
        'u.name as user_name',
        'u.id as user_id_full'
      )
      .where('p.id', id)
      .first();
    
    if (!payment) {
      return res.status(404).json({ error: 'Payment not found' });
    }
    
    res.json({
      id: payment.id,
      user_id: payment.user_id,
      amount: payment.amount,
      status: payment.status,
      external_id: payment.external_id,
      payment_method: payment.payment_method,
      proof_url: payment.proof_url,
      confirmed_by: payment.confirmed_by,
      confirmed_at: payment.confirmed_at,
      description: payment.description,
      created_at: payment.created_at,
      user: {
        id: payment.user_id_full,
        email: payment.user_email,
        name: payment.user_name
      }
    });
  } catch (error) {
    next(error);
  }
};

export const getPaymentStats = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const [
      totalCount,
      statusCounts,
      revenueTotal,
      revenueLast30d
    ] = await Promise.all([
      knex('payments').count('* as total'),
      knex('payments')
        .select('status')
        .count('* as count')
        .groupBy('status'),
      knex('payments')
        .where('status', 'completed')
        .sum('amount as total'),
      knex('payments')
        .where('status', 'completed')
        .where('confirmed_at', '>=', thirtyDaysAgo)
        .sum('amount as total')
    ]);
    
    const stats = {
      total: Number(totalCount[0].total),
      pending: 0,
      completed: 0,
      failed: 0,
      revenue_total: Number(revenueTotal[0].total || 0),
      revenue_last_30d: Number(revenueLast30d[0].total || 0)
    };
    
    // Mapear contagens por status
    statusCounts.forEach(row => {
      stats[row.status] = Number(row.count);
    });
    
    res.json(stats);
  } catch (error) {
    next(error);
  }
};