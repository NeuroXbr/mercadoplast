import { Request, Response, NextFunction } from 'express';
import knex from '../database';
import { Storage } from '@google-cloud/storage';

// Inicializar GCS se configurado
let storage: Storage | null = null;
if (process.env.USE_GCS === 'true' && process.env.GCP_PROJECT_ID && process.env.GCS_BUCKET) {
  try {
    if (process.env.GCP_CREDENTIALS_BASE64) {
      const credentials = JSON.parse(Buffer.from(process.env.GCP_CREDENTIALS_BASE64, 'base64').toString());
      storage = new Storage({ projectId: process.env.GCP_PROJECT_ID, credentials });
    } else {
      storage = new Storage({ projectId: process.env.GCP_PROJECT_ID });
    }
  } catch (error) {
    console.error('Failed to initialize GCS:', error);
  }
}

export const getKYCStatus = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const userId = req.user?.id;
    
    const kycRequest = await knex('kyc_requests')
      .where('user_id', userId)
      .orderBy('created_at', 'desc')
      .first();
    
    const user = await knex('users')
      .where('id', userId)
      .select('kyc_status')
      .first();
    
    res.json({
      kyc_status: user?.kyc_status || 'pending',
      kyc_request: kycRequest || null
    });
  } catch (error) {
    next(error);
  }
};

export const uploadUrl = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const userId = req.user?.id;
    const fileName = `kyc/${userId}/${Date.now()}-${req.body.fileName || 'document.pdf'}`;
    
    if (process.env.USE_GCS === 'true' && storage && process.env.GCS_BUCKET) {
      const bucket = storage.bucket(process.env.GCS_BUCKET);
      const file = bucket.file(fileName);
      
      const [signedUrl] = await file.getSignedUrl({
        version: 'v4',
        action: 'write',
        expires: Date.now() + 15 * 60 * 1000, // 15 minutos
        contentType: 'application/pdf',
      });
      
      res.json({ url: signedUrl, object_path: fileName });
    } else {
      // Stub local
      res.json({
        url: `http://localhost:8080/upload-stub/${fileName}`,
        object_path: fileName
      });
    }
  } catch (error) {
    next(error);
  }
};

export const listKYCRequests = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { status, page = 1, pageSize = 20 } = req.query;
    const offset = (Number(page) - 1) * Number(pageSize);
    
    let query = knex('kyc_requests as kr')
      .join('users as u', 'kr.user_id', 'u.id')
      .select(
        'kr.*',
        'u.email as user_email',
        'u.name as user_name'
      );
    
    if (status) {
      query = query.where('kr.status', status);
    }
    
    const [items, totalResult] = await Promise.all([
      query
        .orderBy('kr.created_at', 'desc')
        .limit(Number(pageSize))
        .offset(offset),
      knex('kyc_requests')
        .where(status ? { status } : {})
        .count('* as total')
    ]);
    
    const total = Number(totalResult[0].total);
    
    res.json({
      items,
      page: Number(page),
      pageSize: Number(pageSize),
      total
    });
  } catch (error) {
    next(error);
  }
};

export const updateKYCStatus = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;
    const { status, note } = req.body;
    const reviewerId = req.user?.id;
    
    await knex.transaction(async (trx) => {
      // Atualizar kyc_request
      const kycRequest = await trx('kyc_requests')
        .where('id', id)
        .update({
          status,
          review_note: note,
          reviewed_by: reviewerId,
          reviewed_at: knex.fn.now()
        })
        .returning('*');
      
      if (!kycRequest.length) {
        throw new Error('KYC request not found');
      }
      
      // Atualizar status do usuário
      await trx('users')
        .where('id', kycRequest[0].user_id)
        .update({
          kyc_status: status
        });
    });
    
    res.json({ success: true });
  } catch (error) {
    next(error);
  }
};

export const getKYCDocument = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { path } = req.query;
    
    if (!path) {
      return res.status(400).json({ error: 'Path is required' });
    }
    
    if (process.env.USE_GCS === 'true' && storage && process.env.GCS_BUCKET) {
      const bucket = storage.bucket(process.env.GCS_BUCKET);
      const file = bucket.file(String(path));
      
      const [signedUrl] = await file.getSignedUrl({
        version: 'v4',
        action: 'read',
        expires: Date.now() + 60 * 60 * 1000, // 1 hora
      });
      
      res.json({ url: signedUrl });
    } else {
      // Stub local
      res.json({ url: `http://localhost:8080/mock/${path}` });
    }
  } catch (error) {
    next(error);
  }
};