import knex from 'knex';
import { knexSnakeCaseMappers } from 'knex';
import dotenv from 'dotenv';

dotenv.config();

const knexConfig = {
  client: 'pg',
  connection: process.env.DATABASE_URL,
  pool: {
    min: 2,
    max: 20,
    idleTimeoutMillis: 30000,
    createTimeoutMillis: 2000,
    acquireTimeoutMillis: 2000
  },
  migrations: {
    directory: './db/migrations',
    extension: 'ts'
  },
  seeds: {
    directory: './db/seeds',
    extension: 'ts'
  },
  ...knexSnakeCaseMappers()
};

const db = knex(knexConfig);

export default db;