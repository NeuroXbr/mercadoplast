export enum UserRole {
  ADMIN = 'admin',
  MODERATOR = 'moderator',
  ANALYST = 'analyst',
  USER = 'user',
}

