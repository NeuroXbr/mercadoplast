/**
 * Predefined donation amounts for different tiers. The keys represent the
 * donation tier names and the values are the fixed amounts in the default
 * currency (e.g. BRL). These values are immutable and should be used
 * throughout the application to prevent clients from sending arbitrary
 * donation amounts from the frontend.
 */
export const DONATION_AMOUNTS = {
  basic: 10.0,
  premium: 25.0,
  supporter: 50.0
} as const;

export type DonationTier = keyof typeof DONATION_AMOUNTS;