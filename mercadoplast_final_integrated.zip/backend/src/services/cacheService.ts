import { createClient } from 'redis';

// Create a single Redis client instance. It will attempt to connect using
// the REDIS_URL environment variable. If the variable is not defined or
// Redis is unavailable, the service falls back to a no-op cache.
const redisUrl = process.env.REDIS_URL;

let client: ReturnType<typeof createClient> | null = null;

if (redisUrl) {
  client = createClient({ url: redisUrl });
  client.on('error', (err) => {
    // Log errors but continue running without crashing the app
    console.error('Redis Client Error', err);
  });
  client.connect().catch((err) => {
    console.error('Failed to connect to Redis', err);
  });
}

/**
 * Get a cached value by key.
 * @param key Cache key
 * @returns Parsed JSON value or null if not found or on error
 */
export async function getCache<T>(key: string): Promise<T | null> {
  if (!client) return null;
  try {
    const value = await client.get(key);
    if (!value) return null;
    return JSON.parse(value) as T;
  } catch (err) {
    console.error('Error reading from Redis', err);
    return null;
  }
}

/**
 * Set a cache value with an optional TTL (time to live).
 * @param key Cache key
 * @param value Value to store (will be JSON.stringify-ed)
 * @param ttlSeconds Time to live in seconds
 */
export async function setCache<T>(key: string, value: T, ttlSeconds: number): Promise<void> {
  if (!client) return;
  try {
    await client.set(key, JSON.stringify(value), {
      EX: ttlSeconds
    });
  } catch (err) {
    console.error('Error writing to Redis', err);
  }
}

/**
 * Delete a key from the cache.
 * @param key Cache key
 */
export async function delCache(key: string): Promise<void> {
  if (!client) return;
  try {
    await client.del(key);
  } catch (err) {
    console.error('Error deleting from Redis', err);
  }
}