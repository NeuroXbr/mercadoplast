import axios from 'axios';
import knex from '../database';
import { DONATION_AMOUNTS, DonationTier } from '../constants/donations';
import { generatePaymentHash } from '../utils/crypto';

interface CreatePaymentResult {
  paymentId: string;
  externalId: string;
  paymentUrl: string;
  hash: string;
}

/**
 * Create a new payment preference and record it in the database. The amount
 * charged is determined by the donation tier. When `USE_MP_STUB` is true, a
 * local stub is used instead of the Mercado Pago API. Returns the
 * identifiers and URL needed to complete payment on the client.
 */
export async function createPayment(
  userId: string,
  tier: DonationTier,
  description?: string
): Promise<CreatePaymentResult> {
  const amount = DONATION_AMOUNTS[tier];
  let paymentUrl: string;
  let externalId: string;

  if (process.env.USE_MP_STUB === 'true') {
    externalId = `STUB-${Date.now()}`;
    paymentUrl = `http://localhost:8080/payment-stub/${externalId}`;
  } else {
    // Real integration with Mercado Pago
    const mpResponse = await axios.post(
      'https://api.mercadopago.com/checkout/preferences',
      {
        items: [
          {
            title: description || `Doação ${tier}`,
            quantity: 1,
            unit_price: amount
          }
        ],
        external_reference: `user_${userId}_${Date.now()}`,
        payment_methods: {
          excluded_payment_types: [],
          installments: 1
        }
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.MP_ACCESS_TOKEN}`,
          'Content-Type': 'application/json'
        }
      }
    );
    externalId = mpResponse.data.id;
    paymentUrl = mpResponse.data.init_point;
  }

  // Insert payment record
  const [payment] = await knex('payments')
    .insert({
      user_id: userId,
      amount,
      status: 'pending',
      external_id: externalId,
      payment_method: 'pix',
      description: description || `Doação ${tier}`
    })
    .returning('*');

  // Generate cryptographic hash to be returned to the client
  const secret = process.env.PAYMENT_SECRET || '';
  const hash = generatePaymentHash(payment.id, externalId, secret);

  return {
    paymentId: payment.id,
    externalId,
    paymentUrl,
    hash
  };
}

/**
 * Confirm a payment. Validates that the provided external ID matches the
 * stored record and that the hash is correct. Updates the payment status
 * and sets the user as premium when completed. Throws on invalid
 * conditions.
 */
export async function confirmPayment(
  paymentId: string,
  externalId: string,
  hash: string,
  confirmedBy: string
): Promise<void> {
  await knex.transaction(async (trx) => {
    const payment = await trx('payments')
      .where({ id: paymentId, external_id: externalId })
      .first();
    if (!payment) {
      throw new Error('Pagamento não encontrado');
    }
    if (payment.status !== 'pending') {
      throw new Error('Pagamento já processado');
    }
    // Validate hash
    const secret = process.env.PAYMENT_SECRET || '';
    const expectedHash = generatePaymentHash(paymentId, externalId, secret);
    if (hash !== expectedHash) {
      throw new Error('Hash de pagamento inválido');
    }
    // Update payment
    await trx('payments')
      .where({ id: paymentId })
      .update({
        status: 'completed',
        confirmed_by: confirmedBy,
        confirmed_at: trx.fn.now()
      });
    // Upgrade user to premium
    await trx('users')
      .where({ id: payment.user_id })
      .update({ premium: true });
  });
}