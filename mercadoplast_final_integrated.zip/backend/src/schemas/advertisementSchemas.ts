import { z } from 'zod';

export const CreateAdSchema = z.object({
  title: z.string().min(3),
  description: z.string().min(3),
  image_url: z.string().url().optional(),
  link_url: z.string().url(),
  type: z.enum(['banner', 'sidebar', 'native']).default('banner'),
  category: z.string().optional(),
  budget: z.number().optional(),
  active: z.boolean().default(true)
});

export const UpdateAdSchema = CreateAdSchema.partial();

export const ListAdsQuerySchema = z.object({
  active: z
    .string()
    .transform(val => val === 'true')
    .optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
});