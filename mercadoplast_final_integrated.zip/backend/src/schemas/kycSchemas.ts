import { z } from 'zod';

export const UpdateKYCStatusRequestSchema = z.object({
  status: z.enum(['approved', 'rejected']),
  note: z.string().max(500).optional(),
});

export const ListKYCQuerySchema = z.object({
  status: z.enum(['pending', 'approved', 'rejected']).optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
});

export const GetKYCDocumentQuerySchema = z.object({
  path: z.string().min(3),
});