import { z } from 'zod';

// Schema for creating a payment link. Clients must specify one of the
// predefined donation tiers (basic, premium, supporter). The amount is
// determined server-side based on this tier. An optional description can
// override the default title used for the preference.
export const CreateLinkRequestSchema = z.object({
  tier: z.enum(['basic', 'premium', 'supporter']),
  description: z.string().optional(),
});

// Schema for confirming a payment. A hash must be provided to ensure
// the integrity of the external_id and payment_id combination.
export const ConfirmPaymentRequestSchema = z.object({
  payment_id: z.string().uuid(),
  external_id: z.string(),
  hash: z.string(),
});

export const GetPaymentsQuerySchema = z.object({
  status: z.enum(['pending', 'completed', 'failed']).optional(),
  method: z.enum(['pix', 'boleto', 'card']).optional(),
  userEmail: z.string().email().optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
  from: z.string().datetime().optional(),
  to: z.string().datetime().optional(),
});