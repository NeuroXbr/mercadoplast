import { Router } from 'express';
import { authenticateJWT } from '../middlewares/auth';
import { authorizeRoles } from '../middlewares/authorization';
import { validateRequest } from '../middlewares/validation';
import { 
  createPaymentLink, 
  confirmPayment,
  listPayments,
  getPaymentById,
  getPaymentStats
} from '../controllers/paymentsController';
import { 
  CreateLinkRequestSchema, 
  ConfirmPaymentRequestSchema,
  GetPaymentsQuerySchema
} from '../schemas/paymentSchemas';
import { paymentRateLimiter } from '../middlewares/paymentRateLimiter';

const router = Router();

// Middleware para verificar admin/moderator
const requireAdmin = authorizeRoles(['admin', 'moderator']);

// POST /payments/create-link - Criar link de pagamento
router.post(
  '/create-link',
  authenticateJWT,
  validateRequest(CreateLinkRequestSchema),
  paymentRateLimiter,
  createPaymentLink
);

// POST /payments/confirm - Confirmar pagamento (ADMIN)
router.post(
  '/confirm',
  authenticateJWT,
  requireAdmin,
  validateRequest(ConfirmPaymentRequestSchema),
  confirmPayment
);

// GET /payments - Listar pagamentos (ADMIN)
router.get(
  '/',
  authenticateJWT,
  requireAdmin,
  validateRequest(GetPaymentsQuerySchema, 'query'),
  listPayments
);

// GET /payments/stats - Estatísticas de pagamentos (ADMIN)
router.get(
  '/stats',
  authenticateJWT,
  requireAdmin,
  getPaymentStats
);

// GET /payments/:id - Detalhe do pagamento (ADMIN)
router.get(
  '/:id',
  authenticateJWT,
  requireAdmin,
  getPaymentById
);

export default router;