import { Router, Request, Response, NextFunction } from 'express';
import { query } from '../database';
import { AppError } from '../middlewares/errorHandler';
import { setCache } from '../middlewares/cacheControl';

const router = Router();

router.get('/', setCache(3600), async (_req: Request, res: Response, next: NextFunction) => {
  try {
    const { rows } = await query('SELECT id, acronym, name, description FROM polymers ORDER BY name ASC');
    res.json(rows);
  } catch (error) {
    next(error);
  }
});

// Rota para adicionar polímeros (apenas para admin, para popular o banco de dados)
router.post('/', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { acronym, name, description } = req.body;
    if (!acronym || !name) {
      return next(new AppError('Acrônimo e nome do polímero são obrigatórios', 400));
    }
    const { rows } = await query(
      'INSERT INTO polymers (acronym, name, description) VALUES ($1, $2, $3) RETURNING id, acronym, name, description',
      [acronym, name, description]
    );
    res.status(201).json(rows[0]);
  } catch (error) {
    next(error);
  }
});

export default router;


