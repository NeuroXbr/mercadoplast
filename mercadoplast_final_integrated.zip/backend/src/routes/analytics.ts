import { Router } from 'express';
import { authenticateJWT } from '../middlewares/auth';
import { authorizeRoles } from '../middlewares/authorization';
import {
  getAdvancedAnalytics,
  getUserSegmentation,
  getGeographicDistribution
} from '../controllers/analyticsController';

const router = Router();

// Middleware para verificar admin/moderator/analyst
const requireAnalytics = authorizeRoles(['admin', 'moderator', 'analyst']);

// GET /analytics/advanced - Análise avançada
router.get(
  '/advanced',
  authenticateJWT,
  requireAnalytics,
  getAdvancedAnalytics
);

// GET /analytics/user-segmentation - Segmentação de usuários
router.get(
  '/user-segmentation',
  authenticateJWT,
  requireAnalytics,
  getUserSegmentation
);

// GET /analytics/geographic - Distribuição geográfica
router.get(
  '/geographic',
  authenticateJWT,
  requireAnalytics,
  getGeographicDistribution
);

export default router;