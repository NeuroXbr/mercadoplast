import { Router } from 'express';
import { authenticateJWT } from '../middlewares/auth';
import { authorizeRoles } from '../middlewares/authorization';
import { validateRequest } from '../middlewares/validation';
import {
  getKYCStatus,
  uploadUrl,
  listKYCRequests,
  updateKYCStatus,
  getKYCDocument
} from '../controllers/kycController';
import {
  ListKYCQuerySchema,
  UpdateKYCStatusRequestSchema,
  GetKYCDocumentQuerySchema
} from '../schemas/kycSchemas';

const router = Router();

// Middleware para verificar admin/moderator
const requireAdmin = authorizeRoles(['admin', 'moderator']);

// GET /kyc/status - Status dos docs do usuário logado
router.get(
  '/status',
  authenticateJWT,
  getKYCStatus
);

// POST /kyc/upload-url - Gera URL assinada
router.post(
  '/upload-url',
  authenticateJWT,
  uploadUrl
);

// GET /kyc - Listar KYC requests (ADMIN)
router.get(
  '/',
  authenticateJWT,
  requireAdmin,
  validateRequest(ListKYCQuerySchema, 'query'),
  listKYCRequests
);

// GET /kyc/document - Obter documento (ADMIN)
router.get(
  '/document',
  authenticateJWT,
  requireAdmin,
  validateRequest(GetKYCDocumentQuerySchema, 'query'),
  getKYCDocument
);

// PUT /kyc/:id - Atualizar status KYC (ADMIN)
router.put(
  '/:id',
  authenticateJWT,
  requireAdmin,
  validateRequest(UpdateKYCStatusRequestSchema),
  updateKYCStatus
);

export default router;