import { Router, Request, Response, NextFunction } from 'express';
import { query } from '../database';
import { authenticateJWT, requireRole } from '../middlewares/auth';
import { setCache } from '../middlewares/cacheControl';
import { AppError } from '../middlewares/errorHandler';
import { UserRole } from '../constants/roles';

const router = Router();

router.get('/', setCache(300), async (_req: Request, res: Response, next: NextFunction) => {
  try {
    const { rows } = await query('SELECT id, title, body, user_id, created_at FROM posts WHERE status=$1 ORDER BY created_at DESC', ['published']);
    res.json(rows);
  } catch (error) {
    next(error);
  }
});

router.post('/', authenticateJWT, requireRole(UserRole.USER, UserRole.ADMIN, UserRole.MODERATOR, UserRole.ANALYST), async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { title, body } = req.body || {};
    if (!title || !body) return next(new AppError('Missing fields', 400));
    const { rows } = await query('INSERT INTO posts (title, body, user_id, status) VALUES ($1,$2,$3,$4) RETURNING id, title, body, user_id, status', [title, body, (req as any).user!.id, 'published']);
    res.status(201).json(rows[0]);
  } catch (error) {
    next(error);
  }
});

export default router;


