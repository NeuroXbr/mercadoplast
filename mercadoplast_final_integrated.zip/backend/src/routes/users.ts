import { Router, Request, Response, NextFunction } from 'express';
import { query } from '../database';
import { authenticateJWT, requireRole } from '../middlewares/auth';
import { UserRole } from '../constants/roles';
import { AppError } from '../middlewares/errorHandler';

const router = Router();

router.get('/', authenticateJWT, requireRole(UserRole.ADMIN, UserRole.MODERATOR, UserRole.ANALYST), async (req: Request, res: Response, next: NextFunction) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;
    const offset = (page - 1) * limit;

    const { rows: users } = await query(
      'SELECT id, username, email, role, created_at FROM users ORDER BY created_at DESC LIMIT $1 OFFSET $2',
      [limit, offset]
    );

    const { rows: countRows } = await query('SELECT COUNT(*) FROM users');
    const totalUsers = parseInt(countRows[0].count);

    res.json({
      total: totalUsers,
      page,
      limit,
      users,
    });
  } catch (error) {
    next(error);
  }
});

router.get('/:id', authenticateJWT, requireRole(UserRole.ADMIN, UserRole.MODERATOR, UserRole.ANALYST), async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { rows } = await query('SELECT id, username, email, role, created_at FROM users WHERE id=$1', [req.params.id]);
    if (!rows[0]) return next(new AppError('User not found', 404));
    res.json(rows[0]);
  } catch (error) {
    next(error);
  }
});

export default router;


