import { Router } from 'express';
import { authenticateJWT } from '../middlewares/auth';
import { authorizeRoles } from '../middlewares/authorization';
import { validateRequest } from '../middlewares/validation';
import {
  listAds,
  createAd,
  updateAd,
  deleteAd,
  toggleAd,
  getAdStats,
  getAdById,
  recordClick,
  recordImpression,
  intelligentAds
} from '../controllers/advertisementsController';
import {
  CreateAdSchema,
  UpdateAdSchema,
  ListAdsQuerySchema
} from '../schemas/advertisementSchemas';

const router = Router();

// Middleware para verificar admin/moderator
const requireAdmin = authorizeRoles(['admin', 'moderator']);

// GET /advertisements - Listagem pública
router.get(
  '/',
  validateRequest(ListAdsQuerySchema, 'query'),
  listAds
);

// POST /advertisements/intelligent - IA para anúncios (se existir)
router.post(
  '/intelligent',
  authenticateJWT,
  intelligentAds
);

// GET /advertisements/stats - Estatísticas (ADMIN)
router.get(
  '/stats',
  authenticateJWT,
  requireAdmin,
  getAdStats
);

// POST /advertisements - Criar anúncio (ADMIN)
router.post(
  '/',
  authenticateJWT,
  requireAdmin,
  validateRequest(CreateAdSchema),
  createAd
);

// GET /advertisements/:id - Detalhe do anúncio (ADMIN)
router.get(
  '/:id',
  authenticateJWT,
  requireAdmin,
  getAdById
);

// PUT /advertisements/:id - Atualizar anúncio (ADMIN)
router.put(
  '/:id',
  authenticateJWT,
  requireAdmin,
  validateRequest(UpdateAdSchema),
  updateAd
);

// DELETE /advertisements/:id - Deletar anúncio (ADMIN)
router.delete(
  '/:id',
  authenticateJWT,
  requireAdmin,
  deleteAd
);

// PATCH /advertisements/:id/toggle - Ativar/Desativar (ADMIN)
router.patch(
  '/:id/toggle',
  authenticateJWT,
  requireAdmin,
  toggleAd
);

// POST /advertisements/:id/click - Registrar clique
router.post(
  '/:id/click',
  recordClick
);

// POST /advertisements/:id/impression - Registrar impressão
router.post(
  '/:id/impression',
  recordImpression
);

export default router;