# Guia de Deploy do Backend MercadoPlast no Google Cloud Platform

Este documento descreve os passos essenciais para realizar o deploy do backend do MercadoPlast no Google Cloud Platform (GCP).

## Pré-requisitos

Antes de iniciar o deploy, certifique-se de ter:

1.  **Conta GCP Ativa**: Um projeto no Google Cloud com faturamento habilitado.
2.  **Google Cloud SDK (gcloud)**: Instalado e configurado localmente.
3.  **Docker**: Instalado localmente para construir imagens Docker.
4.  **Node.js e npm/yarn**: Para desenvolvimento e testes locais.
5.  **Acesso ao Secret Manager**: Para gerenciar segredos como `DATABASE_URL`, `JWT_SECRET`, `MP_ACCESS_TOKEN`, `GCP_CREDENTIALS_BASE64`.
6.  **Cloud SQL (PostgreSQL)**: Uma instância de Cloud SQL configurada e acessível.
7.  **Cloud Storage**: Um bucket para uploads de arquivos (KYC docs).

## Variáveis de Ambiente

O backend utiliza as variáveis de ambiente definidas no arquivo `.env.example`. Certifique-se de configurar estas variáveis no Google Secret Manager e injetá-las no ambiente de execução do Cloud Run ou Kubernetes.

**Variáveis Críticas:**

*   `DATABASE_URL`: String de conexão com o Cloud SQL.
*   `JWT_SECRET`: Chave secreta para JWT.
*   `REFRESH_TOKEN_SECRET`: Chave secreta para Refresh Tokens.
*   `MP_ACCESS_TOKEN`: Token de acesso do Mercado Pago.
*   `GCP_PROJECT_ID`: ID do seu projeto GCP.
*   `GCS_BUCKET`: Nome do bucket do Cloud Storage.
*   `GCP_CREDENTIALS_BASE64`: Credenciais da conta de serviço em Base64.

## Passos para Deploy

### 1. Configurar Secrets no Google Secret Manager

Crie os secrets necessários no Secret Manager. Por exemplo:

```bash
gcloud secrets create DATABASE_URL --data-file=<(echo 'postgres://<DB_USER>:<DB_PASSWORD>@<DB_HOST>:5432/<DB_NAME>')
gcloud secrets create JWT_SECRET --data-file=<(echo '<YOUR_SUPER_SECRET_JWT_KEY>')
gcloud secrets create REFRESH_TOKEN_SECRET --data-file=<(echo '<YOUR_SUPER_SECRET_REFRESH_TOKEN_KEY>')
gcloud secrets create MP_ACCESS_TOKEN --data-file=<(echo '<YOUR_MERCADO_PAGO_ACCESS_TOKEN>')
gcloud secrets create GCP_CREDENTIALS_BASE64 --data-file=<(cat /path/to/your/service-account-key.json | base64)
```

### 2. Configurar Cloud SQL

Certifique-se de que sua instância do Cloud SQL (PostgreSQL) esteja configurada e que o backend tenha permissão para acessá-la. O `DATABASE_URL` deve apontar para esta instância.

### 3. Configurar Cloud Storage

Crie um bucket no Cloud Storage para armazenar os documentos de KYC e outros uploads. A conta de serviço utilizada pelo backend deve ter permissões de leitura e escrita neste bucket.

### 4. Construir Imagem Docker

Navegue até o diretório `backend` e construa a imagem Docker:

```bash
cd mercadoplast_restructured/backend
docker build -t gcr.io/<YOUR_GCP_PROJECT_ID>/mercadoplast-backend:latest .
docker push gcr.io/<YOUR_GCP_PROJECT_ID>/mercadoplast-backend:latest
```

### 5. Deploy no Cloud Run (Exemplo)

Para deploy no Cloud Run, use o seguinte comando, substituindo os placeholders:

```bash
gcloud run deploy mercadoplast-backend \
  --image gcr.io/<YOUR_GCP_PROJECT_ID>/mercadoplast-backend:latest \
  --platform managed \
  --region <YOUR_GCP_REGION> \
  --allow-unauthenticated \
  --set-env-vars NODE_ENV=production,PORT=8080,GCP_PROJECT_ID=<YOUR_GCP_PROJECT_ID>,GCS_BUCKET=<YOUR_GCS_BUCKET_NAME_FOR_UPLOADS>,USE_GCS=true,USE_MP_STUB=false,CORS_ORIGIN=https://<YOUR_FRONTEND_DOMAIN>,https://<YOUR_ADMIN_DOMAIN> \
  --set-secrets=DATABASE_URL=DATABASE_URL:latest,JWT_SECRET=JWT_SECRET:latest,REFRESH_TOKEN_SECRET=REFRESH_TOKEN_SECRET:latest,MP_ACCESS_TOKEN=MP_ACCESS_TOKEN:latest,GCP_CREDENTIALS_BASE64=GCP_CREDENTIALS_BASE64:latest \
  --memory 512Mi \
  --cpu 1 \
  --min-instances 0 \
  --max-instances 5 \
  --project <YOUR_GCP_PROJECT_ID>
```

**Nota**: As variáveis de ambiente `JWT_EXPIRES_IN`, `REFRESH_TOKEN_EXPIRES_IN`, `RATE_LIMIT_WINDOW_MS`, `RATE_LIMIT_MAX_REQUESTS` e `LOG_LEVEL` podem ser definidas diretamente no `--set-env-vars` ou, se preferir, também como secrets no Secret Manager.

## Scripts de Configuração (`scripts/setup.sh`)

Localizado em `scripts/setup.sh`. Este script é responsável por:

*   Verificar variáveis de ambiente essenciais.
*   Executar migrações do banco de dados (`npx knex migrate:latest`).

Este script deve ser executado como parte do processo de build da imagem Docker ou como um passo inicial no Cloud Run, antes da aplicação iniciar. O `Dockerfile` do backend já está configurado para executar as migrações.

## Fluxo de Doação Manual e Interação Humana (Característica Intencional)

Conforme a visão do projeto MercadoPlast, o processo de doação é intencionalmente manual para fomentar a interação humana e a conexão com os apoiadores. Este fluxo é totalmente suportado pela arquitetura atual e é considerado uma **característica fundamental** do projeto, não uma limitação.

**Fluxo Detalhado:**

1.  **Geração do Link de Doação**: Você ou sua equipe gera um link de pagamento/doação através da plataforma do Mercado Pago.
2.  **Compartilhamento com o Doador**: O link é compartilhado com o interessado em doar, via e-mail, chat ou outro canal de comunicação direto.
3.  **Realização da Doação**: O doador utiliza o link para efetuar a doação via Mercado Pago.
4.  **Envio do Comprovante**: O doador envia o comprovante da transação para você, por exemplo, via e-mail ou um formulário específico no site.
5.  **Verificação e Interação Manual**: Você acessa sua conta do Mercado Pago para confirmar a doação e, crucialmente, **interage diretamente com o doador**. Este é o momento para agradecer, entender suas motivações e fortalecer o relacionamento.
6.  **Registro no Painel Administrativo**: No painel de administração do MercadoPlast (`frontend/admin`), você pode registrar a doação, atualizar o status, e gerenciar qualquer benefício ou reconhecimento associado. As páginas como `PaymentsPage` e `KYCReviewPage` (se aplicável para doadores) podem ser adaptadas para este gerenciamento.

Este fluxo garante que cada doação seja uma oportunidade para construir uma comunidade e manter o propósito humanitário do MercadoPlast no centro das operações.

