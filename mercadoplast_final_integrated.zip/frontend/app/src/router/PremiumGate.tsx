import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';

interface PremiumGateProps {
  children: React.ReactNode;
  fallbackPath?: string;
}

export function PremiumGate({ 
  children, 
  fallbackPath = '/payments' 
}: PremiumGateProps) {
  const { isPremium, isAuthenticated } = useAuth();

  if (!isAuthenticated()) {
    return <Navigate to="/login" replace />;
  }

  if (!isPremium()) {
    return <Navigate to={fallbackPath} replace />;
  }

  return <>{children}</>;
}
