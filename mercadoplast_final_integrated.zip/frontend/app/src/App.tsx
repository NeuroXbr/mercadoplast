import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'sonner';
import { AuthProvider } from '@/hooks/useAuth';
import { Header } from '@/components/Header';
import { ProtectedRoute } from '@/router/ProtectedRoute';

// Pages
import { FeedPage } from '@/pages/FeedPage';
import { PostDetailPage } from '@/pages/PostDetailPage';
import { AuthPage } from '@/pages/AuthPage';
import { DashboardPage } from '@/pages/DashboardPage';
import { KYCPage } from '@/pages/KYCPage';
import { PaymentsPage } from '@/pages/PaymentsPage';
import { CreatePostPage } from '@/pages/CreatePostPage';
import { ProfilePage } from '@/pages/ProfilePage';

import { RoleGate } from '@/router/RoleGate';
import { AdminDashboard } from '@/pages/admin/AdminDashboard';
import { AdsPage } from '@/pages/admin/AdsPage';
import { AnalyticsPage } from '@/pages/admin/AnalyticsPage';
import { KYCReviewPage } from '@/pages/admin/KYCReviewPage';
import { UsersPage } from '@/pages/admin/UsersPage';
import { PaymentsPage as AdminPaymentsPage } from '@/pages/admin/PaymentsPage';
import './App.css';

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen bg-background">
          <Header />
          
          <main>
            <Routes>
              {/* Public Routes */}
              <Route path="/" element={<FeedPage />} />
              <Route path="/post/:id" element={<PostDetailPage />} />
              <Route path="/login" element={<AuthPage />} />
              
              {/* Protected Routes */}
              <Route path="/dashboard" element={
                <ProtectedRoute>
                  <DashboardPage />
                </ProtectedRoute>
              } />
              
              <Route path="/kyc" element={
                <ProtectedRoute>
                  <KYCPage />
                </ProtectedRoute>
              } />
              
              <Route path="/payments" element={
                <ProtectedRoute>
                  <PaymentsPage />
                </ProtectedRoute>
              } />
              
              <Route path="/create-post" element={
                <ProtectedRoute>
                  <CreatePostPage />
                </ProtectedRoute>
              } />
              
              <Route path="/profile" element={
                <ProtectedRoute>
                  <ProfilePage />
                </ProtectedRoute>
              } />
              
              <Route path="/settings" element={
                <ProtectedRoute>
                  <ProfilePage />
                </ProtectedRoute>
              } />
              {/* Admin Routes */}
              <Route path="/admin/dashboard" element={
                <RoleGate allowedRoles={['admin']}>
                  <AdminDashboard />
                </RoleGate>
              } />

              <Route path="/admin/ads" element={
                <RoleGate allowedRoles={['admin']}>
                  <AdsPage />
                </RoleGate>
              } />

              <Route path="/admin/analytics" element={
                <RoleGate allowedRoles={['admin']}>
                  <AnalyticsPage />
                </RoleGate>
              } />

              <Route path="/admin/kyc" element={
                <RoleGate allowedRoles={['admin']}>
                  <KYCReviewPage />
                </RoleGate>
              } />

              <Route path="/admin/payments" element={
                <RoleGate allowedRoles={['admin']}>
                  <AdminPaymentsPage />
                </RoleGate>
              } />

              <Route path="/admin/users" element={
                <RoleGate allowedRoles={['admin']}>
                  <UsersPage />
                </RoleGate>
              } />

            </Routes>
          </main>
          
          <Toaster 
            position="top-right"
            toastOptions={{
              duration: 4000,
              style: {
                background: 'white',
                color: 'black',
                border: '1px solid #e5e7eb',
              },
            }}
          />
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
