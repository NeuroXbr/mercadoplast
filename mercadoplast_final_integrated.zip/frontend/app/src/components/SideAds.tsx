import React, { useEffect, useState } from 'react';
import { Advertisement } from '@/types';
import { adService } from '@/services/adService';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ExternalLink, Eye } from 'lucide-react';
import { toast } from 'sonner';

interface SideAdsProps {
  className?: string;
}

export function SideAds({ className = '' }: SideAdsProps) {
  const [ads, setAds] = useState<Advertisement[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAds();
  }, []);

  const loadAds = async () => {
    try {
      const adsData = await adService.getAdvertisements({
        type: 'sidebar',
        limit: 5,
      });
      setAds(adsData);
      
      // Registrar impressões
      adsData.forEach(ad => {
        registerImpression(ad.id);
      });
    } catch (error) {
      console.error('Erro ao carregar anúncios:', error);
    } finally {
      setLoading(false);
    }
  };

  const registerImpression = async (adId: string) => {
    try {
      await adService.registerImpression(adId);
    } catch (error) {
      console.error('Erro ao registrar impressão:', error);
    }
  };

  const handleAdClick = async (ad: Advertisement) => {
    try {
      await adService.registerClick(ad.id);
      window.open(ad.link_url, '_blank', 'noopener,noreferrer');
    } catch (error) {
      console.error('Erro ao registrar clique:', error);
      toast.error('Erro ao abrir anúncio');
    }
  };

  if (loading) {
    return (
      <div className={`space-y-4 ${className}`}>
        {[...Array(3)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-4">
              <div className="h-4 bg-gray-200 rounded mb-2"></div>
              <div className="h-3 bg-gray-200 rounded mb-2"></div>
              <div className="h-3 bg-gray-200 rounded w-2/3"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (ads.length === 0) {
    return null;
  }

  return (
    <div className={`space-y-4 ${className}`}>
      <div className="flex items-center space-x-2 mb-4">
        <Eye className="h-4 w-4 text-muted-foreground" />
        <span className="text-sm font-medium text-muted-foreground">
          Anúncios Patrocinados
        </span>
      </div>
      
      {ads.map((ad) => (
        <Card 
          key={ad.id} 
          className="cursor-pointer hover:shadow-md transition-all duration-200 hover:-translate-y-0.5"
          onClick={() => handleAdClick(ad)}
        >
          <CardContent className="p-4">
            {ad.image_url && (
              <div className="mb-3 rounded-lg overflow-hidden">
                <img
                  src={ad.image_url}
                  alt={ad.title}
                  className="w-full h-32 object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
            )}
            
            <div className="space-y-2">
              <div className="flex items-start justify-between">
                <h4 className="font-medium text-sm line-clamp-2 flex-1">
                  {ad.title}
                </h4>
                <ExternalLink className="h-3 w-3 text-muted-foreground ml-2 flex-shrink-0" />
              </div>
              
              <p className="text-xs text-muted-foreground line-clamp-3">
                {ad.content}
              </p>
              
              <div className="flex items-center justify-between">
                {ad.category && (
                  <Badge variant="secondary" className="text-xs">
                    {ad.category}
                  </Badge>
                )}
                
                <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                  <span>{ad.impressions} visualizações</span>
                  <span>•</span>
                  <span>{ad.clicks} cliques</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
      
      <div className="text-center">
        <p className="text-xs text-muted-foreground">
          Anuncie aqui • Contato: anuncios@mercadoplast.com
        </p>
      </div>
    </div>
  );
}
