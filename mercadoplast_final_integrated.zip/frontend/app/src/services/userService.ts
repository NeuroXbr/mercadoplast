import api from './api';
import { UsersResponse, User, PaginationParams } from '@/types';

export const userService = {
  async getUsers(params?: PaginationParams): Promise<UsersResponse> {
    const response = await api.get('/users', { params });
    return response.data;
  },

  async getUser(id: string): Promise<User> {
    const response = await api.get(`/users/${id}`);
    return response.data;
  },

  async updateUser(id: string, userData: Partial<User>): Promise<User> {
    const response = await api.put(`/users/${id}`, userData);
    return response.data;
  },

  async deleteUser(id: string): Promise<void> {
    await api.delete(`/users/${id}`);
  },
};
