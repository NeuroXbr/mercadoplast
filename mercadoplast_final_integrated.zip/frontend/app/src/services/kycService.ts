import api from './api';
import { KYCDocument, UploadURLResponse, KYCSubmission } from '@/types';

const USE_STUBS = import.meta.env.VITE_USE_STUBS === 'true';

// Mock data para desenvolvimento
const mockKYCDocuments: KYCDocument[] = [
  { type: 'cpf', status: 'pending' },
  { type: 'address_proof', status: 'approved', uploaded_at: '2024-01-15T10:30:00Z' },
  { type: 'cnpj', status: 'rejected' },
];

const mockUploadURL: UploadURLResponse = {
  signed_url: 'https://example.com/upload/mock-url',
  object_path: '/uploads/mock-document.pdf',
};

export const kycService = {
  async getKYCStatus(): Promise<KYCDocument[]> {
    if (USE_STUBS) {
      // Simular delay de rede
      await new Promise(resolve => setTimeout(resolve, 500));
      return mockKYCDocuments;
    }

    try {
      const response = await api.get('/kyc/status');
      return response.data;
    } catch (error) {
      console.warn('KYC status endpoint not available, using stub');
      return mockKYCDocuments;
    }
  },

  async getUploadURL(type: string, fileName: string): Promise<UploadURLResponse> {
    if (USE_STUBS) {
      // Simular delay de rede
      await new Promise(resolve => setTimeout(resolve, 300));
      return {
        ...mockUploadURL,
        object_path: `/uploads/${type}-${fileName}`,
      };
    }

    try {
      const response = await api.post('/kyc/upload-url', {
        type,
        file_name: fileName,
      });
      return response.data;
    } catch (error) {
      console.warn('KYC upload-url endpoint not available, using stub');
      return {
        ...mockUploadURL,
        object_path: `/uploads/${type}-${fileName}`,
      };
    }
  },

  async submitKYC(submission: KYCSubmission): Promise<void> {
    const response = await api.post('/kyc', submission);
    return response.data;
  },
};
