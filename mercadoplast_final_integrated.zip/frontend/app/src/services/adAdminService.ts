import api from './api';
import { Advertisement, CreateAdvertisementRequest, PaginationParams } from '@/types';

interface AdParams extends PaginationParams {
  type?: string;
  category?: string;
  location?: string;
}

interface AdStats {
  totalAds: number;
  activeAds: number;
  totalClicks: number;
  totalImpressions: number;
  ctr: number;
  topPerformingAds: Advertisement[];
}

export const adService = {
  async getAdvertisements(params?: AdParams): Promise<Advertisement[]> {
    try {
      const response = await api.get('/advertisements', { params });
      return response.data;
    } catch (error) {
      console.warn('Usando dados mockados para anúncios');
      
      // Mock data para desenvolvimento
      const mockAds: Advertisement[] = [
        {
          id: '1',
          title: 'Polímeros Premium - Qualidade Garantida',
          content: 'Descubra nossa linha completa de polímeros de alta qualidade para sua indústria.',
          image_url: 'https://via.placeholder.com/400x200/3b82f6/ffffff?text=Polímeros+Premium',
          link_url: 'https://exemplo.com/polimeros-premium',
          type: 'banner',
          category: 'polimeros',
          location: 'homepage',
          active: true,
          created_at: '2024-02-15T10:30:00Z',
          clicks: 245,
          impressions: 3420,
        },
        {
          id: '2',
          title: 'Equipamentos Industriais',
          content: 'Máquinas e equipamentos para processamento de plásticos.',
          image_url: 'https://via.placeholder.com/300x150/10b981/ffffff?text=Equipamentos',
          link_url: 'https://exemplo.com/equipamentos',
          type: 'sidebar',
          category: 'equipamentos',
          location: 'feed',
          active: true,
          created_at: '2024-02-10T14:20:00Z',
          clicks: 156,
          impressions: 2180,
        },
        {
          id: '3',
          title: 'Consultoria Especializada',
          content: 'Consultoria técnica para otimização de processos industriais.',
          image_url: 'https://via.placeholder.com/350x175/f59e0b/ffffff?text=Consultoria',
          link_url: 'https://exemplo.com/consultoria',
          type: 'popup',
          category: 'servicos',
          location: 'dashboard',
          active: false,
          created_at: '2024-02-05T09:15:00Z',
          clicks: 89,
          impressions: 1560,
        },
        {
          id: '4',
          title: 'Matéria-Prima Sustentável',
          content: 'Materiais recicláveis e sustentáveis para sua produção.',
          image_url: 'https://via.placeholder.com/400x200/059669/ffffff?text=Sustentável',
          link_url: 'https://exemplo.com/sustentavel',
          type: 'banner',
          category: 'sustentabilidade',
          location: 'posts',
          active: true,
          created_at: '2024-02-01T16:45:00Z',
          clicks: 312,
          impressions: 4200,
        },
        {
          id: '5',
          title: 'Treinamentos Online',
          content: 'Cursos e treinamentos para profissionais da área.',
          image_url: 'https://via.placeholder.com/300x150/8b5cf6/ffffff?text=Treinamentos',
          link_url: 'https://exemplo.com/treinamentos',
          type: 'sidebar',
          category: 'educacao',
          location: 'profile',
          active: true,
          created_at: '2024-01-28T11:30:00Z',
          clicks: 198,
          impressions: 2890,
        },
      ];
      
      return mockAds;
    }
  },

  async getAdvertisement(id: string): Promise<Advertisement> {
    try {
      const response = await api.get(`/advertisements/${id}`);
      return response.data;
    } catch (error) {
      const ads = await this.getAdvertisements();
      const ad = ads.find(a => a.id === id);
      if (!ad) {
        throw new Error('Anúncio não encontrado');
      }
      return ad;
    }
  },

  async createAdvertisement(adData: CreateAdvertisementRequest): Promise<Advertisement> {
    try {
      const response = await api.post('/advertisements', adData);
      return response.data;
    } catch (error) {
      console.warn('Simulando criação de anúncio');
      
      // Simular criação de anúncio
      const newAd: Advertisement = {
        id: Math.random().toString(36).substr(2, 9),
        ...adData,
        active: true,
        created_at: new Date().toISOString(),
        clicks: 0,
        impressions: 0,
      };
      
      // Simular delay da API
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      return newAd;
    }
  },

  async updateAdvertisement(id: string, adData: Partial<CreateAdvertisementRequest>): Promise<Advertisement> {
    try {
      const response = await api.put(`/advertisements/${id}`, adData);
      return response.data;
    } catch (error) {
      console.warn('Simulando atualização de anúncio');
      
      const currentAd = await this.getAdvertisement(id);
      const updatedAd = { ...currentAd, ...adData };
      
      // Simular delay da API
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      return updatedAd;
    }
  },

  async deleteAdvertisement(id: string): Promise<void> {
    try {
      await api.delete(`/advertisements/${id}`);
    } catch (error) {
      console.warn('Simulando exclusão de anúncio');
      // Simular delay da API
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  },

  async getStats(): Promise<AdStats> {
    try {
      const response = await api.get('/advertisements/stats');
      return response.data;
    } catch (error) {
      console.warn('Usando estatísticas mockadas de anúncios');
      
      const ads = await this.getAdvertisements();
      
      const totalClicks = ads.reduce((sum, ad) => sum + ad.clicks, 0);
      const totalImpressions = ads.reduce((sum, ad) => sum + ad.impressions, 0);
      const ctr = totalImpressions > 0 ? (totalClicks / totalImpressions) * 100 : 0;
      
      const topPerformingAds = ads
        .sort((a, b) => b.clicks - a.clicks)
        .slice(0, 3);
      
      return {
        totalAds: ads.length,
        activeAds: ads.filter(ad => ad.active).length,
        totalClicks,
        totalImpressions,
        ctr,
        topPerformingAds,
      };
    }
  },

  async toggleAdStatus(id: string): Promise<Advertisement> {
    try {
      const response = await api.patch(`/advertisements/${id}/toggle`);
      return response.data;
    } catch (error) {
      console.warn('Simulando alteração de status do anúncio');
      
      const currentAd = await this.getAdvertisement(id);
      const updatedAd = { ...currentAd, active: !currentAd.active };
      
      // Simular delay da API
      await new Promise(resolve => setTimeout(resolve, 500));
      
      return updatedAd;
    }
  },
};
