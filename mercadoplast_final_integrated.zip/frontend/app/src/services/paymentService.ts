import api from './api';
import { Payment, CreateLinkResponse, CreatePaymentLinkRequest } from '@/types';

export const paymentService = {
  async createPaymentLink(data: CreatePaymentLinkRequest): Promise<CreateLinkResponse> {
    const response = await api.post('/payments/create-link', data);
    return response.data;
  },

  async getMyPayments(): Promise<Payment[]> {
    const response = await api.get('/payments/my');
    return response.data;
  },

  async getPayment(id: string): Promise<Payment> {
    const response = await api.get(`/payments/${id}`);
    return response.data;
  },
};
