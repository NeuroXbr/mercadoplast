import api from './api';
import { Polymer } from '@/types';

export const polymerService = {
  async getPolymers(): Promise<Polymer[]> {
    const response = await api.get('/polymers');
    return response.data;
  },

  async getPolymer(id: string): Promise<Polymer> {
    const response = await api.get(`/polymers/${id}`);
    return response.data;
  },
};
