import api from './api';
import { Advertisement, PaginationParams } from '@/types';

interface AdParams extends PaginationParams {
  type?: string;
  category?: string;
  location?: string;
}

export const adService = {
  async getAdvertisements(params?: AdParams): Promise<Advertisement[]> {
    const response = await api.get('/advertisements', { params });
    return response.data;
  },

  async getAdvertisement(id: string): Promise<Advertisement> {
    const response = await api.get(`/advertisements/${id}`);
    return response.data;
  },

  async registerClick(id: string): Promise<void> {
    await api.post(`/advertisements/${id}/click`);
  },

  async registerImpression(id: string): Promise<void> {
    await api.post(`/advertisements/${id}/impression`);
  },
};
