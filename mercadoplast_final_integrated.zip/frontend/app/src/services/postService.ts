import api from './api';
import { PostsResponse, CreatePostRequest, Post, PaginationParams } from '@/types';

export const postService = {
  async getPosts(params?: PaginationParams): Promise<PostsResponse> {
    const response = await api.get('/posts', { params });
    return response.data;
  },

  async getPost(id: string): Promise<Post> {
    const response = await api.get(`/posts/${id}`);
    return response.data;
  },

  async createPost(postData: CreatePostRequest): Promise<Post> {
    const response = await api.post('/posts', postData);
    return response.data;
  },

  async updatePost(id: string, postData: Partial<CreatePostRequest>): Promise<Post> {
    const response = await api.put(`/posts/${id}`, postData);
    return response.data;
  },

  async deletePost(id: string): Promise<void> {
    await api.delete(`/posts/${id}`);
  },
};
