import api from './api';
import { Analytics } from '@/types';

interface AdvancedAnalytics extends Analytics {
  userGrowth: Array<{
    date: string;
    users: number;
    premium: number;
  }>;
  revenueGrowth: Array<{
    date: string;
    revenue: number;
    subscriptions: number;
  }>;
  postActivity: Array<{
    date: string;
    posts: number;
    views: number;
  }>;
  adPerformance: Array<{
    date: string;
    impressions: number;
    clicks: number;
    ctr: number;
  }>;
  topCategories: Array<{
    category: string;
    posts: number;
    percentage: number;
  }>;
  userActivity: Array<{
    hour: number;
    users: number;
  }>;
  conversionFunnel: Array<{
    stage: string;
    users: number;
    percentage: number;
  }>;
}

export const analyticsService = {
  async getAnalytics(): Promise<Analytics> {
    try {
      const response = await api.get('/analytics');
      return response.data;
    } catch (error) {
      console.warn('Usando dados mockados para analytics básico');
      
      return {
        totalUsers: 1247,
        totalPosts: 3892,
        totalAds: 15,
        totalClicks: 2847,
        totalImpressions: 45620,
        ctr: 6.24,
        revenue: 12450.80,
      };
    }
  },

  async getAdvancedAnalytics(): Promise<AdvancedAnalytics> {
    try {
      const response = await api.get('/analytics/advanced');
      return response.data;
    } catch (error) {
      console.warn('Usando dados mockados para analytics avançado');
      
      const basicAnalytics = await this.getAnalytics();
      
      // Gerar dados mockados para os últimos 30 dias
      const generateDateRange = (days: number) => {
        const dates = [];
        for (let i = days - 1; i >= 0; i--) {
          const date = new Date();
          date.setDate(date.getDate() - i);
          dates.push(date.toISOString().split('T')[0]);
        }
        return dates;
      };

      const dates = generateDateRange(30);

      return {
        ...basicAnalytics,
        userGrowth: dates.map((date, index) => ({
          date,
          users: Math.floor(800 + (index * 15) + Math.random() * 50),
          premium: Math.floor(120 + (index * 2) + Math.random() * 10),
        })),
        revenueGrowth: dates.map((date, index) => ({
          date,
          revenue: Math.floor(300 + (index * 25) + Math.random() * 100),
          subscriptions: Math.floor(8 + (index * 0.5) + Math.random() * 3),
        })),
        postActivity: dates.map((date, index) => ({
          date,
          posts: Math.floor(45 + Math.random() * 30),
          views: Math.floor(1200 + Math.random() * 800),
        })),
        adPerformance: dates.map((date, index) => ({
          date,
          impressions: Math.floor(1200 + Math.random() * 400),
          clicks: Math.floor(60 + Math.random() * 40),
          ctr: parseFloat((4 + Math.random() * 4).toFixed(2)),
        })),
        topCategories: [
          { category: 'Polímeros', posts: 1245, percentage: 32.0 },
          { category: 'Equipamentos', posts: 892, percentage: 22.9 },
          { category: 'Matéria-Prima', posts: 678, percentage: 17.4 },
          { category: 'Sustentabilidade', posts: 543, percentage: 13.9 },
          { category: 'Serviços', posts: 534, percentage: 13.8 },
        ],
        userActivity: Array.from({ length: 24 }, (_, hour) => ({
          hour,
          users: Math.floor(20 + Math.sin((hour - 6) * Math.PI / 12) * 80 + Math.random() * 20),
        })),
        conversionFunnel: [
          { stage: 'Visitantes', users: 10000, percentage: 100 },
          { stage: 'Cadastros', users: 2500, percentage: 25 },
          { stage: 'Posts Criados', users: 1200, percentage: 12 },
          { stage: 'KYC Enviado', users: 800, percentage: 8 },
          { stage: 'Premium', users: 300, percentage: 3 },
        ],
      };
    }
  },

  async getAdvertisementStats(): Promise<any> {
    try {
      const response = await api.get('/advertisements/stats');
      return response.data;
    } catch (error) {
      console.warn('Usando estatísticas mockadas de anúncios');
      
      return {
        totalAds: 15,
        activeAds: 12,
        totalClicks: 2847,
        totalImpressions: 45620,
        ctr: 6.24,
        topPerformingAds: [
          {
            id: '1',
            title: 'Polímeros Premium',
            clicks: 312,
            impressions: 4200,
            ctr: 7.43,
          },
          {
            id: '2',
            title: 'Equipamentos Industriais',
            clicks: 245,
            impressions: 3420,
            ctr: 7.16,
          },
          {
            id: '3',
            title: 'Matéria-Prima Sustentável',
            clicks: 198,
            impressions: 2890,
            ctr: 6.85,
          },
        ],
      };
    }
  },

  async getUserSegmentation(): Promise<{
    segments: Array<{
      name: string;
      users: number;
      percentage: number;
      color: string;
    }>;
  }> {
    try {
      const response = await api.get('/analytics/user-segmentation');
      return response.data;
    } catch (error) {
      console.warn('Usando dados mockados para segmentação de usuários');
      
      return {
        segments: [
          { name: 'Usuários Gratuitos', users: 947, percentage: 76.0, color: '#3b82f6' },
          { name: 'Premium Mensal', users: 180, percentage: 14.4, color: '#10b981' },
          { name: 'Premium Anual', users: 120, percentage: 9.6, color: '#f59e0b' },
        ],
      };
    }
  },

  async getGeographicData(): Promise<{
    regions: Array<{
      region: string;
      users: number;
      percentage: number;
    }>;
  }> {
    try {
      const response = await api.get('/analytics/geographic');
      return response.data;
    } catch (error) {
      console.warn('Usando dados mockados para dados geográficos');
      
      return {
        regions: [
          { region: 'São Paulo', users: 387, percentage: 31.0 },
          { region: 'Rio de Janeiro', users: 249, percentage: 20.0 },
          { region: 'Minas Gerais', users: 187, percentage: 15.0 },
          { region: 'Rio Grande do Sul', users: 125, percentage: 10.0 },
          { region: 'Paraná', users: 112, percentage: 9.0 },
          { region: 'Outros', users: 187, percentage: 15.0 },
        ],
      };
    }
  },
};
