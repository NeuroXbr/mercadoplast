import { useState, useCallback } from 'react';

interface UsePaginationProps {
  initialPage?: number;
  initialLimit?: number;
}

interface PaginationState {
  page: number;
  limit: number;
  offset: number;
  hasMore: boolean;
  total: number;
}

interface PaginationActions {
  setPage: (page: number) => void;
  setLimit: (limit: number) => void;
  nextPage: () => void;
  prevPage: () => void;
  setTotal: (total: number) => void;
  reset: () => void;
}

export function usePagination({
  initialPage = 1,
  initialLimit = 10,
}: UsePaginationProps = {}): [PaginationState, PaginationActions] {
  const [page, setPageState] = useState(initialPage);
  const [limit, setLimitState] = useState(initialLimit);
  const [total, setTotalState] = useState(0);

  const offset = (page - 1) * limit;
  const hasMore = offset + limit < total;

  const setPage = useCallback((newPage: number) => {
    setPageState(Math.max(1, newPage));
  }, []);

  const setLimit = useCallback((newLimit: number) => {
    setLimitState(Math.max(1, newLimit));
    setPageState(1); // Reset to first page when changing limit
  }, []);

  const nextPage = useCallback(() => {
    if (hasMore) {
      setPageState(prev => prev + 1);
    }
  }, [hasMore]);

  const prevPage = useCallback(() => {
    setPageState(prev => Math.max(1, prev - 1));
  }, []);

  const setTotal = useCallback((newTotal: number) => {
    setTotalState(Math.max(0, newTotal));
  }, []);

  const reset = useCallback(() => {
    setPageState(initialPage);
    setLimitState(initialLimit);
    setTotalState(0);
  }, [initialPage, initialLimit]);

  const state: PaginationState = {
    page,
    limit,
    offset,
    hasMore,
    total,
  };

  const actions: PaginationActions = {
    setPage,
    setLimit,
    nextPage,
    prevPage,
    setTotal,
    reset,
  };

  return [state, actions];
}
