// Auth Types
export type UserRole = 'user' | 'admin' | 'moderator' | 'analyst';

export interface User {
  id: string;
  username: string;
  email: string;
  role: UserRole;
  premium: boolean;
  kycStatus: 'pending' | 'approved' | 'rejected';
  created_at: string;
}

export interface AuthResponse {
  user: User;
  accessToken: string;
  refreshToken?: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  email: string;
  password: string;
}

// Post/Polymer Types
export interface Polymer {
  id: string;
  acronym: string;
  name: string;
  description: string;
}

export interface Post {
  id: string;
  user_id: string;
  title: string;
  body: string;
  status: 'active' | 'inactive' | 'pending';
  created_at: string;
  polymer: Polymer;
}

export interface PostsResponse {
  posts: Post[];
  total?: number;
  page?: number;
  limit?: number;
}

export interface CreatePostRequest {
  title: string;
  body: string;
  polymer_id: string;
}

// KYC Types
export type KYCDocumentType = 'cpf' | 'cnpj' | 'address_proof' | 'company_registration';
export type KYCStatus = 'pending' | 'approved' | 'rejected';

export interface KYCDocument {
  id: string;
  user_id: string;
  type: KYCDocumentType;
  object_path: string;
  status: KYCStatus;
  uploaded_at: string;
  file_size: number;
  mime_type: string;
}

export interface KYCPending {
  id: string;
  user_id: string;
  user: User;
  documents: KYCDocument[];
  submitted_at: string;
  status: KYCStatus;
  reviewed_at?: string;
  reviewed_by?: string;
  rejection_reason?: string;
}

export interface UploadURLResponse {
  signed_url: string;
  object_path: string;
}

export interface KYCSubmissionDocument {
  type: KYCDocumentType;
  object_path: string;
  file_size: number;
  mime_type: string;
}

export interface KYCSubmission {
  documents: KYCSubmissionDocument[];
}

// Payment Types
export interface Payment {
  id: string;
  user_id: string;
  amount: number;
  status: 'pending' | 'completed' | 'failed';
  created_at: string;
  external_id?: string;
  proof_url?: string;
}

export interface PaymentAdmin extends Payment {
  user: User;
  description: string;
  payment_method: 'pix' | 'credit_card' | 'bank_transfer';
  confirmed_at?: string;
  confirmed_by?: string;
  failure_reason?: string;
}

export interface CreateLinkResponse {
  checkout_url: string;
  external_id: string;
}

export interface CreatePaymentLinkRequest {
  amount: number;
  description: string;
}

export interface ConfirmPaymentRequest {
  user_id: string;
  external_id: string;
  proof_url: string;
  note?: string;
}

// Advertisement Types
export interface Advertisement {
  id: string;
  title: string;
  content: string;
  image_url?: string;
  link_url: string;
  type: 'banner' | 'sidebar' | 'popup';
  category?: string;
  location?: string;
  active: boolean;
  created_at: string;
  clicks: number;
  impressions: number;
}

export interface CreateAdvertisementRequest {
  title: string;
  content: string;
  image_url?: string;
  link_url: string;
  type: 'banner' | 'sidebar' | 'popup';
  category?: string;
  location?: string;
}

// Analytics Types
export interface Analytics {
  totalUsers: number;
  totalPosts: number;
  totalAds: number;
  totalClicks: number;
  totalImpressions: number;
  ctr: number;
  revenue: number;
}

// API Response Types
export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
}

export interface PaginationParams {
  limit?: number;
  offset?: number;
  page?: number;
}

// Users (Admin) Types
export interface UsersResponse {
  total: number;
  page: number;
  limit: number;
  users: User[];
}
