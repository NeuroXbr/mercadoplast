import React, { useEffect, useState } from 'react';
import { Analytics } from '@/types';
import { analyticsService } from '@/services/analyticsService';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Users, 
  FileText, 
  Megaphone, 
  MousePointer, 
  Eye,
  TrendingUp,
  DollarSign,
  Activity,
  Loader2
} from 'lucide-react';

export function AdminDashboard() {
  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadAnalytics();
  }, []);

  const loadAnalytics = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await analyticsService.getAnalytics();
      setAnalytics(data);
    } catch (error: any) {
      console.error('Erro ao carregar analytics:', error);
      setError('Erro ao carregar dados do dashboard');
      // Mock data para desenvolvimento
      setAnalytics({
        totalUsers: 1250,
        totalPosts: 340,
        totalAds: 25,
        totalClicks: 1580,
        totalImpressions: 12400,
        ctr: 12.7,
        revenue: 15750.50,
      });
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const formatNumber = (value: number) => {
    return new Intl.NumberFormat('pt-BR').format(value);
  };

  const formatPercentage = (value: number) => {
    return `${value.toFixed(1)}%`;
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <Loader2 className="h-12 w-12 animate-spin text-blue-600 mx-auto mb-4" />
            <p className="text-lg text-muted-foreground">Carregando dashboard...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error && !analytics) {
    return (
      <div className="p-6">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Erro ao carregar dashboard</h1>
          <p className="text-muted-foreground mb-6">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard Administrativo</h1>
          <p className="text-muted-foreground mt-1">
            Visão geral da plataforma MercadoPlast
          </p>
        </div>
        
        {error && (
          <Badge variant="outline" className="bg-yellow-50 text-yellow-800 border-yellow-200">
            Usando dados de exemplo
          </Badge>
        )}
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total de Usuários
            </CardTitle>
            <Users className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {analytics ? formatNumber(analytics.totalUsers) : '0'}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              +12% desde o último mês
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Posts Publicados
            </CardTitle>
            <FileText className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {analytics ? formatNumber(analytics.totalPosts) : '0'}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              +8% desde a semana passada
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Anúncios Ativos
            </CardTitle>
            <Megaphone className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">
              {analytics ? formatNumber(analytics.totalAds) : '0'}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              +3 novos esta semana
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Receita Total
            </CardTitle>
            <DollarSign className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              {analytics ? formatCurrency(analytics.revenue) : 'R$ 0,00'}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              +15% desde o último mês
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Secondary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Impressões de Anúncios
            </CardTitle>
            <Eye className="h-4 w-4 text-indigo-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-indigo-600">
              {analytics ? formatNumber(analytics.totalImpressions) : '0'}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Visualizações totais
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Cliques em Anúncios
            </CardTitle>
            <MousePointer className="h-4 w-4 text-teal-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-teal-600">
              {analytics ? formatNumber(analytics.totalClicks) : '0'}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Interações totais
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Taxa de Cliques (CTR)
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-rose-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-rose-600">
              {analytics ? formatPercentage(analytics.ctr) : '0%'}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Performance dos anúncios
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Activity Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Activity className="h-5 w-5 mr-2 text-blue-600" />
              Atividade Recente
            </CardTitle>
            <CardDescription>
              Últimas ações na plataforma
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium">Novo usuário registrado</p>
                  <p className="text-xs text-muted-foreground">2 minutos atrás</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium">Post aprovado</p>
                  <p className="text-xs text-muted-foreground">5 minutos atrás</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 p-3 bg-purple-50 rounded-lg">
                <div className="w-2 h-2 bg-purple-600 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium">Novo anúncio criado</p>
                  <p className="text-xs text-muted-foreground">10 minutos atrás</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 p-3 bg-orange-50 rounded-lg">
                <div className="w-2 h-2 bg-orange-600 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium">Pagamento confirmado</p>
                  <p className="text-xs text-muted-foreground">15 minutos atrás</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="h-5 w-5 mr-2 text-green-600" />
              Métricas de Performance
            </CardTitle>
            <CardDescription>
              Indicadores chave de performance
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <p className="text-sm font-medium">Usuários Ativos (7 dias)</p>
                  <p className="text-xs text-muted-foreground">Últimos 7 dias</p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold text-blue-600">892</p>
                  <p className="text-xs text-green-600">+5.2%</p>
                </div>
              </div>
              
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <p className="text-sm font-medium">Taxa de Conversão</p>
                  <p className="text-xs text-muted-foreground">Visitantes → Usuários</p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold text-green-600">3.4%</p>
                  <p className="text-xs text-green-600">+0.8%</p>
                </div>
              </div>
              
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <p className="text-sm font-medium">Tempo Médio na Plataforma</p>
                  <p className="text-xs text-muted-foreground">Por sessão</p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold text-purple-600">12m 34s</p>
                  <p className="text-xs text-green-600">+2m 15s</p>
                </div>
              </div>
              
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <p className="text-sm font-medium">Satisfação do Cliente</p>
                  <p className="text-xs text-muted-foreground">Avaliação média</p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold text-orange-600">4.7/5</p>
                  <p className="text-xs text-green-600">+0.2</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
