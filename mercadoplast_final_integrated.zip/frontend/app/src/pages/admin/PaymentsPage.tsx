import React, { useState, useEffect } from 'react';
import { 
  CreditCard, 
  DollarSign, 
  Clock, 
  CheckCircle, 
  XCircle,
  Eye,
  Search,
  Filter,
  Download,
  User,
  Calendar,
  AlertTriangle,
  Banknote,
  TrendingUp
} from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

import { paymentService } from '@/services/paymentService';
import { PaymentAdmin } from '@/types';
import { cn } from '@/lib/utils';

// Utility functions
const formatCurrency = (value: number): string => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(value);
};

const formatNumber = (value: number): string => {
  return new Intl.NumberFormat('pt-BR').format(value);
};

const PaymentsPage: React.FC = () => {
  const [payments, setPayments] = useState<PaymentAdmin[]>([]);
  const [filteredPayments, setFilteredPayments] = useState<PaymentAdmin[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'completed' | 'failed'>('all');
  const [methodFilter, setMethodFilter] = useState<'all' | 'pix' | 'credit_card' | 'bank_transfer'>('all');
  const [selectedPayment, setSelectedPayment] = useState<PaymentAdmin | null>(null);
  const [confirmNote, setConfirmNote] = useState('');
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [stats, setStats] = useState({
    total: 0,
    pending: 0,
    completed: 0,
    failed: 0,
    totalRevenue: 0,
    pendingRevenue: 0,
  });

  useEffect(() => {
    loadPayments();
    loadStats();
  }, []);

  useEffect(() => {
    filterPayments();
  }, [payments, searchTerm, statusFilter, methodFilter]);

  const loadPayments = async () => {
    try {
      setLoading(true);
      const data = await paymentService.getPayments();
      setPayments(data);
    } catch (error) {
      toast.error('Erro ao carregar pagamentos');
      console.error('Erro ao carregar pagamentos:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadStats = async () => {
    try {
      const data = await paymentService.getPaymentStats();
      setStats(data);
    } catch (error) {
      console.error('Erro ao carregar estatísticas:', error);
    }
  };

  const filterPayments = () => {
    let filtered = payments;

    if (searchTerm) {
      filtered = filtered.filter(payment => 
        payment.user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
        payment.user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        payment.external_id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        payment.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter(payment => payment.status === statusFilter);
    }

    if (methodFilter !== 'all') {
      filtered = filtered.filter(payment => payment.payment_method === methodFilter);
    }

    // Ordenar por data de criação (mais recentes primeiro)
    filtered.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    setFilteredPayments(filtered);
  };

  const handleConfirmPayment = async (payment: PaymentAdmin) => {
    if (!payment.external_id) {
      toast.error('ID externo não encontrado');
      return;
    }

    try {
      setProcessingId(payment.id);
      
      await paymentService.confirmPayment({
        user_id: payment.user_id,
        external_id: payment.external_id,
        proof_url: payment.proof_url || '',
        note: confirmNote,
      });

      // Atualizar o pagamento localmente
      setPayments(prev => prev.map(p => 
        p.id === payment.id 
          ? { 
              ...p, 
              status: 'completed' as const,
              confirmed_at: new Date().toISOString(),
              confirmed_by: 'admin'
            }
          : p
      ));

      // Atualizar estatísticas
      await loadStats();

      toast.success('Pagamento confirmado com sucesso');
      setSelectedPayment(null);
      setConfirmNote('');
    } catch (error) {
      toast.error('Erro ao confirmar pagamento');
      console.error('Erro ao confirmar pagamento:', error);
    } finally {
      setProcessingId(null);
    }
  };

  const getStatusBadge = (status: PaymentAdmin['status']) => {
    const variants = {
      pending: { variant: 'secondary' as const, icon: Clock, text: 'Pendente', color: 'text-yellow-600' },
      completed: { variant: 'default' as const, icon: CheckCircle, text: 'Concluído', color: 'text-green-600' },
      failed: { variant: 'destructive' as const, icon: XCircle, text: 'Falhou', color: 'text-red-600' },
    };

    const config = variants[status];
    const Icon = config.icon;

    return (
      <Badge variant={config.variant} className="flex items-center gap-1">
        <Icon className="h-3 w-3" />
        {config.text}
      </Badge>
    );
  };

  const getMethodBadge = (method: PaymentAdmin['payment_method']) => {
    const variants = {
      pix: { text: 'PIX', color: 'bg-green-100 text-green-800' },
      credit_card: { text: 'Cartão', color: 'bg-blue-100 text-blue-800' },
      bank_transfer: { text: 'Transferência', color: 'bg-purple-100 text-purple-800' },
    };

    const config = variants[method];

    return (
      <Badge variant="outline" className={config.color}>
        {config.text}
      </Badge>
    );
  };

  const handleViewProof = (proofUrl: string) => {
    window.open(proofUrl, '_blank');
  };

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-32" />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => (
            <Card key={i}>
              <CardContent className="p-4">
                <Skeleton className="h-16 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
        
        <Card>
          <CardContent className="p-6">
            <Skeleton className="h-64 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Gerenciamento de Pagamentos</h1>
          <p className="text-muted-foreground">
            Monitore e gerencie todos os pagamentos da plataforma
          </p>
        </div>
        
        <Button onClick={loadPayments} variant="outline">
          <TrendingUp className="h-4 w-4 mr-2" />
          Atualizar
        </Button>
      </div>

      {/* Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total de Pagamentos</p>
                <p className="text-2xl font-bold">{stats.total}</p>
              </div>
              <CreditCard className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Pendentes</p>
                <p className="text-2xl font-bold text-yellow-600">{stats.pending}</p>
                <p className="text-xs text-muted-foreground">
                  {formatCurrency(stats.pendingRevenue)}
                </p>
              </div>
              <Clock className="h-8 w-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Concluídos</p>
                <p className="text-2xl font-bold text-green-600">{stats.completed}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Receita Total</p>
                <p className="text-2xl font-bold text-green-600">
                  {formatCurrency(stats.totalRevenue)}
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filtros */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Filtros</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 flex-wrap">
            <div className="flex-1 min-w-64">
              <Input
                placeholder="Buscar por usuário, email, ID externo..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
              />
            </div>
            
            <Select value={statusFilter} onValueChange={(value) => setStatusFilter(value as any)}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os Status</SelectItem>
                <SelectItem value="pending">Pendente</SelectItem>
                <SelectItem value="completed">Concluído</SelectItem>
                <SelectItem value="failed">Falhou</SelectItem>
              </SelectContent>
            </Select>

            <Select value={methodFilter} onValueChange={(value) => setMethodFilter(value as any)}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Método" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os Métodos</SelectItem>
                <SelectItem value="pix">PIX</SelectItem>
                <SelectItem value="credit_card">Cartão de Crédito</SelectItem>
                <SelectItem value="bank_transfer">Transferência</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Lista de Pagamentos */}
      <Card>
        <CardHeader>
          <CardTitle>Pagamentos ({filteredPayments.length})</CardTitle>
          <CardDescription>
            Lista completa de todos os pagamentos da plataforma
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredPayments.length === 0 ? (
            <div className="text-center py-8">
              <CreditCard className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Nenhum pagamento encontrado</h3>
              <p className="text-muted-foreground">
                {searchTerm || statusFilter !== 'all' || methodFilter !== 'all'
                  ? 'Tente ajustar os filtros para ver mais resultados'
                  : 'Não há pagamentos registrados no momento'
                }
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Usuário</TableHead>
                    <TableHead>Descrição</TableHead>
                    <TableHead>Valor</TableHead>
                    <TableHead>Método</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead>Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPayments.map((payment) => (
                    <TableRow key={payment.id} className="hover:bg-muted/50">
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                            <User className="h-4 w-4 text-blue-600" />
                          </div>
                          <div>
                            <p className="font-medium">{payment.user.username}</p>
                            <p className="text-sm text-muted-foreground">{payment.user.email}</p>
                          </div>
                        </div>
                      </TableCell>
                      
                      <TableCell>
                        <div>
                          <p className="font-medium">{payment.description}</p>
                          {payment.external_id && (
                            <p className="text-sm text-muted-foreground">ID: {payment.external_id}</p>
                          )}
                        </div>
                      </TableCell>
                      
                      <TableCell>
                        <p className="font-bold text-green-600">
                          {formatCurrency(payment.amount)}
                        </p>
                      </TableCell>
                      
                      <TableCell>
                        {getMethodBadge(payment.payment_method)}
                      </TableCell>
                      
                      <TableCell>
                        {getStatusBadge(payment.status)}
                      </TableCell>
                      
                      <TableCell>
                        <div className="text-sm">
                          <p>{format(new Date(payment.created_at), 'dd/MM/yyyy', { locale: ptBR })}</p>
                          <p className="text-muted-foreground">
                            {format(new Date(payment.created_at), 'HH:mm', { locale: ptBR })}
                          </p>
                        </div>
                      </TableCell>
                      
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => setSelectedPayment(payment)}
                              >
                                <Eye className="h-3 w-3" />
                              </Button>
                            </DialogTrigger>
                            
                            <DialogContent className="max-w-2xl">
                              <DialogHeader>
                                <DialogTitle>Detalhes do Pagamento</DialogTitle>
                                <DialogDescription>
                                  Informações completas sobre este pagamento
                                </DialogDescription>
                              </DialogHeader>
                              
                              <div className="space-y-4">
                                {/* Informações do Usuário */}
                                <div className="p-4 bg-gray-50 rounded-lg">
                                  <h4 className="font-medium mb-2">Informações do Usuário</h4>
                                  <div className="grid grid-cols-2 gap-4 text-sm">
                                    <div>
                                      <span className="text-muted-foreground">Nome:</span>
                                      <p className="font-medium">{payment.user.username}</p>
                                    </div>
                                    <div>
                                      <span className="text-muted-foreground">Email:</span>
                                      <p className="font-medium">{payment.user.email}</p>
                                    </div>
                                    <div>
                                      <span className="text-muted-foreground">Tipo:</span>
                                      <p className="font-medium">
                                        {payment.user.premium ? 'Premium' : 'Gratuito'}
                                      </p>
                                    </div>
                                    <div>
                                      <span className="text-muted-foreground">KYC:</span>
                                      <p className="font-medium capitalize">{payment.user.kycStatus}</p>
                                    </div>
                                  </div>
                                </div>

                                {/* Detalhes do Pagamento */}
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <label className="text-sm font-medium text-muted-foreground">Valor</label>
                                    <p className="text-lg font-bold text-green-600">
                                      {formatCurrency(payment.amount)}
                                    </p>
                                  </div>
                                  
                                  <div>
                                    <label className="text-sm font-medium text-muted-foreground">Status</label>
                                    <div className="mt-1">
                                      {getStatusBadge(payment.status)}
                                    </div>
                                  </div>
                                  
                                  <div>
                                    <label className="text-sm font-medium text-muted-foreground">Método</label>
                                    <div className="mt-1">
                                      {getMethodBadge(payment.payment_method)}
                                    </div>
                                  </div>
                                  
                                  <div>
                                    <label className="text-sm font-medium text-muted-foreground">ID Externo</label>
                                    <p className="font-mono text-sm">{payment.external_id || 'N/A'}</p>
                                  </div>
                                </div>

                                {/* Datas */}
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <label className="text-sm font-medium text-muted-foreground">Criado em</label>
                                    <p>{format(new Date(payment.created_at), 'dd/MM/yyyy HH:mm', { locale: ptBR })}</p>
                                  </div>
                                  
                                  {payment.confirmed_at && (
                                    <div>
                                      <label className="text-sm font-medium text-muted-foreground">Confirmado em</label>
                                      <p>{format(new Date(payment.confirmed_at), 'dd/MM/yyyy HH:mm', { locale: ptBR })}</p>
                                      {payment.confirmed_by && (
                                        <p className="text-sm text-muted-foreground">Por: {payment.confirmed_by}</p>
                                      )}
                                    </div>
                                  )}
                                </div>

                                {/* Comprovante */}
                                {payment.proof_url && (
                                  <div>
                                    <label className="text-sm font-medium text-muted-foreground">Comprovante</label>
                                    <div className="mt-1">
                                      <Button
                                        size="sm"
                                        variant="outline"
                                        onClick={() => handleViewProof(payment.proof_url!)}
                                      >
                                        <Eye className="h-4 w-4 mr-2" />
                                        Visualizar Comprovante
                                      </Button>
                                    </div>
                                  </div>
                                )}

                                {/* Motivo da Falha */}
                                {payment.status === 'failed' && payment.failure_reason && (
                                  <Alert>
                                    <AlertTriangle className="h-4 w-4" />
                                    <AlertDescription>
                                      <strong>Motivo da falha:</strong> {payment.failure_reason}
                                    </AlertDescription>
                                  </Alert>
                                )}

                                {/* Ações para Pagamentos Pendentes */}
                                {payment.status === 'pending' && (
                                  <div className="space-y-3 pt-4 border-t">
                                    <div>
                                      <label className="text-sm font-medium">Observações da Confirmação</label>
                                      <Textarea
                                        placeholder="Adicione observações sobre a confirmação..."
                                        value={confirmNote}
                                        onChange={(e) => setConfirmNote(e.target.value)}
                                        className="mt-1"
                                      />
                                    </div>
                                    
                                    <Button
                                      onClick={() => handleConfirmPayment(payment)}
                                      disabled={processingId === payment.id}
                                      className="w-full"
                                    >
                                      <CheckCircle className="h-4 w-4 mr-2" />
                                      {processingId === payment.id ? 'Confirmando...' : 'Confirmar Pagamento'}
                                    </Button>
                                  </div>
                                )}
                              </div>
                            </DialogContent>
                          </Dialog>

                          {payment.proof_url && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleViewProof(payment.proof_url!)}
                            >
                              <Download className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default PaymentsPage;
