import React, { useState, useEffect } from 'react';
import { 
  Megaphone, 
  Plus, 
  Edit, 
  Trash2, 
  Eye,
  Search,
  Filter,
  BarChart3,
  MousePointer,
  Monitor,
  ToggleLeft,
  ToggleRight,
  ExternalLink,
  Image as ImageIcon,
  Calendar,
  TrendingUp
} from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';
import { Switch } from '@/components/ui/switch';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';

import { adService } from '@/services/adAdminService';
import { Advertisement, CreateAdvertisementRequest } from '@/types';
import { cn } from '@/lib/utils';

// Utility functions
const formatNumber = (value: number): string => {
  return new Intl.NumberFormat('pt-BR').format(value);
};

const adSchema = z.object({
  title: z.string().min(1, 'Título é obrigatório').max(100, 'Título muito longo'),
  content: z.string().min(1, 'Conteúdo é obrigatório').max(500, 'Conteúdo muito longo'),
  image_url: z.string().url('URL da imagem inválida').optional().or(z.literal('')),
  link_url: z.string().url('URL do link é obrigatória'),
  type: z.enum(['banner', 'sidebar', 'popup']),
  category: z.string().optional(),
  location: z.string().optional(),
});

type AdFormData = z.infer<typeof adSchema>;

const AdsPage: React.FC = () => {
  const [ads, setAds] = useState<Advertisement[]>([]);
  const [filteredAds, setFilteredAds] = useState<Advertisement[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'banner' | 'sidebar' | 'popup'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [editingAd, setEditingAd] = useState<Advertisement | null>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [stats, setStats] = useState({
    totalAds: 0,
    activeAds: 0,
    totalClicks: 0,
    totalImpressions: 0,
    ctr: 0,
    topPerformingAds: [] as Advertisement[],
  });

  const form = useForm<AdFormData>({
    resolver: zodResolver(adSchema),
    defaultValues: {
      title: '',
      content: '',
      image_url: '',
      link_url: '',
      type: 'banner',
      category: '',
      location: '',
    },
  });

  useEffect(() => {
    loadAds();
    loadStats();
  }, []);

  useEffect(() => {
    filterAds();
  }, [ads, searchTerm, typeFilter, statusFilter]);

  const loadAds = async () => {
    try {
      setLoading(true);
      const data = await adService.getAdvertisements();
      setAds(data);
    } catch (error) {
      toast.error('Erro ao carregar anúncios');
      console.error('Erro ao carregar anúncios:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadStats = async () => {
    try {
      const data = await adService.getStats();
      setStats(data);
    } catch (error) {
      console.error('Erro ao carregar estatísticas:', error);
    }
  };

  const filterAds = () => {
    let filtered = ads;

    if (searchTerm) {
      filtered = filtered.filter(ad => 
        ad.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        ad.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
        ad.category?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (typeFilter !== 'all') {
      filtered = filtered.filter(ad => ad.type === typeFilter);
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter(ad => 
        statusFilter === 'active' ? ad.active : !ad.active
      );
    }

    // Ordenar por data de criação (mais recentes primeiro)
    filtered.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    setFilteredAds(filtered);
  };

  const handleCreateAd = async (data: AdFormData) => {
    try {
      const newAd = await adService.createAdvertisement({
        ...data,
        image_url: data.image_url || undefined,
      });
      
      setAds(prev => [newAd, ...prev]);
      await loadStats();
      
      toast.success('Anúncio criado com sucesso');
      setIsCreateDialogOpen(false);
      form.reset();
    } catch (error) {
      toast.error('Erro ao criar anúncio');
      console.error('Erro ao criar anúncio:', error);
    }
  };

  const handleEditAd = async (data: AdFormData) => {
    if (!editingAd) return;

    try {
      const updatedAd = await adService.updateAdvertisement(editingAd.id, {
        ...data,
        image_url: data.image_url || undefined,
      });
      
      setAds(prev => prev.map(ad => ad.id === editingAd.id ? updatedAd : ad));
      await loadStats();
      
      toast.success('Anúncio atualizado com sucesso');
      setIsEditDialogOpen(false);
      setEditingAd(null);
      form.reset();
    } catch (error) {
      toast.error('Erro ao atualizar anúncio');
      console.error('Erro ao atualizar anúncio:', error);
    }
  };

  const handleDeleteAd = async (id: string) => {
    if (!confirm('Tem certeza que deseja excluir este anúncio?')) return;

    try {
      setProcessingId(id);
      await adService.deleteAdvertisement(id);
      
      setAds(prev => prev.filter(ad => ad.id !== id));
      await loadStats();
      
      toast.success('Anúncio excluído com sucesso');
    } catch (error) {
      toast.error('Erro ao excluir anúncio');
      console.error('Erro ao excluir anúncio:', error);
    } finally {
      setProcessingId(null);
    }
  };

  const handleToggleStatus = async (ad: Advertisement) => {
    try {
      setProcessingId(ad.id);
      const updatedAd = await adService.toggleAdStatus(ad.id);
      
      setAds(prev => prev.map(a => a.id === ad.id ? updatedAd : a));
      await loadStats();
      
      toast.success(`Anúncio ${updatedAd.active ? 'ativado' : 'desativado'} com sucesso`);
    } catch (error) {
      toast.error('Erro ao alterar status do anúncio');
      console.error('Erro ao alterar status:', error);
    } finally {
      setProcessingId(null);
    }
  };

  const openEditDialog = (ad: Advertisement) => {
    setEditingAd(ad);
    form.reset({
      title: ad.title,
      content: ad.content,
      image_url: ad.image_url || '',
      link_url: ad.link_url,
      type: ad.type,
      category: ad.category || '',
      location: ad.location || '',
    });
    setIsEditDialogOpen(true);
  };

  const getTypeBadge = (type: Advertisement['type']) => {
    const variants = {
      banner: { text: 'Banner', color: 'bg-blue-100 text-blue-800' },
      sidebar: { text: 'Sidebar', color: 'bg-green-100 text-green-800' },
      popup: { text: 'Popup', color: 'bg-purple-100 text-purple-800' },
    };

    const config = variants[type];

    return (
      <Badge variant="outline" className={config.color}>
        {config.text}
      </Badge>
    );
  };

  const calculateCTR = (clicks: number, impressions: number) => {
    if (impressions === 0) return 0;
    return ((clicks / impressions) * 100);
  };

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-32" />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => (
            <Card key={i}>
              <CardContent className="p-4">
                <Skeleton className="h-16 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
        
        <Card>
          <CardContent className="p-6">
            <Skeleton className="h-64 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Gerenciamento de Anúncios</h1>
          <p className="text-muted-foreground">
            Crie, edite e monitore anúncios da plataforma
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button onClick={loadAds} variant="outline">
            <BarChart3 className="h-4 w-4 mr-2" />
            Atualizar
          </Button>
          
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Novo Anúncio
              </Button>
            </DialogTrigger>
            
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Criar Novo Anúncio</DialogTitle>
                <DialogDescription>
                  Preencha as informações para criar um novo anúncio
                </DialogDescription>
              </DialogHeader>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(handleCreateAd)} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Título</FormLabel>
                          <FormControl>
                            <Input placeholder="Título do anúncio" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tipo</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Selecione o tipo" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="banner">Banner</SelectItem>
                              <SelectItem value="sidebar">Sidebar</SelectItem>
                              <SelectItem value="popup">Popup</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="content"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Conteúdo</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Descrição do anúncio" 
                            className="min-h-20"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="image_url"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>URL da Imagem (opcional)</FormLabel>
                          <FormControl>
                            <Input placeholder="https://exemplo.com/imagem.jpg" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="link_url"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>URL de Destino</FormLabel>
                          <FormControl>
                            <Input placeholder="https://exemplo.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Categoria (opcional)</FormLabel>
                          <FormControl>
                            <Input placeholder="polimeros, equipamentos, etc." {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Localização (opcional)</FormLabel>
                          <FormControl>
                            <Input placeholder="homepage, feed, dashboard, etc." {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="flex gap-2 pt-4">
                    <Button type="submit" className="flex-1">
                      <Plus className="h-4 w-4 mr-2" />
                      Criar Anúncio
                    </Button>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => {
                        setIsCreateDialogOpen(false);
                        form.reset();
                      }}
                    >
                      Cancelar
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total de Anúncios</p>
                <p className="text-2xl font-bold">{stats.totalAds}</p>
              </div>
              <Megaphone className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Anúncios Ativos</p>
                <p className="text-2xl font-bold text-green-600">{stats.activeAds}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total de Cliques</p>
                <p className="text-2xl font-bold text-purple-600">
                  {formatNumber(stats.totalClicks)}
                </p>
              </div>
              <MousePointer className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">CTR Médio</p>
                <p className="text-2xl font-bold text-orange-600">
                  {stats.ctr.toFixed(2)}%
                </p>
              </div>
              <BarChart3 className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filtros */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Filtros</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 flex-wrap">
            <div className="flex-1 min-w-64">
              <Input
                placeholder="Buscar por título, conteúdo ou categoria..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
              />
            </div>
            
            <Select value={typeFilter} onValueChange={(value) => setTypeFilter(value as any)}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os Tipos</SelectItem>
                <SelectItem value="banner">Banner</SelectItem>
                <SelectItem value="sidebar">Sidebar</SelectItem>
                <SelectItem value="popup">Popup</SelectItem>
              </SelectContent>
            </Select>

            <Select value={statusFilter} onValueChange={(value) => setStatusFilter(value as any)}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os Status</SelectItem>
                <SelectItem value="active">Ativo</SelectItem>
                <SelectItem value="inactive">Inativo</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Lista de Anúncios */}
      <div className="space-y-4">
        {filteredAds.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <Megaphone className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Nenhum anúncio encontrado</h3>
              <p className="text-muted-foreground">
                {searchTerm || typeFilter !== 'all' || statusFilter !== 'all'
                  ? 'Tente ajustar os filtros para ver mais resultados'
                  : 'Crie seu primeiro anúncio para começar'
                }
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredAds.map((ad) => (
            <Card key={ad.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  {/* Imagem do Anúncio */}
                  <div className="w-24 h-16 bg-gray-100 rounded-lg flex items-center justify-center overflow-hidden flex-shrink-0">
                    {ad.image_url ? (
                      <img 
                        src={ad.image_url} 
                        alt={ad.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <ImageIcon className="h-6 w-6 text-gray-400" />
                    )}
                  </div>

                  {/* Conteúdo Principal */}
                  <div className="flex-1 space-y-2">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-semibold text-lg">{ad.title}</h3>
                        <p className="text-muted-foreground text-sm">{ad.content}</p>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        {getTypeBadge(ad.type)}
                        <Badge variant={ad.active ? 'default' : 'secondary'}>
                          {ad.active ? 'Ativo' : 'Inativo'}
                        </Badge>
                      </div>
                    </div>

                    {/* Informações Adicionais */}
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        {format(new Date(ad.created_at), 'dd/MM/yyyy', { locale: ptBR })}
                      </div>
                      
                      {ad.category && (
                        <div>
                          <span className="font-medium">Categoria:</span> {ad.category}
                        </div>
                      )}
                      
                      {ad.location && (
                        <div>
                          <span className="font-medium">Local:</span> {ad.location}
                        </div>
                      )}
                    </div>

                    {/* Métricas */}
                    <div className="flex items-center gap-6 text-sm">
                      <div className="flex items-center gap-1">
                        <Monitor className="h-4 w-4 text-blue-600" />
                        <span className="font-medium">{formatNumber(ad.impressions)}</span>
                        <span className="text-muted-foreground">impressões</span>
                      </div>
                      
                      <div className="flex items-center gap-1">
                        <MousePointer className="h-4 w-4 text-green-600" />
                        <span className="font-medium">{formatNumber(ad.clicks)}</span>
                        <span className="text-muted-foreground">cliques</span>
                      </div>
                      
                      <div className="flex items-center gap-1">
                        <BarChart3 className="h-4 w-4 text-purple-600" />
                        <span className="font-medium">{calculateCTR(ad.clicks, ad.impressions).toFixed(2)}%</span>
                        <span className="text-muted-foreground">CTR</span>
                      </div>
                    </div>

                    {/* URL de Destino */}
                    <div className="flex items-center gap-2 text-sm">
                      <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      <a 
                        href={ad.link_url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:underline truncate"
                      >
                        {ad.link_url}
                      </a>
                    </div>
                  </div>

                  {/* Ações */}
                  <div className="flex flex-col gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleToggleStatus(ad)}
                      disabled={processingId === ad.id}
                    >
                      {ad.active ? (
                        <ToggleRight className="h-4 w-4" />
                      ) : (
                        <ToggleLeft className="h-4 w-4" />
                      )}
                    </Button>
                    
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => openEditDialog(ad)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDeleteAd(ad.id)}
                      disabled={processingId === ad.id}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Dialog de Edição */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Editar Anúncio</DialogTitle>
            <DialogDescription>
              Atualize as informações do anúncio
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleEditAd)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Título</FormLabel>
                      <FormControl>
                        <Input placeholder="Título do anúncio" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tipo</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o tipo" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="banner">Banner</SelectItem>
                          <SelectItem value="sidebar">Sidebar</SelectItem>
                          <SelectItem value="popup">Popup</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="content"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Conteúdo</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Descrição do anúncio" 
                        className="min-h-20"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="image_url"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>URL da Imagem (opcional)</FormLabel>
                      <FormControl>
                        <Input placeholder="https://exemplo.com/imagem.jpg" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="link_url"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>URL de Destino</FormLabel>
                      <FormControl>
                        <Input placeholder="https://exemplo.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Categoria (opcional)</FormLabel>
                      <FormControl>
                        <Input placeholder="polimeros, equipamentos, etc." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="location"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Localização (opcional)</FormLabel>
                      <FormControl>
                        <Input placeholder="homepage, feed, dashboard, etc." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="flex gap-2 pt-4">
                <Button type="submit" className="flex-1">
                  <Edit className="h-4 w-4 mr-2" />
                  Atualizar Anúncio
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => {
                    setIsEditDialogOpen(false);
                    setEditingAd(null);
                    form.reset();
                  }}
                >
                  Cancelar
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdsPage;
