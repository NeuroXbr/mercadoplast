import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  User, 
  Calendar, 
  CheckCircle, 
  XCircle, 
  Eye,
  Download,
  Clock,
  AlertCircle,
  Filter,
  Search
} from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';

import { kycService } from '@/services/kycService';
import { KYCPending, KYCDocument, KYCStatus } from '@/types';
import { cn } from '@/lib/utils';

const KYCReviewPage: React.FC = () => {
  const [kycRequests, setKycRequests] = useState<KYCPending[]>([]);
  const [filteredRequests, setFilteredRequests] = useState<KYCPending[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<KYCStatus | 'all'>('all');
  const [selectedRequest, setSelectedRequest] = useState<KYCPending | null>(null);
  const [reviewNote, setReviewNote] = useState('');
  const [processingId, setProcessingId] = useState<string | null>(null);

  useEffect(() => {
    loadKYCRequests();
  }, []);

  useEffect(() => {
    filterRequests();
  }, [kycRequests, searchTerm, statusFilter]);

  const loadKYCRequests = async () => {
    try {
      setLoading(true);
      const data = await kycService.getAllKYC();
      setKycRequests(data);
    } catch (error) {
      toast.error('Erro ao carregar solicitações KYC');
      console.error('Erro ao carregar KYC:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterRequests = () => {
    let filtered = kycRequests;

    if (searchTerm) {
      filtered = filtered.filter(request => 
        request.user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
        request.user.email.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter(request => request.status === statusFilter);
    }

    setFilteredRequests(filtered);
  };

  const handleReviewKYC = async (id: string, status: 'approved' | 'rejected') => {
    try {
      setProcessingId(id);
      await kycService.updateKYCStatus(id, status, reviewNote);
      
      // Atualizar o status localmente
      setKycRequests(prev => prev.map(request => 
        request.id === id 
          ? { 
              ...request, 
              status,
              reviewed_at: new Date().toISOString(),
              reviewed_by: 'admin',
              rejection_reason: status === 'rejected' ? reviewNote : undefined
            }
          : request
      ));

      toast.success(`KYC ${status === 'approved' ? 'aprovado' : 'rejeitado'} com sucesso`);
      setSelectedRequest(null);
      setReviewNote('');
    } catch (error) {
      toast.error('Erro ao processar solicitação KYC');
      console.error('Erro ao processar KYC:', error);
    } finally {
      setProcessingId(null);
    }
  };

  const getStatusBadge = (status: KYCStatus) => {
    const variants = {
      pending: { variant: 'secondary' as const, icon: Clock, text: 'Pendente' },
      approved: { variant: 'default' as const, icon: CheckCircle, text: 'Aprovado' },
      rejected: { variant: 'destructive' as const, icon: XCircle, text: 'Rejeitado' },
    };

    const config = variants[status];
    const Icon = config.icon;

    return (
      <Badge variant={config.variant} className="flex items-center gap-1">
        <Icon className="h-3 w-3" />
        {config.text}
      </Badge>
    );
  };

  const getDocumentTypeLabel = (type: string) => {
    const labels = {
      cpf: 'CPF',
      cnpj: 'CNPJ',
      address_proof: 'Comprovante de Endereço',
      company_registration: 'Contrato Social',
    };
    return labels[type as keyof typeof labels] || type;
  };

  const formatFileSize = (bytes: number) => {
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    if (bytes === 0) return '0 Bytes';
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
  };

  const handleViewDocument = async (document: KYCDocument) => {
    try {
      const url = await kycService.getKYCDocument(document.object_path);
      window.open(url, '_blank');
    } catch (error) {
      toast.error('Erro ao carregar documento');
    }
  };

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-32" />
        </div>
        
        <div className="grid gap-4">
          {[1, 2, 3].map(i => (
            <Card key={i}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <Skeleton className="h-6 w-32" />
                  <Skeleton className="h-6 w-20" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-3/4" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Revisão de KYC</h1>
          <p className="text-muted-foreground">
            Gerencie as solicitações de verificação de identidade
          </p>
        </div>
        
        <Button onClick={loadKYCRequests} variant="outline">
          <AlertCircle className="h-4 w-4 mr-2" />
          Atualizar
        </Button>
      </div>

      {/* Filtros */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Filtros</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <div className="flex-1">
              <Input
                placeholder="Buscar por usuário ou email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
              />
            </div>
            
            <Select value={statusFilter} onValueChange={(value) => setStatusFilter(value as KYCStatus | 'all')}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="pending">Pendente</SelectItem>
                <SelectItem value="approved">Aprovado</SelectItem>
                <SelectItem value="rejected">Rejeitado</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total</p>
                <p className="text-2xl font-bold">{kycRequests.length}</p>
              </div>
              <FileText className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Pendentes</p>
                <p className="text-2xl font-bold text-yellow-600">
                  {kycRequests.filter(r => r.status === 'pending').length}
                </p>
              </div>
              <Clock className="h-8 w-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Aprovados</p>
                <p className="text-2xl font-bold text-green-600">
                  {kycRequests.filter(r => r.status === 'approved').length}
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Rejeitados</p>
                <p className="text-2xl font-bold text-red-600">
                  {kycRequests.filter(r => r.status === 'rejected').length}
                </p>
              </div>
              <XCircle className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Lista de Solicitações */}
      <div className="space-y-4">
        {filteredRequests.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Nenhuma solicitação encontrada</h3>
              <p className="text-muted-foreground">
                {searchTerm || statusFilter !== 'all' 
                  ? 'Tente ajustar os filtros para ver mais resultados'
                  : 'Não há solicitações de KYC no momento'
                }
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredRequests.map((request) => (
            <Card key={request.id} className="hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <User className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{request.user.username}</CardTitle>
                      <CardDescription>{request.user.email}</CardDescription>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {getStatusBadge(request.status)}
                    {request.user.premium && (
                      <Badge variant="outline" className="text-purple-600 border-purple-200">
                        Premium
                      </Badge>
                    )}
                  </div>
                </div>
              </CardHeader>
              
              <CardContent>
                <div className="space-y-4">
                  {/* Informações da Solicitação */}
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      Enviado em {format(new Date(request.submitted_at), 'dd/MM/yyyy HH:mm', { locale: ptBR })}
                    </div>
                    
                    {request.reviewed_at && (
                      <div className="flex items-center gap-1">
                        <CheckCircle className="h-4 w-4" />
                        Revisado em {format(new Date(request.reviewed_at), 'dd/MM/yyyy HH:mm', { locale: ptBR })}
                      </div>
                    )}
                  </div>

                  {/* Documentos */}
                  <div>
                    <h4 className="font-medium mb-2">Documentos ({request.documents.length})</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {request.documents.map((doc) => (
                        <div key={doc.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center gap-2">
                            <FileText className="h-4 w-4 text-gray-600" />
                            <div>
                              <p className="text-sm font-medium">{getDocumentTypeLabel(doc.type)}</p>
                              <p className="text-xs text-muted-foreground">
                                {formatFileSize(doc.file_size)} • {doc.mime_type}
                              </p>
                            </div>
                          </div>
                          
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleViewDocument(doc)}
                          >
                            <Eye className="h-3 w-3" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Motivo da Rejeição */}
                  {request.status === 'rejected' && request.rejection_reason && (
                    <Alert>
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>
                        <strong>Motivo da rejeição:</strong> {request.rejection_reason}
                      </AlertDescription>
                    </Alert>
                  )}

                  {/* Ações */}
                  {request.status === 'pending' && (
                    <div className="flex gap-2 pt-2">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button 
                            size="sm" 
                            onClick={() => setSelectedRequest(request)}
                            disabled={processingId === request.id}
                          >
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Revisar
                          </Button>
                        </DialogTrigger>
                        
                        <DialogContent className="max-w-2xl">
                          <DialogHeader>
                            <DialogTitle>Revisar KYC - {request.user.username}</DialogTitle>
                            <DialogDescription>
                              Analise os documentos e tome uma decisão sobre esta solicitação
                            </DialogDescription>
                          </DialogHeader>
                          
                          <div className="space-y-4">
                            {/* Informações do Usuário */}
                            <div className="p-4 bg-gray-50 rounded-lg">
                              <h4 className="font-medium mb-2">Informações do Usuário</h4>
                              <div className="grid grid-cols-2 gap-4 text-sm">
                                <div>
                                  <span className="text-muted-foreground">Nome:</span>
                                  <p className="font-medium">{request.user.username}</p>
                                </div>
                                <div>
                                  <span className="text-muted-foreground">Email:</span>
                                  <p className="font-medium">{request.user.email}</p>
                                </div>
                                <div>
                                  <span className="text-muted-foreground">Cadastrado em:</span>
                                  <p className="font-medium">
                                    {format(new Date(request.user.created_at), 'dd/MM/yyyy', { locale: ptBR })}
                                  </p>
                                </div>
                                <div>
                                  <span className="text-muted-foreground">Tipo:</span>
                                  <p className="font-medium">
                                    {request.user.premium ? 'Premium' : 'Gratuito'}
                                  </p>
                                </div>
                              </div>
                            </div>

                            {/* Documentos para Revisão */}
                            <div>
                              <h4 className="font-medium mb-2">Documentos para Análise</h4>
                              <div className="space-y-2">
                                {request.documents.map((doc) => (
                                  <div key={doc.id} className="flex items-center justify-between p-3 border rounded-lg">
                                    <div>
                                      <p className="font-medium">{getDocumentTypeLabel(doc.type)}</p>
                                      <p className="text-sm text-muted-foreground">
                                        {formatFileSize(doc.file_size)} • Enviado em {' '}
                                        {format(new Date(doc.uploaded_at), 'dd/MM/yyyy HH:mm', { locale: ptBR })}
                                      </p>
                                    </div>
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => handleViewDocument(doc)}
                                    >
                                      <Eye className="h-4 w-4 mr-2" />
                                      Visualizar
                                    </Button>
                                  </div>
                                ))}
                              </div>
                            </div>

                            {/* Nota da Revisão */}
                            <div>
                              <label className="text-sm font-medium">Observações (opcional)</label>
                              <Textarea
                                placeholder="Adicione observações sobre a revisão..."
                                value={reviewNote}
                                onChange={(e) => setReviewNote(e.target.value)}
                                className="mt-1"
                              />
                            </div>

                            {/* Botões de Ação */}
                            <div className="flex gap-2 pt-4">
                              <Button
                                onClick={() => handleReviewKYC(request.id, 'approved')}
                                disabled={processingId === request.id}
                                className="flex-1"
                              >
                                <CheckCircle className="h-4 w-4 mr-2" />
                                {processingId === request.id ? 'Processando...' : 'Aprovar'}
                              </Button>
                              
                              <Button
                                variant="destructive"
                                onClick={() => handleReviewKYC(request.id, 'rejected')}
                                disabled={processingId === request.id}
                                className="flex-1"
                              >
                                <XCircle className="h-4 w-4 mr-2" />
                                {processingId === request.id ? 'Processando...' : 'Rejeitar'}
                              </Button>
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};

export default KYCReviewPage;
