import React, { useEffect, useState } from 'react';
import { User, UsersResponse } from '@/types';
import { userService } from '@/services/userService';
import { usePagination } from '@/hooks/usePagination';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { 
  Search, 
  Eye, 
  Edit, 
  Trash2, 
  Users, 
  Crown,
  Shield,
  User as UserIcon,
  Loader2,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from 'sonner';

export function UsersPage() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [total, setTotal] = useState(0);
  
  const [pagination, paginationActions] = usePagination({
    initialLimit: 10,
  });

  useEffect(() => {
    loadUsers();
  }, [pagination.page, pagination.limit]);

  const loadUsers = async () => {
    try {
      setLoading(true);
      const response = await userService.getUsers({
        limit: pagination.limit,
        offset: pagination.offset,
      });
      
      setUsers(response.users);
      setTotal(response.total);
      paginationActions.setTotal(response.total);
    } catch (error: any) {
      console.error('Erro ao carregar usuários:', error);
      toast.error('Erro ao carregar usuários');
      
      // Mock data para desenvolvimento
      const mockUsers: User[] = [
        {
          id: '1',
          username: 'joao.silva',
          email: 'joao@empresa.com',
          role: 'user',
          premium: true,
          kycStatus: 'approved',
          created_at: '2024-01-15T10:30:00Z',
        },
        {
          id: '2',
          username: 'maria.santos',
          email: 'maria@plasticos.com',
          role: 'user',
          premium: false,
          kycStatus: 'pending',
          created_at: '2024-02-20T14:15:00Z',
        },
        {
          id: '3',
          username: 'admin.sistema',
          email: 'admin@mercadoplast.com',
          role: 'admin',
          premium: true,
          kycStatus: 'approved',
          created_at: '2024-01-01T00:00:00Z',
        },
      ];
      
      setUsers(mockUsers);
      setTotal(mockUsers.length);
      paginationActions.setTotal(mockUsers.length);
    } finally {
      setLoading(false);
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'admin':
        return 'bg-red-100 text-red-800';
      case 'moderator':
        return 'bg-blue-100 text-blue-800';
      case 'analyst':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getRoleText = (role: string) => {
    switch (role) {
      case 'admin':
        return 'Admin';
      case 'moderator':
        return 'Moderador';
      case 'analyst':
        return 'Analista';
      default:
        return 'Usuário';
    }
  };

  const getKYCStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  const getKYCStatusText = (status: string) => {
    switch (status) {
      case 'approved':
        return 'Aprovado';
      case 'rejected':
        return 'Rejeitado';
      default:
        return 'Pendente';
    }
  };

  const formatDate = (dateString: string) => {
    try {
      return formatDistanceToNow(new Date(dateString), {
        addSuffix: true,
        locale: ptBR,
      });
    } catch {
      return 'Data inválida';
    }
  };

  const getInitials = (username: string) => {
    return username.slice(0, 2).toUpperCase();
  };

  const filteredUsers = users.filter(user =>
    user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalPages = Math.ceil(total / pagination.limit);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Gerenciamento de Usuários</h1>
          <p className="text-muted-foreground mt-1">
            Visualize e gerencie todos os usuários da plataforma
          </p>
        </div>
        
        <div className="flex items-center space-x-2">
          <Badge variant="outline" className="bg-blue-50 text-blue-700">
            <Users className="w-4 h-4 mr-1" />
            {total} usuários
          </Badge>
        </div>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Filtros</CardTitle>
          <CardDescription>
            Busque e filtre usuários por nome ou email
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Buscar por nome ou email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Users Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Lista de Usuários</CardTitle>
          <CardDescription>
            {filteredUsers.length} usuário(s) encontrado(s)
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
            </div>
          ) : filteredUsers.length === 0 ? (
            <div className="text-center py-12">
              <Users className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Nenhum usuário encontrado</h3>
              <p className="text-muted-foreground">
                {searchTerm ? 'Tente ajustar sua busca' : 'Nenhum usuário cadastrado ainda'}
              </p>
            </div>
          ) : (
            <>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Usuário</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Premium</TableHead>
                      <TableHead>KYC</TableHead>
                      <TableHead>Cadastro</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredUsers.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell>
                          <div className="flex items-center space-x-3">
                            <Avatar className="h-10 w-10">
                              <AvatarFallback className="bg-blue-100 text-blue-600">
                                {getInitials(user.username)}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium">{user.username}</p>
                              <p className="text-sm text-muted-foreground">{user.email}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={getRoleColor(user.role)}>
                            {user.role === 'admin' && <Shield className="w-3 h-3 mr-1" />}
                            {getRoleText(user.role)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {user.premium ? (
                            <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white">
                              <Crown className="w-3 h-3 mr-1" />
                              Premium
                            </Badge>
                          ) : (
                            <Badge variant="secondary">
                              <UserIcon className="w-3 h-3 mr-1" />
                              Básico
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge className={getKYCStatusColor(user.kycStatus)}>
                            {getKYCStatusText(user.kycStatus)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <span className="text-sm text-muted-foreground">
                            {formatDate(user.created_at)}
                          </span>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end space-x-2">
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button 
                                  variant="ghost" 
                                  size="sm"
                                  onClick={() => setSelectedUser(user)}
                                >
                                  <Eye className="h-4 w-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Detalhes do Usuário</DialogTitle>
                                  <DialogDescription>
                                    Informações completas do usuário selecionado
                                  </DialogDescription>
                                </DialogHeader>
                                {selectedUser && (
                                  <div className="space-y-4">
                                    <div className="flex items-center space-x-4">
                                      <Avatar className="h-16 w-16">
                                        <AvatarFallback className="bg-blue-100 text-blue-600 text-lg">
                                          {getInitials(selectedUser.username)}
                                        </AvatarFallback>
                                      </Avatar>
                                      <div>
                                        <h3 className="text-lg font-semibold">{selectedUser.username}</h3>
                                        <p className="text-muted-foreground">{selectedUser.email}</p>
                                      </div>
                                    </div>
                                    
                                    <div className="grid grid-cols-2 gap-4">
                                      <div>
                                        <label className="text-sm font-medium text-muted-foreground">Role</label>
                                        <div className="mt-1">
                                          <Badge className={getRoleColor(selectedUser.role)}>
                                            {getRoleText(selectedUser.role)}
                                          </Badge>
                                        </div>
                                      </div>
                                      
                                      <div>
                                        <label className="text-sm font-medium text-muted-foreground">Plano</label>
                                        <div className="mt-1">
                                          {selectedUser.premium ? (
                                            <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white">
                                              Premium
                                            </Badge>
                                          ) : (
                                            <Badge variant="secondary">Básico</Badge>
                                          )}
                                        </div>
                                      </div>
                                      
                                      <div>
                                        <label className="text-sm font-medium text-muted-foreground">Status KYC</label>
                                        <div className="mt-1">
                                          <Badge className={getKYCStatusColor(selectedUser.kycStatus)}>
                                            {getKYCStatusText(selectedUser.kycStatus)}
                                          </Badge>
                                        </div>
                                      </div>
                                      
                                      <div>
                                        <label className="text-sm font-medium text-muted-foreground">Cadastro</label>
                                        <p className="text-sm mt-1">{formatDate(selectedUser.created_at)}</p>
                                      </div>
                                    </div>
                                    
                                    <div className="flex space-x-2 pt-4">
                                      <Button variant="outline" size="sm">
                                        <Edit className="h-4 w-4 mr-2" />
                                        Editar
                                      </Button>
                                      <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700">
                                        <Trash2 className="h-4 w-4 mr-2" />
                                        Excluir
                                      </Button>
                                    </div>
                                  </div>
                                )}
                              </DialogContent>
                            </Dialog>
                            
                            <Button variant="ghost" size="sm">
                              <Edit className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between mt-4">
                  <p className="text-sm text-muted-foreground">
                    Mostrando {pagination.offset + 1} a {Math.min(pagination.offset + pagination.limit, total)} de {total} usuários
                  </p>
                  
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={paginationActions.prevPage}
                      disabled={pagination.page === 1}
                    >
                      <ChevronLeft className="h-4 w-4" />
                      Anterior
                    </Button>
                    
                    <span className="text-sm">
                      Página {pagination.page} de {totalPages}
                    </span>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={paginationActions.nextPage}
                      disabled={!pagination.hasMore}
                    >
                      Próxima
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
