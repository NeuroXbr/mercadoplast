import React, { useEffect, useState } from 'react';
import { Payment } from '@/types';
import { paymentService } from '@/services/paymentService';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  CreditCard, 
  Crown, 
  Check, 
  Star,
  Zap,
  Shield,
  TrendingUp,
  Users,
  MessageCircle,
  ExternalLink,
  Loader2,
  AlertTriangle,
  CheckCircle
} from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/useAuth';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

const plans = [
  {
    id: 'basic',
    name: 'Básico',
    price: 0,
    period: 'Gratuito',
    description: 'Para começar no mercado de plásticos',
    features: [
      'Visualizar posts públicos',
      'Criar até 3 posts por mês',
      'Suporte por email',
      'Acesso a polímeros básicos',
    ],
    icon: <Users className="h-6 w-6" />,
    color: 'bg-gray-100 text-gray-800',
    buttonText: 'Plano Atual',
    popular: false,
  },
  {
    id: 'premium',
    name: 'Premium',
    price: 49.90,
    period: 'por mês',
    description: 'Para profissionais do setor',
    features: [
      'Posts ilimitados',
      'Acesso a todos os polímeros',
      'Análises de mercado',
      'Suporte prioritário',
      'Relatórios personalizados',
      'Networking exclusivo',
    ],
    icon: <Crown className="h-6 w-6" />,
    color: 'bg-gradient-to-r from-yellow-400 to-orange-500 text-white',
    buttonText: 'Assinar Premium',
    popular: true,
  },
  {
    id: 'enterprise',
    name: 'Empresarial',
    price: 199.90,
    period: 'por mês',
    description: 'Para empresas e distribuidores',
    features: [
      'Tudo do Premium',
      'API de integração',
      'Dashboard avançado',
      'Gerente de conta dedicado',
      'Treinamentos exclusivos',
      'Consultoria especializada',
    ],
    icon: <TrendingUp className="h-6 w-6" />,
    color: 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white',
    buttonText: 'Falar com Vendas',
    popular: false,
  },
];

export function PaymentsPage() {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingPayment, setProcessingPayment] = useState<string | null>(null);
  const { user, isPremium } = useAuth();

  useEffect(() => {
    loadPayments();
  }, []);

  const loadPayments = async () => {
    try {
      setLoading(true);
      const paymentsData = await paymentService.getMyPayments();
      setPayments(paymentsData);
    } catch (error) {
      console.error('Erro ao carregar pagamentos:', error);
      // Mock data para desenvolvimento
      const mockPayments: Payment[] = [
        {
          id: '1',
          user_id: user?.id || '1',
          amount: 49.90,
          status: 'completed',
          created_at: '2024-01-15T10:30:00Z',
          external_id: 'MP-123456',
          proof_url: 'https://example.com/proof.pdf',
        },
        {
          id: '2',
          user_id: user?.id || '1',
          amount: 49.90,
          status: 'pending',
          created_at: '2024-02-15T10:30:00Z',
          external_id: 'MP-789012',
        },
      ];
      setPayments(mockPayments);
    } finally {
      setLoading(false);
    }
  };

  const handleSubscribe = async (planId: string, amount: number) => {
    try {
      setProcessingPayment(planId);
      
      const response = await paymentService.createPaymentLink({
        amount,
        description: `Assinatura ${plans.find(p => p.id === planId)?.name}`,
      });

      // Abrir link de pagamento em nova aba
      window.open(response.checkout_url, '_blank', 'noopener,noreferrer');
      
      toast.success('Link de pagamento gerado! Complete o pagamento na nova aba.');
      
      // Recarregar pagamentos após alguns segundos
      setTimeout(() => {
        loadPayments();
      }, 3000);
    } catch (error: any) {
      console.error('Erro ao criar link de pagamento:', error);
      toast.error('Erro ao gerar link de pagamento');
    } finally {
      setProcessingPayment(null);
    }
  };

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  const getPaymentStatusText = (status: string) => {
    switch (status) {
      case 'completed':
        return 'Pago';
      case 'failed':
        return 'Falhou';
      default:
        return 'Pendente';
    }
  };

  const formatDate = (dateString: string) => {
    try {
      return formatDistanceToNow(new Date(dateString), {
        addSuffix: true,
        locale: ptBR,
      });
    } catch {
      return 'Data inválida';
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Planos e Pagamentos
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Escolha o plano ideal para suas necessidades no mercado de materiais plásticos
        </p>
      </div>

      {/* Current Plan Status */}
      {user && (
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Shield className="h-6 w-6 mr-2 text-blue-600" />
              Seu Plano Atual
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                {isPremium() ? (
                  <>
                    <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-3 py-1">
                      <Crown className="w-4 h-4 mr-1" />
                      Premium
                    </Badge>
                    <span className="text-muted-foreground">
                      Você tem acesso completo à plataforma
                    </span>
                  </>
                ) : (
                  <>
                    <Badge variant="secondary" className="px-3 py-1">
                      <Users className="w-4 h-4 mr-1" />
                      Básico
                    </Badge>
                    <span className="text-muted-foreground">
                      Upgrade para desbloquear recursos premium
                    </span>
                  </>
                )}
              </div>
              
              {!isPremium() && (
                <Button onClick={() => handleSubscribe('premium', 49.90)}>
                  <Crown className="h-4 w-4 mr-2" />
                  Fazer Upgrade
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
        {plans.map((plan) => {
          const isCurrentPlan = (plan.id === 'basic' && !isPremium()) || 
                               (plan.id === 'premium' && isPremium());
          const isProcessing = processingPayment === plan.id;

          return (
            <Card 
              key={plan.id} 
              className={`relative hover:shadow-xl transition-all duration-300 ${
                plan.popular ? 'ring-2 ring-blue-500 scale-105' : ''
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-blue-600 text-white px-4 py-1">
                    <Star className="w-3 h-3 mr-1" />
                    Mais Popular
                  </Badge>
                </div>
              )}
              
              <CardHeader className="text-center pb-4">
                <div className={`inline-flex items-center justify-center w-12 h-12 rounded-full mb-4 ${plan.color}`}>
                  {plan.icon}
                </div>
                <CardTitle className="text-2xl">{plan.name}</CardTitle>
                <CardDescription className="text-base">{plan.description}</CardDescription>
                
                <div className="mt-4">
                  <div className="text-4xl font-bold text-gray-900">
                    {plan.price === 0 ? 'Gratuito' : formatCurrency(plan.price)}
                  </div>
                  {plan.price > 0 && (
                    <div className="text-muted-foreground">{plan.period}</div>
                  )}
                </div>
              </CardHeader>
              
              <CardContent className="space-y-6">
                <ul className="space-y-3">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start space-x-3">
                      <Check className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <Button
                  className="w-full"
                  variant={isCurrentPlan ? "outline" : "default"}
                  disabled={isCurrentPlan || isProcessing}
                  onClick={() => {
                    if (plan.id === 'enterprise') {
                      window.open('mailto:vendas@mercadoplast.com', '_blank');
                    } else if (plan.price > 0) {
                      handleSubscribe(plan.id, plan.price);
                    }
                  }}
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Processando...
                    </>
                  ) : isCurrentPlan ? (
                    <>
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Plano Atual
                    </>
                  ) : plan.id === 'enterprise' ? (
                    <>
                      <MessageCircle className="h-4 w-4 mr-2" />
                      {plan.buttonText}
                    </>
                  ) : (
                    <>
                      <Crown className="h-4 w-4 mr-2" />
                      {plan.buttonText}
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Payment History */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <CreditCard className="h-6 w-6 mr-2 text-blue-600" />
            Histórico de Pagamentos
          </CardTitle>
          <CardDescription>
            Seus pagamentos e transações na plataforma
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
            </div>
          ) : payments.length === 0 ? (
            <div className="text-center py-12">
              <CreditCard className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Nenhum pagamento encontrado</h3>
              <p className="text-muted-foreground mb-4">
                Você ainda não realizou nenhum pagamento
              </p>
              <Button onClick={() => handleSubscribe('premium', 49.90)}>
                <Crown className="h-4 w-4 mr-2" />
                Assinar Premium
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {payments.map((payment) => (
                <div key={payment.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                      <CreditCard className="h-6 w-6 text-blue-600" />
                    </div>
                    
                    <div>
                      <div className="font-medium">
                        {formatCurrency(payment.amount)}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {formatDate(payment.created_at)}
                      </div>
                      {payment.external_id && (
                        <div className="text-xs text-muted-foreground">
                          ID: {payment.external_id}
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <Badge className={getPaymentStatusColor(payment.status)}>
                      {getPaymentStatusText(payment.status)}
                    </Badge>
                    
                    {payment.proof_url && (
                      <Button variant="ghost" size="sm" asChild>
                        <a href={payment.proof_url} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4" />
                        </a>
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Payment Instructions */}
      <Alert className="mt-8 border-blue-200 bg-blue-50">
        <AlertTriangle className="h-4 w-4 text-blue-600" />
        <AlertDescription className="text-blue-800">
          <strong>Como funciona:</strong> Após clicar em "Assinar Premium", você será redirecionado para o Mercado Pago. 
          Complete o pagamento e aguarde a confirmação automática. Em caso de dúvidas, entre em contato conosco.
        </AlertDescription>
      </Alert>
    </div>
  );
}
