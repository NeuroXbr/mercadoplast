import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Polymer, CreatePostRequest } from '@/types';
import { polymerService } from '@/services/polymerService';
import { postService } from '@/services/postService';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Package, 
  FileText, 
  Send, 
  ArrowLeft,
  Loader2,
  AlertTriangle,
  Info,
  Image,
  Upload
} from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/useAuth';

const createPostSchema = z.object({
  title: z.string()
    .min(10, 'Título deve ter pelo menos 10 caracteres')
    .max(100, 'Título deve ter no máximo 100 caracteres'),
  body: z.string()
    .min(50, 'Descrição deve ter pelo menos 50 caracteres')
    .max(2000, 'Descrição deve ter no máximo 2000 caracteres'),
  polymer_id: z.string().min(1, 'Selecione um polímero'),
});

type CreatePostFormData = z.infer<typeof createPostSchema>;

export function CreatePostPage() {
  const [polymers, setPolymers] = useState<Polymer[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const { user, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  const form = useForm<CreatePostFormData>({
    resolver: zodResolver(createPostSchema),
    defaultValues: {
      title: '',
      body: '',
      polymer_id: '',
    },
  });

  useEffect(() => {
    if (!isAuthenticated()) {
      navigate('/login');
      return;
    }
    
    loadPolymers();
  }, [isAuthenticated, navigate]);

  const loadPolymers = async () => {
    try {
      setLoading(true);
      const polymersData = await polymerService.getPolymers();
      setPolymers(polymersData);
    } catch (error) {
      console.error('Erro ao carregar polímeros:', error);
      toast.error('Erro ao carregar lista de polímeros');
      
      // Mock data para desenvolvimento
      const mockPolymers: Polymer[] = [
        {
          id: '1',
          acronym: 'PE',
          name: 'Polietileno',
          description: 'Polímero termoplástico amplamente utilizado',
        },
        {
          id: '2',
          acronym: 'PP',
          name: 'Polipropileno',
          description: 'Polímero versátil com excelente resistência química',
        },
        {
          id: '3',
          acronym: 'PVC',
          name: 'Policloreto de Vinila',
          description: 'Polímero rígido ou flexível, amplamente usado na construção',
        },
        {
          id: '4',
          acronym: 'PET',
          name: 'Politereftalato de Etileno',
          description: 'Polímero transparente, ideal para embalagens',
        },
        {
          id: '5',
          acronym: 'PS',
          name: 'Poliestireno',
          description: 'Polímero leve e isolante térmico',
        },
      ];
      setPolymers(mockPolymers);
    } finally {
      setLoading(false);
    }
  };

  const onSubmit = async (data: CreatePostFormData) => {
    try {
      setSubmitting(true);
      
      const postData: CreatePostRequest = {
        title: data.title,
        body: data.body,
        polymer_id: data.polymer_id,
      };

      const newPost = await postService.createPost(postData);
      
      toast.success('Post criado com sucesso!');
      navigate(`/post/${newPost.id}`);
    } catch (error: any) {
      console.error('Erro ao criar post:', error);
      const message = error.response?.data?.message || 'Erro ao criar post';
      toast.error(message);
    } finally {
      setSubmitting(false);
    }
  };

  const selectedPolymer = polymers.find(p => p.id === form.watch('polymer_id'));

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <Loader2 className="h-12 w-12 animate-spin text-blue-600 mx-auto mb-4" />
            <p className="text-lg text-muted-foreground">Carregando formulário...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Criar Novo Post
          </h1>
          <p className="text-muted-foreground">
            Compartilhe oportunidades no mercado de materiais plásticos
          </p>
        </div>
        
        <Button variant="outline" onClick={() => navigate(-1)}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Voltar
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Form */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="h-6 w-6 mr-2 text-blue-600" />
                Informações do Post
              </CardTitle>
              <CardDescription>
                Preencha as informações sobre sua oportunidade de negócio
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                {/* Title */}
                <div className="space-y-2">
                  <Label htmlFor="title">Título *</Label>
                  <Input
                    id="title"
                    placeholder="Ex: Vendo lote de PE virgem para embalagens"
                    {...form.register('title')}
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>
                      {form.formState.errors.title && (
                        <span className="text-red-600">
                          {form.formState.errors.title.message}
                        </span>
                      )}
                    </span>
                    <span>{form.watch('title')?.length || 0}/100</span>
                  </div>
                </div>

                {/* Polymer Selection */}
                <div className="space-y-2">
                  <Label htmlFor="polymer">Polímero *</Label>
                  <Select
                    value={form.watch('polymer_id')}
                    onValueChange={(value) => form.setValue('polymer_id', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o tipo de polímero" />
                    </SelectTrigger>
                    <SelectContent>
                      {polymers.map((polymer) => (
                        <SelectItem key={polymer.id} value={polymer.id}>
                          <div className="flex items-center space-x-2">
                            <Package className="h-4 w-4" />
                            <span>
                              <strong>{polymer.acronym}</strong> - {polymer.name}
                            </span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {form.formState.errors.polymer_id && (
                    <p className="text-sm text-red-600">
                      {form.formState.errors.polymer_id.message}
                    </p>
                  )}
                </div>

                {/* Selected Polymer Info */}
                {selectedPolymer && (
                  <Alert className="border-blue-200 bg-blue-50">
                    <Package className="h-4 w-4 text-blue-600" />
                    <AlertDescription className="text-blue-800">
                      <strong>{selectedPolymer.acronym} - {selectedPolymer.name}</strong>
                      <br />
                      {selectedPolymer.description}
                    </AlertDescription>
                  </Alert>
                )}

                {/* Description */}
                <div className="space-y-2">
                  <Label htmlFor="body">Descrição *</Label>
                  <Textarea
                    id="body"
                    placeholder="Descreva detalhadamente sua oportunidade: quantidade, qualidade, preço, localização, condições de pagamento, etc."
                    rows={8}
                    {...form.register('body')}
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>
                      {form.formState.errors.body && (
                        <span className="text-red-600">
                          {form.formState.errors.body.message}
                        </span>
                      )}
                    </span>
                    <span>{form.watch('body')?.length || 0}/2000</span>
                  </div>
                </div>

                {/* Image Upload Placeholder */}
                <div className="space-y-2">
                  <Label>Imagens (Em breve)</Label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                    <Image className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-muted-foreground mb-2">
                      Upload de imagens será implementado em breve
                    </p>
                    <Button variant="outline" disabled>
                      <Upload className="h-4 w-4 mr-2" />
                      Adicionar Imagens
                    </Button>
                  </div>
                </div>

                {/* Submit Button */}
                <div className="flex justify-end space-x-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => navigate(-1)}
                  >
                    Cancelar
                  </Button>
                  
                  <Button type="submit" disabled={submitting}>
                    {submitting ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Publicando...
                      </>
                    ) : (
                      <>
                        <Send className="h-4 w-4 mr-2" />
                        Publicar Post
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="lg:col-span-1">
          <div className="space-y-6">
            {/* Tips Card */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <Info className="h-5 w-5 mr-2 text-blue-600" />
                  Dicas para um bom post
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div>
                  <h4 className="font-medium mb-1">Título atrativo</h4>
                  <p className="text-muted-foreground">
                    Use palavras-chave relevantes e seja específico sobre o que está oferecendo
                  </p>
                </div>
                
                <div>
                  <h4 className="font-medium mb-1">Descrição completa</h4>
                  <p className="text-muted-foreground">
                    Inclua quantidade, qualidade, preço, localização e condições
                  </p>
                </div>
                
                <div>
                  <h4 className="font-medium mb-1">Polímero correto</h4>
                  <p className="text-muted-foreground">
                    Selecione o tipo exato de polímero para alcançar o público certo
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Guidelines Card */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <AlertTriangle className="h-5 w-5 mr-2 text-amber-600" />
                  Diretrizes
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="flex items-start space-x-2">
                  <div className="w-1.5 h-1.5 bg-amber-600 rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-muted-foreground">
                    Seja honesto sobre a qualidade e condições do material
                  </p>
                </div>
                
                <div className="flex items-start space-x-2">
                  <div className="w-1.5 h-1.5 bg-amber-600 rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-muted-foreground">
                    Não publique conteúdo ofensivo ou spam
                  </p>
                </div>
                
                <div className="flex items-start space-x-2">
                  <div className="w-1.5 h-1.5 bg-amber-600 rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-muted-foreground">
                    Responda rapidamente aos interessados
                  </p>
                </div>
                
                <div className="flex items-start space-x-2">
                  <div className="w-1.5 h-1.5 bg-amber-600 rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-muted-foreground">
                    Mantenha suas informações de contato atualizadas
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* User Info */}
            {user && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Publicando como</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="text-blue-600 font-medium">
                        {user.username.slice(0, 2).toUpperCase()}
                      </span>
                    </div>
                    <div>
                      <p className="font-medium">{user.username}</p>
                      <p className="text-sm text-muted-foreground">{user.email}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
