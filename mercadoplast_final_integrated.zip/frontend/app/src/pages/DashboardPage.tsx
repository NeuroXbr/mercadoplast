import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Post, Payment, KYCDocument } from '@/types';
import { postService } from '@/services/postService';
import { paymentService } from '@/services/paymentService';
import { kycService } from '@/services/kycService';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  User, 
  FileText, 
  CreditCard, 
  Shield, 
  Crown,
  Plus,
  Eye,
  Calendar,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Clock,
  Package
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export function DashboardPage() {
  const { user, isPremium } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [kycDocuments, setKycDocuments] = useState<KYCDocument[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      
      // Carregar posts do usuário (simulado - endpoint não existe ainda)
      // const postsData = await postService.getPosts({ limit: 5 });
      // setPosts(postsData.posts);

      // Carregar pagamentos
      try {
        const paymentsData = await paymentService.getMyPayments();
        setPayments(paymentsData);
      } catch (error) {
        console.warn('Erro ao carregar pagamentos:', error);
      }

      // Carregar status KYC
      try {
        const kycData = await kycService.getKYCStatus();
        setKycDocuments(kycData);
      } catch (error) {
        console.warn('Erro ao carregar KYC:', error);
      }
    } catch (error) {
      console.error('Erro ao carregar dados do dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const getKYCProgress = () => {
    if (kycDocuments.length === 0) return 0;
    const approved = kycDocuments.filter(doc => doc.status === 'approved').length;
    return (approved / kycDocuments.length) * 100;
  };

  const getKYCStatusIcon = (status: string) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'rejected':
        return <XCircle className="h-4 w-4 text-red-600" />;
      default:
        return <Clock className="h-4 w-4 text-yellow-600" />;
    }
  };

  const getKYCStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  const formatDate = (dateString: string) => {
    try {
      return formatDistanceToNow(new Date(dateString), {
        addSuffix: true,
        locale: ptBR,
      });
    } catch {
      return 'Data inválida';
    }
  };

  if (!user) {
    return null;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
            <p className="text-muted-foreground mt-1">
              Bem-vindo de volta, {user.username}!
            </p>
          </div>
          
          {isPremium() && (
            <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white">
              <Crown className="w-4 h-4 mr-1" />
              Premium
            </Badge>
          )}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Meus Posts</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{posts.length}</div>
            <p className="text-xs text-muted-foreground">
              +0 desde o último mês
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Visualizações</CardTitle>
            <Eye className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">0</div>
            <p className="text-xs text-muted-foreground">
              +0% desde a semana passada
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Status KYC</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{Math.round(getKYCProgress())}%</div>
            <p className="text-xs text-muted-foreground">
              Documentos aprovados
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pagamentos</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{payments.length}</div>
            <p className="text-xs text-muted-foreground">
              Total de transações
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* KYC Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Shield className="h-5 w-5 mr-2" />
              Status KYC
            </CardTitle>
            <CardDescription>
              Verificação de identidade e documentos
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Progresso geral</span>
                <span>{Math.round(getKYCProgress())}%</span>
              </div>
              <Progress value={getKYCProgress()} className="h-2" />
            </div>

            <div className="space-y-3">
              {kycDocuments.length > 0 ? (
                kycDocuments.map((doc, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      {getKYCStatusIcon(doc.status)}
                      <div>
                        <p className="font-medium capitalize">
                          {doc.type.replace('_', ' ')}
                        </p>
                        {doc.uploaded_at && (
                          <p className="text-xs text-muted-foreground">
                            {formatDate(doc.uploaded_at)}
                          </p>
                        )}
                      </div>
                    </div>
                    <Badge className={getKYCStatusColor(doc.status)}>
                      {doc.status === 'approved' ? 'Aprovado' : 
                       doc.status === 'rejected' ? 'Rejeitado' : 'Pendente'}
                    </Badge>
                  </div>
                ))
              ) : (
                <div className="text-center py-6">
                  <AlertTriangle className="h-12 w-12 text-yellow-500 mx-auto mb-3" />
                  <p className="text-muted-foreground mb-4">
                    Nenhum documento KYC enviado ainda
                  </p>
                </div>
              )}
            </div>

            <Button asChild className="w-full">
              <Link to="/kyc">
                <Shield className="h-4 w-4 mr-2" />
                Gerenciar KYC
              </Link>
            </Button>
          </CardContent>
        </Card>

        {/* Recent Payments */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <CreditCard className="h-5 w-5 mr-2" />
              Pagamentos Recentes
            </CardTitle>
            <CardDescription>
              Histórico de transações e planos
            </CardDescription>
          </CardHeader>
          <CardContent>
            {payments.length > 0 ? (
              <div className="space-y-3">
                {payments.slice(0, 3).map((payment) => (
                  <div key={payment.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">
                        R$ {payment.amount.toFixed(2)}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {formatDate(payment.created_at)}
                      </p>
                    </div>
                    <Badge className={getPaymentStatusColor(payment.status)}>
                      {payment.status === 'completed' ? 'Pago' : 
                       payment.status === 'failed' ? 'Falhou' : 'Pendente'}
                    </Badge>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6">
                <CreditCard className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                <p className="text-muted-foreground mb-4">
                  Nenhum pagamento realizado ainda
                </p>
              </div>
            )}

            <Button asChild className="w-full mt-4">
              <Link to="/payments">
                <CreditCard className="h-4 w-4 mr-2" />
                Ver Todos os Pagamentos
              </Link>
            </Button>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="h-5 w-5 mr-2" />
              Ações Rápidas
            </CardTitle>
            <CardDescription>
              Principais funcionalidades do sistema
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button asChild className="w-full justify-start">
              <Link to="/create-post">
                <Plus className="h-4 w-4 mr-2" />
                Criar Novo Post
              </Link>
            </Button>
            
            <Button variant="outline" asChild className="w-full justify-start">
              <Link to="/kyc">
                <Shield className="h-4 w-4 mr-2" />
                Completar KYC
              </Link>
            </Button>
            
            {!isPremium() && (
              <Button variant="outline" asChild className="w-full justify-start">
                <Link to="/payments">
                  <Crown className="h-4 w-4 mr-2" />
                  Upgrade para Premium
                </Link>
              </Button>
            )}
            
            <Button variant="outline" asChild className="w-full justify-start">
              <Link to="/profile">
                <User className="h-4 w-4 mr-2" />
                Editar Perfil
              </Link>
            </Button>
          </CardContent>
        </Card>

        {/* Recent Posts */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Package className="h-5 w-5 mr-2" />
              Meus Posts Recentes
            </CardTitle>
            <CardDescription>
              Últimas oportunidades compartilhadas
            </CardDescription>
          </CardHeader>
          <CardContent>
            {posts.length > 0 ? (
              <div className="space-y-3">
                {posts.slice(0, 3).map((post) => (
                  <div key={post.id} className="p-3 border rounded-lg">
                    <h4 className="font-medium line-clamp-1">{post.title}</h4>
                    <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                      {post.body}
                    </p>
                    <div className="flex items-center justify-between mt-2">
                      <Badge variant="secondary" className="text-xs">
                        {post.polymer.acronym}
                      </Badge>
                      <span className="text-xs text-muted-foreground">
                        {formatDate(post.created_at)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6">
                <Package className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                <p className="text-muted-foreground mb-4">
                  Você ainda não criou nenhum post
                </p>
                <Button asChild>
                  <Link to="/create-post">
                    <Plus className="h-4 w-4 mr-2" />
                    Criar Primeiro Post
                  </Link>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
