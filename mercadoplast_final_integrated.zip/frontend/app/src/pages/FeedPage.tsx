import React, { useEffect, useState } from 'react';
import { Post } from '@/types';
import { postService } from '@/services/postService';
import { usePagination } from '@/hooks/usePagination';
import { PostCard } from '@/components/PostCard';
import { SideAds } from '@/components/SideAds';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { 
  Loader2, 
  Search, 
  Filter, 
  Plus,
  RefreshCw,
  Package
} from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/useAuth';
import { Link } from 'react-router-dom';

export function FeedPage() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const { isAuthenticated } = useAuth();
  
  const [pagination, paginationActions] = usePagination({
    initialLimit: 10,
  });

  useEffect(() => {
    loadPosts(true);
  }, []);

  const loadPosts = async (reset = false) => {
    try {
      if (reset) {
        setLoading(true);
        setPosts([]);
        paginationActions.reset();
      } else {
        setLoadingMore(true);
      }

      const response = await postService.getPosts({
        limit: pagination.limit,
        offset: reset ? 0 : pagination.offset,
      });

      if (reset) {
        setPosts(response.posts);
      } else {
        setPosts(prev => [...prev, ...response.posts]);
      }

      // Se a resposta tem informação de total, usar ela
      if (response.posts.length > 0) {
        paginationActions.setTotal(response.posts.length + pagination.offset + 1);
      }
    } catch (error: any) {
      console.error('Erro ao carregar posts:', error);
      toast.error('Erro ao carregar posts');
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  };

  const handleLoadMore = () => {
    paginationActions.nextPage();
    loadPosts(false);
  };

  const handleRefresh = () => {
    loadPosts(true);
    toast.success('Feed atualizado!');
  };

  const filteredPosts = posts.filter(post =>
    post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.body.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.polymer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.polymer.acronym.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <Loader2 className="h-12 w-12 animate-spin text-blue-600 mx-auto mb-4" />
            <p className="text-lg text-muted-foreground">Carregando posts...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-3">
          {/* Header */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                Feed de Materiais Plásticos
              </h1>
              <p className="text-muted-foreground">
                Descubra oportunidades no mercado de polímeros
              </p>
            </div>
            
            <div className="flex items-center space-x-2 mt-4 sm:mt-0">
              <Button variant="outline" size="sm" onClick={handleRefresh}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Atualizar
              </Button>
              
              {isAuthenticated() && (
                <Button asChild>
                  <Link to="/create-post">
                    <Plus className="h-4 w-4 mr-2" />
                    Criar Post
                  </Link>
                </Button>
              )}
            </div>
          </div>

          {/* Search and Filters */}
          <Card className="mb-6">
            <CardContent className="p-4">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    placeholder="Buscar por título, conteúdo ou polímero..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Button variant="outline" size="sm">
                  <Filter className="h-4 w-4 mr-2" />
                  Filtros
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Posts Grid */}
          {filteredPosts.length === 0 ? (
            <Card className="text-center py-12">
              <CardContent>
                <Package className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Nenhum post encontrado</h3>
                <p className="text-muted-foreground mb-4">
                  {searchTerm 
                    ? 'Tente ajustar sua busca ou limpar os filtros'
                    : 'Seja o primeiro a compartilhar uma oportunidade!'
                  }
                </p>
                {isAuthenticated() && (
                  <Button asChild>
                    <Link to="/create-post">
                      <Plus className="h-4 w-4 mr-2" />
                      Criar Primeiro Post
                    </Link>
                  </Button>
                )}
              </CardContent>
            </Card>
          ) : (
            <>
              <div className="grid gap-6 mb-8">
                {filteredPosts.map((post) => (
                  <PostCard key={post.id} post={post} />
                ))}
              </div>

              {/* Load More Button */}
              {pagination.hasMore && (
                <div className="text-center">
                  <Button 
                    variant="outline" 
                    size="lg"
                    onClick={handleLoadMore}
                    disabled={loadingMore}
                  >
                    {loadingMore ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Carregando...
                      </>
                    ) : (
                      'Carregar mais posts'
                    )}
                  </Button>
                </div>
              )}
            </>
          )}
        </div>

        {/* Sidebar */}
        <div className="lg:col-span-1">
          <div className="sticky top-24">
            <SideAds />
          </div>
        </div>
      </div>
    </div>
  );
}
