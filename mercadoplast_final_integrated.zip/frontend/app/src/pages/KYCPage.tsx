import React, { useEffect, useState, useCallback } from 'react';
import { KYCDocument, KYCDocumentType } from '@/types';
import { kycService } from '@/services/kycService';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  FileCheck, 
  Upload, 
  CheckCircle, 
  XCircle, 
  Clock, 
  AlertTriangle,
  FileText,
  Building,
  MapPin,
  CreditCard,
  Loader2
} from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/useAuth';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

const documentTypes: { type: KYCDocumentType; label: string; description: string; icon: React.ReactNode }[] = [
  {
    type: 'cpf',
    label: 'CPF',
    description: 'Documento de identificação pessoal',
    icon: <CreditCard className="h-5 w-5" />,
  },
  {
    type: 'cnpj',
    label: 'CNPJ',
    description: 'Cadastro Nacional da Pessoa Jurídica',
    icon: <Building className="h-5 w-5" />,
  },
  {
    type: 'address_proof',
    label: 'Comprovante de Endereço',
    description: 'Conta de luz, água ou telefone',
    icon: <MapPin className="h-5 w-5" />,
  },
  {
    type: 'company_registration',
    label: 'Contrato Social',
    description: 'Documento de constituição da empresa',
    icon: <FileText className="h-5 w-5" />,
  },
];

export function KYCPage() {
  const [documents, setDocuments] = useState<KYCDocument[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploadingFiles, setUploadingFiles] = useState<Set<KYCDocumentType>>(new Set());
  const { user } = useAuth();

  useEffect(() => {
    loadKYCStatus();
  }, []);

  const loadKYCStatus = async () => {
    try {
      setLoading(true);
      const kycData = await kycService.getKYCStatus();
      setDocuments(kycData);
    } catch (error) {
      console.error('Erro ao carregar status KYC:', error);
      toast.error('Erro ao carregar documentos KYC');
    } finally {
      setLoading(false);
    }
  };

  const getDocumentStatus = (type: KYCDocumentType): KYCDocument | undefined => {
    return documents.find(doc => doc.type === type);
  };

  const getProgress = () => {
    if (documents.length === 0) return 0;
    const approved = documents.filter(doc => doc.status === 'approved').length;
    return (approved / documentTypes.length) * 100;
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'rejected':
        return <XCircle className="h-5 w-5 text-red-600" />;
      default:
        return <Clock className="h-5 w-5 text-yellow-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'approved':
        return 'Aprovado';
      case 'rejected':
        return 'Rejeitado';
      default:
        return 'Pendente';
    }
  };

  const formatDate = (dateString: string) => {
    try {
      return formatDistanceToNow(new Date(dateString), {
        addSuffix: true,
        locale: ptBR,
      });
    } catch {
      return 'Data inválida';
    }
  };

  const handleFileUpload = useCallback(async (type: KYCDocumentType, file: File) => {
    if (!file) return;

    // Validar tipo de arquivo
    const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg'];
    if (!allowedTypes.includes(file.type)) {
      toast.error('Tipo de arquivo não suportado. Use PDF, JPEG ou PNG.');
      return;
    }

    // Validar tamanho (5MB max)
    const maxSize = 5 * 1024 * 1024; // 5MB
    if (file.size > maxSize) {
      toast.error('Arquivo muito grande. Tamanho máximo: 5MB.');
      return;
    }

    try {
      setUploadingFiles(prev => new Set(prev).add(type));

      // 1. Obter URL de upload
      const uploadResponse = await kycService.getUploadURL(type, file.name);
      
      // 2. Fazer upload do arquivo (simulado)
      // Em produção, você faria upload para a URL assinada
      await new Promise(resolve => setTimeout(resolve, 2000)); // Simular upload
      
      // 3. Submeter informações do documento
      await kycService.submitKYC({
        documents: [{
          type,
          object_path: uploadResponse.object_path,
          file_size: file.size,
          mime_type: file.type,
        }]
      });

      toast.success('Documento enviado com sucesso!');
      
      // Recarregar status
      await loadKYCStatus();
    } catch (error: any) {
      console.error('Erro no upload:', error);
      toast.error('Erro ao enviar documento');
    } finally {
      setUploadingFiles(prev => {
        const newSet = new Set(prev);
        newSet.delete(type);
        return newSet;
      });
    }
  }, []);

  const triggerFileInput = (type: KYCDocumentType) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.pdf,.jpg,.jpeg,.png';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        handleFileUpload(type, file);
      }
    };
    input.click();
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <Loader2 className="h-12 w-12 animate-spin text-blue-600 mx-auto mb-4" />
            <p className="text-lg text-muted-foreground">Carregando documentos KYC...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Verificação KYC
        </h1>
        <p className="text-muted-foreground">
          Complete sua verificação de identidade para acessar todos os recursos da plataforma
        </p>
      </div>

      {/* Progress Overview */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="flex items-center">
            <FileCheck className="h-6 w-6 mr-2 text-blue-600" />
            Progresso da Verificação
          </CardTitle>
          <CardDescription>
            {Math.round(getProgress())}% dos documentos aprovados
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Progress value={getProgress()} className="h-3" />
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">
                {documents.filter(doc => doc.status === 'approved').length}
              </div>
              <div className="text-sm text-blue-700">Aprovados</div>
            </div>
            
            <div className="text-center p-4 bg-yellow-50 rounded-lg">
              <div className="text-2xl font-bold text-yellow-600">
                {documents.filter(doc => doc.status === 'pending').length}
              </div>
              <div className="text-sm text-yellow-700">Pendentes</div>
            </div>
            
            <div className="text-center p-4 bg-red-50 rounded-lg">
              <div className="text-2xl font-bold text-red-600">
                {documents.filter(doc => doc.status === 'rejected').length}
              </div>
              <div className="text-sm text-red-700">Rejeitados</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* KYC Status Alert */}
      {user?.kycStatus === 'pending' && (
        <Alert className="mb-6 border-yellow-200 bg-yellow-50">
          <AlertTriangle className="h-4 w-4 text-yellow-600" />
          <AlertDescription className="text-yellow-800">
            Sua verificação KYC está pendente. Complete o envio de todos os documentos para acelerar o processo.
          </AlertDescription>
        </Alert>
      )}

      {user?.kycStatus === 'rejected' && (
        <Alert className="mb-6 border-red-200 bg-red-50">
          <XCircle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-800">
            Alguns documentos foram rejeitados. Verifique os detalhes abaixo e reenvie os documentos necessários.
          </AlertDescription>
        </Alert>
      )}

      {user?.kycStatus === 'approved' && (
        <Alert className="mb-6 border-green-200 bg-green-50">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800">
            Parabéns! Sua verificação KYC foi aprovada. Você tem acesso completo à plataforma.
          </AlertDescription>
        </Alert>
      )}

      {/* Documents Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {documentTypes.map((docType) => {
          const documentStatus = getDocumentStatus(docType.type);
          const isUploading = uploadingFiles.has(docType.type);

          return (
            <Card key={docType.type} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    {docType.icon}
                    <span>{docType.label}</span>
                  </div>
                  
                  {documentStatus && (
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(documentStatus.status)}
                      <Badge className={getStatusColor(documentStatus.status)}>
                        {getStatusText(documentStatus.status)}
                      </Badge>
                    </div>
                  )}
                </CardTitle>
                <CardDescription>
                  {docType.description}
                </CardDescription>
              </CardHeader>
              
              <CardContent className="space-y-4">
                {documentStatus ? (
                  <div className="space-y-3">
                    <div className="p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Status:</span>
                        <Badge className={getStatusColor(documentStatus.status)}>
                          {getStatusText(documentStatus.status)}
                        </Badge>
                      </div>
                      
                      {documentStatus.uploaded_at && (
                        <div className="flex items-center justify-between mt-2">
                          <span className="text-sm font-medium">Enviado:</span>
                          <span className="text-sm text-muted-foreground">
                            {formatDate(documentStatus.uploaded_at)}
                          </span>
                        </div>
                      )}
                    </div>
                    
                    {documentStatus.status === 'rejected' && (
                      <Button
                        onClick={() => triggerFileInput(docType.type)}
                        disabled={isUploading}
                        className="w-full"
                        variant="outline"
                      >
                        {isUploading ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Enviando...
                          </>
                        ) : (
                          <>
                            <Upload className="h-4 w-4 mr-2" />
                            Reenviar Documento
                          </>
                        )}
                      </Button>
                    )}
                  </div>
                ) : (
                  <Button
                    onClick={() => triggerFileInput(docType.type)}
                    disabled={isUploading}
                    className="w-full"
                  >
                    {isUploading ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Enviando...
                      </>
                    ) : (
                      <>
                        <Upload className="h-4 w-4 mr-2" />
                        Enviar Documento
                      </>
                    )}
                  </Button>
                )}
                
                <div className="text-xs text-muted-foreground">
                  Formatos aceitos: PDF, JPEG, PNG (máx. 5MB)
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Help Section */}
      <Card className="mt-8">
        <CardHeader>
          <CardTitle className="flex items-center">
            <AlertTriangle className="h-5 w-5 mr-2 text-blue-600" />
            Dicas Importantes
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <h4 className="font-medium mb-2">Qualidade dos Documentos:</h4>
              <ul className="space-y-1 text-muted-foreground">
                <li>• Imagens nítidas e bem iluminadas</li>
                <li>• Todos os dados devem estar visíveis</li>
                <li>• Evite reflexos e sombras</li>
                <li>• Documentos devem estar dentro da validade</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-medium mb-2">Tempo de Análise:</h4>
              <ul className="space-y-1 text-muted-foreground">
                <li>• Análise em até 2 dias úteis</li>
                <li>• Você será notificado por email</li>
                <li>• Documentos rejeitados podem ser reenviados</li>
                <li>• Suporte disponível para dúvidas</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
