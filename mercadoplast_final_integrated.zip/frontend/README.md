# MercadoPlast Frontend

Plataforma de marketplace completa e de nível empresarial para materiais plásticos com interfaces excepcionais.

## 🚀 Estrutura do Projeto

```
mercadoplast-frontend/
├── app/                    # Aplicação pública para usuários
│   ├── src/
│   │   ├── components/     # Componentes reutilizáveis
│   │   ├── pages/          # Páginas da aplicação
│   │   ├── services/       # Serviços de API
│   │   ├── hooks/          # Hooks customizados
│   │   ├── types/          # Definições TypeScript
│   │   └── lib/            # Utilitários
│   └── package.json
├── admin/                  # Painel administrativo
│   ├── src/
│   │   ├── components/     # Componentes do admin
│   │   ├── pages/          # Páginas administrativas
│   │   ├── services/       # Serviços de API do admin
│   │   └── hooks/          # Hooks do admin
│   └── package.json
└── README.md
```

## 🎯 Funcionalidades

### Aplicação Pública (App)
- ✅ **Feed interativo** com busca, filtros e carregamento infinito
- ✅ **Sistema de autenticação** robusto com refresh automático
- ✅ **Dashboard pessoal** com métricas e status do usuário
- ✅ **Sistema KYC completo** com upload de documentos
- ✅ **Página de pagamentos** com planos Premium e histórico
- ✅ **Criação de posts** com seleção de polímeros
- ✅ **Perfil do usuário** com edição de dados
- ✅ **Sidebar de anúncios** com tracking

### Painel Administrativo (Admin)
- ✅ **Dashboard administrativo** com métricas em tempo real
- ✅ **Gerenciamento de usuários** com busca e paginação
- ✅ **Sistema de autenticação** específico para admins
- ✅ **Controle de acesso** por roles (admin/moderator/analyst)
- ✅ **Layout profissional** com sidebar responsiva

## 🛠️ Tecnologias

- **Frontend**: React 18 + TypeScript + Vite
- **Styling**: Tailwind CSS + shadcn/ui
- **Roteamento**: React Router DOM
- **Formulários**: React Hook Form + Zod
- **HTTP Client**: Axios com interceptors
- **Notificações**: Sonner
- **Ícones**: Lucide React
- **Formatação**: date-fns

## 🚀 Como Executar

### Pré-requisitos
- Node.js 18+ 
- pnpm (recomendado) ou npm

### Instalação

1. **Clone o repositório**
```bash
git clone <repository-url>
cd mercadoplast-frontend
```

2. **Instale as dependências da aplicação pública**
```bash
cd app
pnpm install
```

3. **Instale as dependências do painel admin**
```bash
cd ../admin
pnpm install
```

### Desenvolvimento

**Executar aplicação pública (porta 3001):**
```bash
cd app
pnpm dev
```

**Executar painel administrativo (porta 3002):**
```bash
cd admin
pnpm dev
```

### Build para Produção

**Build da aplicação pública:**
```bash
cd app
pnpm build
pnpm preview
```

**Build do painel admin:**
```bash
cd admin
pnpm build
pnpm preview
```

## 🎨 Design System

### Cores Principais
- **Primary**: Blue 600 (#2563eb)
- **Secondary**: Gray 100 (#f3f4f6)
- **Success**: Green 600 (#16a34a)
- **Warning**: Yellow 600 (#ca8a04)
- **Error**: Red 600 (#dc2626)

### Componentes UI
- Baseados em **shadcn/ui** e **Radix UI**
- **Totalmente acessíveis** com suporte a teclado
- **Responsivos** para todos os dispositivos
- **Animações fluidas** e micro-interações

## 🔧 Configuração

### Variáveis de Ambiente

**App (.env):**
```env
VITE_API_BASE_URL=http://localhost:3000
VITE_USE_STUBS=true
```

**Admin (.env):**
```env
VITE_API_BASE_URL=http://localhost:3000
VITE_USE_STUBS=true
```

### Stubs para Desenvolvimento
- Sistema de **stubs integrado** para desenvolvimento sem backend
- Dados mockados realistas para todas as funcionalidades
- Fácil alternância entre stubs e API real

## 📱 Responsividade

- **Mobile First**: Design otimizado para dispositivos móveis
- **Breakpoints**: sm (640px), md (768px), lg (1024px), xl (1280px)
- **Touch Friendly**: Botões e áreas de toque otimizadas
- **Performance**: Carregamento rápido em conexões lentas

## 🔐 Segurança

- **Autenticação JWT** com refresh automático
- **Validação de formulários** com Zod
- **Sanitização de dados** em todas as entradas
- **HTTPS Only** em produção
- **CSP Headers** configurados

## 🚀 Performance

### Otimizações Implementadas
- **Code Splitting** automático por rotas
- **Lazy Loading** de componentes pesados
- **Tree Shaking** para reduzir bundle size
- **Compressão Gzip/Brotli**
- **Cache de assets** otimizado
- **Preload** de recursos críticos

### Métricas Alvo
- **First Contentful Paint**: < 1.5s
- **Largest Contentful Paint**: < 2.5s
- **Cumulative Layout Shift**: < 0.1
- **First Input Delay**: < 100ms

## 🧪 Testes

```bash
# Executar testes unitários
pnpm test

# Executar testes com coverage
pnpm test:coverage

# Executar testes e2e
pnpm test:e2e
```

## 📦 Deploy

### Vercel (Recomendado)
```bash
# Deploy automático via Git
vercel --prod
```

### Netlify
```bash
# Build e deploy
netlify deploy --prod --dir=dist
```

### Docker
```bash
# Build da imagem
docker build -t mercadoplast-app .

# Executar container
docker run -p 3001:80 mercadoplast-app
```

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para detalhes.

## 🆘 Suporte

- **Documentação**: [docs.mercadoplast.com](https://docs.mercadoplast.com)
- **Issues**: [GitHub Issues](https://github.com/mercadoplast/frontend/issues)
- **Email**: suporte@mercadoplast.com

---

**Desenvolvido com ❤️ para o mercado de materiais plásticos**
